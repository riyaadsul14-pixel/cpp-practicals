# ADYPU Student Portal - B.Tech Computer Science & Engineering

**Ajeenkya DY Patil University, Pune** | School of Engineering | Department of Computer Science & Engineering

A complete student portal for the B.Tech CSE programme, written **100% in C++17 using object-oriented programming**, with a **Supabase (PostgreSQL) cloud database**. It is a menu-driven console application: colourful, simple to use, and needing no installation (just run `student_portal.exe`).

![UML class diagram](docs/UML_Class_Diagram.png)

---

## What makes it different

| Feature | What it does |
|---|---|
| **Attendance Guardian** | For every course, tells the student exactly how many lectures they can still miss, or how many they must attend in a row to get back to 75%. |
| **Grade Target Planner** | The student enters a target SGPA and the portal calculates the end-semester marks needed in each course (greedy optimiser over the 10-point grade scale), plus a grade ladder (marks needed for O / A+ / A). |
| **Student Success Radar** | An early-warning risk score (0-100: LOW / MEDIUM / HIGH) from attendance shortage, weak internal + mid-sem marks, backlogs and overdue fees, with suggested actions for mentors and the HoD. |
| **Verifiable certificates** | Bonafide certificates and report cards carry an HMAC-SHA256 verification code. Anyone (a bank, a company's HR) can check a code from the login screen without logging in and gets GENUINE, INVALID or NOT FOUND. |
| **Tamper-evident audit trail** | Every important action (marks, attendance, fees, passwords, approvals) is written to a SHA-256 hash chain. If anyone edits the database directly, *Verify audit-trail integrity* names the altered entry. |
| **Strong security** | PBKDF2-SHA256 password hashing (100,000 iterations, random salt), lock-out after 5 failed logins, forced change of temporary passwords, Row Level Security so the public Supabase key can read nothing. |

## Features by role

**Student:** dashboard summary - profile - Attendance Guardian - results with SGPA, CGPA, class and backlogs - Grade Target Planner - fees and receipts - notice board - bonafide request and download - signed report card - update mobile/email - change password

**Faculty:** my courses - mark attendance (type only the absentees, e.g. `2,5,9-11`) - course attendance report - enter internal / mid-sem / end-sem marks - result sheet with pass % and average - Success Radar for my students - notices - export attendance or results to CSV (Excel)

**Admin (academic office):** university overview (students per semester, fee collection) - students (list, search 360-degree view, add, edit, CSV import, promote semester, activate/deactivate, export) - faculty - curriculum and faculty assignment - auto-enrolment - fees (bill a semester, record payments, pending dues) - notices - Success Radar - certificate approvals - accounts (reset password, unlock) - audit trail and integrity check

---

## How to run

1. Keep the folder structure as it is (`student_portal.exe` reads `config/portal.conf` and `data/`).
2. Double-click **`student_portal.exe`**, or from a terminal in this folder:

```
student_portal.exe              start the portal (login screen)
student_portal.exe --check      test the Supabase connection and tables
student_portal.exe --seed       load the sample ADYPU data into an EMPTY database
student_portal.exe --reset-and-seed   delete all data and load the sample data again
```

The database is already set up and filled with sample data. **Demo logins:**

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `Admin@123` |
| Faculty | `fac001` ... `fac007` | `Faculty@123` |
| Student | PRN in lower case, e.g. `2024btcs001` | `Student@123` |

### Setting up a new Supabase project (only if you change the database)
1. Supabase Dashboard -> SQL Editor -> New query -> paste `database/schema.sql` -> **Run** (creates the 12 tables once).
2. Put the project URL and the **secret / service_role key** into `config/portal.conf`.
3. Run `student_portal.exe --check`, then `student_portal.exe --seed`.

### Rebuilding the exe from source (optional)
With any C++17 compiler (e.g. MinGW-w64 g++ on Windows), from this folder:
```
g++ -std=c++17 -O2 -Iinclude src/*.cpp src/*/*.cpp -o student_portal.exe -static -lwinhttp
```
Unit tests (84 checks of the pure C++ logic):
```
g++ -std=c++17 -O2 -Iinclude tests/unit_tests.cpp src/*/*.cpp -o unit_tests.exe -static -lwinhttp
unit_tests.exe
```
On Linux, use `-lcurl` instead of `-lwinhttp -static` (the libcurl backend is chosen automatically).

---

## OOP concepts used (for the viva)

| Concept | Where |
|---|---|
| **Classes and encapsulation** | Every model keeps its data `private` and exposes validated setters, e.g. `Student::setSemester()` rejects 9 (`include/models/Student.hpp`). |
| **Abstraction** | Abstract classes `Entity`, `User`, `HttpClient`, `Dashboard` with pure virtual functions (`toJson() = 0`, `role() = 0`, `send() = 0`, `handle() = 0`). |
| **Inheritance** | `Entity <- User <- Student / Faculty / Admin`; `Entity <- Course, MarkRecord, Payment ...`; `Dashboard <- StudentDashboard / FacultyDashboard / AdminDashboard`; `HttpClient <- WinHttpClient / CurlHttpClient`; `PortalException <- DatabaseException, ValidationException ...` |
| **Runtime polymorphism** | `AuthService::login()` returns `unique_ptr<User>`, and `DashboardFactory` opens the matching dashboard; `operator<<` calls the virtual `printProfile()` of the real type. |
| **Template Method pattern** | `Dashboard::run()` is fixed; the derived dashboards supply `title()`, `menuItems()` and `handle()`. |
| **Templates (generic programming)** | `Repository<T>` gives CRUD to any model (`Repository<Course>`, `Repository<MarkRecord>` ...). |
| **Composition** | `PortalContext` owns the database client and all 10 services; `SupabaseClient` owns its `HttpClient`. |
| **Operator overloading** | `Date` (`==`, `<`, `-`), `Json` (`[]`, `==`), `operator<<` for users. |
| **Exception handling** | Custom exception hierarchy; every menu action is protected, so a bad input or network error never crashes the portal. |
| **RAII and smart pointers** | WinHTTP handles closed in destructors, `std::unique_ptr` ownership, no manual `delete` anywhere. |
| **Static members / utility classes** | `Validator`, `GradeCalculator`, `PasswordHasher`, `Console`. |

## Project structure

```
student_portal.exe        ready-to-run program (Windows, no DLLs needed)
config/portal.conf        Supabase URL + key, academic year, attendance rule
database/schema.sql       one-time table creation for Supabase
data/                     sample ADYPU CSE data: students.csv, faculty.csv, courses.csv (curriculum)
include/  src/            C++ source code (.hpp headers, .cpp implementations)
   core/      Json, Config, Date, Csv, Sha256/PBKDF2, Validator, exceptions
   net/       HttpClient (WinHTTP on Windows, libcurl on Linux)
   db/        SupabaseClient, Query builder, Repository<T>
   models/    Entity, User, Student, Faculty, Admin, Course, Enrollment, Attendance, Marks, Notice, Fees, Documents, Audit
   services/  Auth, Users, Academic, Attendance, Results, Fees, Notices, Documents, Audit, Reports, Analytics
   ui/        Console, Table, Dashboard + Student/Faculty/Admin dashboards
   app/       PortalApp, PortalContext, UniversityProfile, DataSeeder
tests/unit_tests.cpp      84 unit tests
docs/                     UML class diagram (PNG + SVG)
output/                   sample console output, report card, bonafide certificate, attendance CSV
exports/                  (created automatically) files generated while using the portal
```

## Database (Supabase / PostgreSQL)
`users`, `students`, `faculty`, `courses`, `enrollments`, `attendance`, `marks`, `notices`, `fees`, `fee_payments`, `documents`, `audit_log`. The C++ program talks to them through the Supabase REST API (HTTPS + JSON), using its own JSON parser and HTTP client, with no third-party libraries.

## Academic rules used
- Marks: Internal / CA 20 + Mid-sem 30 + End-sem 50 = 100.
- Pass: total of at least 40 **and** end-sem of at least 20/50. 10-point grades: O >= 90, A+ >= 80, A >= 70, B+ >= 60, B >= 50, C >= 45, P >= 40, F below that.
- SGPA / CGPA are credit-weighted; a semester is declared once all its marks are entered.
- Minimum attendance: 75% (configurable in `config/portal.conf`).

These rules live in `GradeCalculator` (`src/services/Analytics.cpp`) and can be changed to match the official university regulations.

*All names, PRNs, phone numbers and emails in `data/` are fictional sample data.*
