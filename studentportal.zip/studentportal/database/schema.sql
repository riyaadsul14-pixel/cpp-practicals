-- =============================================================================
--  ADYPU Student Portal (B.Tech CSE) - Supabase database schema
--  ONE-TIME SETUP: Supabase Dashboard -> SQL Editor -> New query -> paste -> RUN
--  (Supabase is PostgreSQL; tables can only be created with SQL. All application
--   logic lives in the C++ program.)  Safe to run more than once.
-- =============================================================================

create table if not exists public.users (
    id                   bigint generated always as identity primary key,
    username             text not null unique,
    password_hash        text not null,                -- pbkdf2_sha256$iterations$salt$hash
    role                 text not null check (role in ('admin', 'faculty', 'student')),
    full_name            text not null,
    email                text not null unique,
    phone                text,
    is_active            boolean not null default true,
    must_change_password boolean not null default false,
    failed_logins        integer not null default 0,
    locked_until         bigint,                       -- unix time; null = not locked
    last_login_at        timestamptz,
    created_at           timestamptz not null default now()
);

create table if not exists public.students (
    id             bigint primary key references public.users (id) on delete cascade,
    prn            text not null unique,
    semester       smallint not null check (semester between 1 and 8),
    division       text not null default 'A',
    admission_year smallint not null,
    date_of_birth  date,
    gender         text check (gender in ('Male', 'Female', 'Other')),
    guardian_name  text,
    guardian_phone text,
    address        text
);

create table if not exists public.faculty (
    id             bigint primary key references public.users (id) on delete cascade,
    employee_code  text not null unique,
    designation    text not null default 'Assistant Professor',
    qualification  text,
    specialization text,
    joining_date   date
);

create table if not exists public.courses (
    id          bigint generated always as identity primary key,
    code        text not null unique,
    name        text not null,
    semester    smallint not null check (semester between 1 and 8),
    credits     smallint not null check (credits between 1 and 10),
    course_type text not null default 'Theory' check (course_type in ('Theory', 'Lab', 'Elective', 'Project')),
    faculty_id  bigint references public.faculty (id) on delete set null
);

create table if not exists public.enrollments (
    id            bigint generated always as identity primary key,
    student_id    bigint not null references public.students (id) on delete cascade,
    course_id     bigint not null references public.courses (id) on delete cascade,
    academic_year text not null,
    enrolled_at   timestamptz not null default now(),
    unique (student_id, course_id)
);

create table if not exists public.attendance (
    id         bigint generated always as identity primary key,
    course_id  bigint not null references public.courses (id) on delete cascade,
    student_id bigint not null references public.students (id) on delete cascade,
    class_date date not null,
    is_present boolean not null,
    marked_by  bigint references public.users (id) on delete set null,
    unique (course_id, student_id, class_date)
);

create table if not exists public.marks (
    id             bigint generated always as identity primary key,
    student_id     bigint not null references public.students (id) on delete cascade,
    course_id      bigint not null references public.courses (id) on delete cascade,
    internal_marks numeric(4, 1) check (internal_marks between 0 and 20),
    midsem_marks   numeric(4, 1) check (midsem_marks between 0 and 30),
    endsem_marks   numeric(4, 1) check (endsem_marks between 0 and 50),
    updated_by     bigint references public.users (id) on delete set null,
    updated_at     timestamptz not null default now(),
    unique (student_id, course_id)
);

create table if not exists public.notices (
    id         bigint generated always as identity primary key,
    title      text not null,
    body       text not null,
    audience   text not null default 'all' check (audience in ('all', 'students', 'faculty')),
    posted_by  bigint references public.users (id) on delete set null,
    created_at timestamptz not null default now()
);

create table if not exists public.fees (
    id            bigint generated always as identity primary key,
    student_id    bigint not null references public.students (id) on delete cascade,
    academic_year text not null,
    description   text not null,
    amount        numeric(12, 2) not null check (amount > 0),
    due_date      date not null,
    created_at    timestamptz not null default now(),
    unique (student_id, academic_year, description)
);

create table if not exists public.fee_payments (
    id          bigint generated always as identity primary key,
    fee_id      bigint not null references public.fees (id) on delete cascade,
    student_id  bigint not null references public.students (id) on delete cascade,
    amount      numeric(12, 2) not null check (amount > 0),
    mode        text not null check (mode in ('UPI', 'Card', 'NetBanking', 'Cash', 'Cheque', 'DD')),
    reference   text,
    paid_on     date not null,
    recorded_by bigint references public.users (id) on delete set null,
    created_at  timestamptz not null default now()
);

create table if not exists public.documents (
    id                bigint generated always as identity primary key,
    student_id        bigint not null references public.students (id) on delete cascade,
    doc_type          text not null check (doc_type in ('bonafide', 'report_card')),
    purpose           text not null,
    status            text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
    verification_code text unique,                     -- HMAC-SHA256 based, set on approval
    content_digest    text,
    issued_on         date,
    remarks           text,
    decided_by        bigint references public.users (id) on delete set null,
    requested_at      timestamptz not null default now()
);

create table if not exists public.audit_log (
    id         bigint generated always as identity primary key,
    actor_id   bigint,                                 -- no FK: the log must survive deletions
    actor_name text not null,
    action     text not null,
    details    text not null,
    created_at text not null,                          -- exact text that was hashed
    prev_hash  text not null unique,                   -- unique => the chain can never fork
    hash       text not null unique
);

-- Indexes for the lookups the portal performs most often
create index if not exists idx_students_semester   on public.students (semester);
create index if not exists idx_courses_semester    on public.courses (semester);
create index if not exists idx_courses_faculty     on public.courses (faculty_id);
create index if not exists idx_enrollments_course  on public.enrollments (course_id);
create index if not exists idx_attendance_student  on public.attendance (student_id);
create index if not exists idx_marks_course        on public.marks (course_id);
create index if not exists idx_fees_student        on public.fees (student_id);
create index if not exists idx_payments_fee        on public.fee_payments (fee_id);
create index if not exists idx_payments_student    on public.fee_payments (student_id);
create index if not exists idx_documents_student   on public.documents (student_id);
create index if not exists idx_notices_created     on public.notices (created_at desc);

-- Security: Row Level Security ON with no policies -> the public anon/publishable key
-- can read or change NOTHING. The C++ app uses the secret (service_role) key.
do $$
declare t text;
begin
    foreach t in array array['users', 'students', 'faculty', 'courses', 'enrollments', 'attendance', 'marks',
                             'notices', 'fees', 'fee_payments', 'documents', 'audit_log']
    loop
        execute format('alter table public.%I enable row level security', t);
        execute format('revoke all on public.%I from anon, authenticated', t);
        execute format('grant all on public.%I to service_role', t);
    end loop;
end $$;
grant usage, select on all sequences in schema public to service_role;

notify pgrst, 'reload schema';
