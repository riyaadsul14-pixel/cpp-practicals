// ============================================================================
//  unit_tests.cpp - tests for the pure C++ logic (no database needed)
//  Build & run:  cmake --build build && build/unit_tests
// ============================================================================
#include <cmath>
#include <iostream>
#include <string>

#include "core/Crypto.hpp"
#include "core/Csv.hpp"
#include "core/Date.hpp"
#include "core/Exceptions.hpp"
#include "core/Json.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"
#include "db/Query.hpp"
#include "models/Campus.hpp"
#include "models/Student.hpp"
#include "services/Analytics.hpp"
#include "services/CampusServices.hpp"

using namespace portal;

namespace {
int passed = 0;
int failed = 0;

void check(bool condition, const std::string& name) {
    if (condition) {
        ++passed;
    } else {
        ++failed;
        std::cout << "  FAIL: " << name << '\n';
    }
}

template <typename F>
bool throws(F&& f) {
    try {
        f();
    } catch (const std::exception&) {
        return true;
    }
    return false;
}

bool near(double a, double b) { return std::fabs(a - b) < 1e-6; }

Course makeCourse(long long id, int semester, int credits, const std::string& code) {
    Json row = Json::object();
    row["id"] = id;
    row["code"] = code;
    row["name"] = "Course " + code;
    row["semester"] = semester;
    row["credits"] = credits;
    return Course::fromJson(row);
}

MarkRecord makeMarks(long long courseId, double in, double mid, double end, bool withEnd = true) {
    MarkRecord m;
    m.setCourseId(courseId);
    m.set(ExamComponent::Internal, in);
    m.set(ExamComponent::MidSem, mid);
    if (withEnd) m.set(ExamComponent::EndSem, end);
    return m;
}
}  // namespace

void testJson() {
    const Json j = Json::parse(R"({"id":5,"name":"Aarav \"A\" Sharma","ok":true,"marks":[18.5,null],"u":"₹ 😀"})");
    check(j.getInt("id") == 5, "json int");
    check(j.getString("name") == "Aarav \"A\" Sharma", "json escaped string");
    check(j.getBool("ok"), "json bool");
    check(j["marks"].size() == 2 && near(j["marks"].at(0).asDouble(), 18.5), "json array");
    check(j["marks"].at(1).isNull(), "json null");
    check(j.getString("u") == "\xE2\x82\xB9 \xF0\x9F\x98\x80", "json unicode escapes + surrogate pair");
    check(j.getString("missing", "x") == "x", "json missing key fallback");
    check(Json::parse(j.dump()) == j, "json round trip");
    check(Json(185000.0).dump() == "185000" && Json(0.5).dump() == "0.5", "json number format");
    check(throws([] { Json::parse("{\"a\":}"); }), "json rejects bad value");
    check(throws([] { Json::parse("[1,2"); }), "json rejects unterminated array");
    check(throws([] { Json::parse("{} x"); }), "json rejects trailing text");
}

void testCrypto() {
    check(Sha256::hexDigest("") == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "sha256 empty");
    check(Sha256::hexDigest("abc") == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", "sha256 abc");
    check(Sha256::hexDigest("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq") ==
              "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1",
          "sha256 two blocks");
    const auto mac = hmacSha256("Jefe", "what do ya want for nothing?");
    check(toHex(mac.data(), mac.size()) == "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843",
          "hmac-sha256 RFC 4231 case 2");
    const auto dk1 = pbkdf2HmacSha256("password", "salt", 1, 32);
    check(toHex(dk1.data(), dk1.size()) == "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b",
          "pbkdf2 c=1");
    const auto dk2 = pbkdf2HmacSha256("password", "salt", 4096, 32);
    check(toHex(dk2.data(), dk2.size()) == "c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a",
          "pbkdf2 c=4096");
    const std::string stored = PasswordHasher::hash("Student@123", 1000);
    check(PasswordHasher::verify("Student@123", stored), "password verify ok");
    check(!PasswordHasher::verify("student@123", stored), "password verify wrong");
    check(!PasswordHasher::verify("x", "garbage"), "password verify garbage hash");
    check(PasswordHasher::hash("same", 1000) != PasswordHasher::hash("same", 1000), "password salts differ");
    check(!PasswordHasher::strengthProblem("weak").empty(), "weak password rejected");
    check(PasswordHasher::strengthProblem("Strong@123").empty(), "strong password accepted");
    check(PasswordHasher::strengthProblem(PasswordHasher::generateTemporaryPassword()).empty(), "temp password is strong");
}

void testDates() {
    check(Date::parse("18-11-2026") == Date(2026, 11, 18), "date DD-MM-YYYY");
    check(Date::parse("2026-11-18") == Date(2026, 11, 18), "date ISO");
    check(Date::parse("2026-11-18T10:00:00+00:00") == Date(2026, 11, 18), "date from timestamp");
    check(Date(2026, 11, 18).weekday() == 3, "18-Nov-2026 is Wednesday");
    check(Date(2024, 2, 29).addDays(365) == Date(2025, 2, 28) && Date(2024, 2, 28).addDays(1) == Date(2024, 2, 29), "leap year arithmetic");
    check(!Date::isValid(2025, 2, 29) && Date::isValid(2024, 2, 29), "leap year validation");
    check(throws([] { Date::parse("31-04-2026"); }), "invalid date rejected");
    check(Date(2026, 1, 1) - Date(2025, 1, 1) == 365, "date difference");
    check(Date(2006, 11, 19).ageOn(Date(2026, 11, 18)) == 19, "age calculation");
    long long epoch = 0;
    check(DateTime::parseIso("2026-11-18T10:30:00.123+05:30", epoch) && epoch == 1794978000LL, "iso timestamp with offset");
    check(DateTime::parseHttpDate("Wed, 18 Nov 2026 05:00:00 GMT", epoch) && epoch == 1794978000LL, "http date header");
}

void testStringsAndValidation() {
    check(str::formatMoney(185000) == "Rs. 1,85,000.00", "indian money format");
    check(str::formatMoney(12345678.5) == "Rs. 1,23,45,678.50", "indian money crore");
    check(str::formatMoney(999) == "Rs. 999.00", "small money");
    check(str::urlEncode("a b@c,(1)") == "a%20b%40c%2C%281%29", "url encode");
    check(str::trim("  hi \r\n") == "hi", "trim");
    check(str::displayWidth("\033[92mOK\033[0m") == 2, "width ignores colour codes");
    check(Validator::isEmail("aarav.sharma26@student.example.edu") && !Validator::isEmail("bad@"), "email");
    check(Validator::isIndianMobile("+91 98765 00101") && !Validator::isIndianMobile("1234567890"), "mobile");
    check(Validator::isPrn("2024BTCS001") && !Validator::isPrn("24-01"), "prn");
    check(Validator::isAcademicYear("2026-27") && !Validator::isAcademicYear("2026-28"), "academic year");
    Student s;
    check(throws([&] { s.setSemester(9); }), "semester 9 rejected");
    check(throws([&] { s.setEmail("not-an-email"); }), "bad email rejected");
    s.setPrn("2024btcs001");
    check(s.prn() == "2024BTCS001", "prn upper-cased");
    s.setAdmissionYear(2024);
    s.setSemester(5);
    check(s.academicYearForSemester(1) == "2024-25" && s.academicYearForSemester(5) == "2026-27", "academic year per semester");
    check(s.yearLabel() == "Third Year", "year label");
}

void testCsvAndQuery() {
    const auto rows = Csv::parse("# comment\nprn,name\n\"2024BTCS001\",\"Sharma, Aarav \"\"AS\"\"\"\r\n\n2024BTCS002,Neha\n");
    check(rows.size() == 3, "csv rows (comment + blank skipped)");
    check(rows[1][1] == "Sharma, Aarav \"AS\"", "csv quoted field with comma and quotes");
    check(Csv::escape("a,b") == "\"a,b\"" && Csv::escape("plain") == "plain", "csv escape");
    const std::string q = Query().select("*,users(*)").eq("semester", 5).inText("audience", {"all", "students"}).order("prn").limit(10).build();
    check(q == "select=%2A%2Cusers%28%2A%29&semester=eq.5&audience=in.%28%22all%22%2C%22students%22%29&order=prn.asc&limit=10",
          "postgrest query string");
}

void testGrades() {
    check(GradeCalculator::grade(91, 45).letter == "O", "grade O");
    check(GradeCalculator::grade(89.5, 45).letter == "O", "89.5 rounds to O");
    check(GradeCalculator::grade(72, 30).letter == "A", "grade A");
    check(GradeCalculator::grade(40, 20).letter == "P", "grade P boundary");
    check(GradeCalculator::grade(39, 25).letter == "F", "below 40 fails");
    check(GradeCalculator::grade(65, 19.5).letter == "F", "end-sem below 20 fails");
    check(near(GradeCalculator::weightedAverage({{4, 10}, {3, 8}, {2, 9}}), 9.11), "weighted average");
    check(GradeCalculator::classification(8.1) == "First Class with Distinction", "classification");

    const std::vector<Course> courses = {makeCourse(1, 1, 4, "MA101"), makeCourse(2, 1, 3, "CS101"),
                                         makeCourse(3, 2, 4, "CS102")};
    const std::vector<MarkRecord> marks = {makeMarks(1, 18, 27, 46), makeMarks(2, 15, 20, 30),
                                           makeMarks(3, 12, 15, 0, false)};
    const Transcript t = TranscriptBuilder::build(courses, marks);
    check(t.semesters.size() == 2, "transcript semesters");
    check(t.semesters[0].declared && !t.semesters[1].declared, "declared only when complete");
    // MA101: 91 -> O(10) x4 ; CS101: 65 -> B+(7) x3  => (40+21)/7 = 8.71
    check(near(t.semesters[0].sgpa, 8.71), "sgpa");
    check(t.hasCgpa && near(t.cgpa, 8.71) && t.backlogs == 0, "cgpa + backlogs");
}

void testGuardianPlannerRisk() {
    check(AttendanceGuardian::classesNeeded(12, 20, 75) == 12, "need 12 classes: (12+12)/(20+12)=75%");
    check(AttendanceGuardian::classesNeeded(15, 20, 75) == 0, "exactly 75 needs none");
    check(AttendanceGuardian::classesCanMiss(18, 20, 75) == 4, "can miss 4: 18/24=75%");
    check(AttendanceGuardian::classesCanMiss(10, 20, 75) == 0, "cannot miss when short");

    check(GradeTargetPlanner::endsemNeeded(40, 10) == 49.5, "O needs 49.5 with 40 continuous (89.5 rounds to 90)");
    check(GradeTargetPlanner::endsemNeeded(30, 4) == 20.0, "pass needs at least 20 end-sem");
    check(!GradeTargetPlanner::endsemNeeded(10, 10).has_value(), "O impossible with 10 continuous");
    const std::vector<std::pair<Course, MarkRecord>> current = {
        {makeCourse(1, 5, 4, "CS302"), makeMarks(1, 18, 26, 0, false)},
        {makeCourse(2, 5, 3, "CS303"), makeMarks(2, 15, 20, 0, false)},
        {makeCourse(3, 5, 2, "CS351"), makeMarks(3, 19, 28, 0, false)}};
    const TargetPlan plan = GradeTargetPlanner::plan(current, 8.0);
    check(plan.achievable && plan.plannedSgpa >= 8.0, "target 8.0 achievable");
    bool allPlanned = true;
    for (const auto& row : plan.rows) allPlanned = allPlanned && row.requiredEndsem && *row.requiredEndsem <= 50;
    check(allPlanned, "every course gets an end-sem target");
    check(!GradeTargetPlanner::plan(current, 10.0).achievable, "10.0 not achievable");
    check(plan.maxPossibleSgpa >= plan.plannedSgpa, "max possible >= planned");

    RiskInput bad;
    bad.hasAttendance = true;
    bad.attendancePercent = 55;
    bad.hasMarks = true;
    bad.continuousPercent = 30;
    bad.backlogs = 2;
    bad.overdueFees = 5000;
    check(RiskAssessor::assess(bad, 75).level == "HIGH", "high risk");
    RiskInput good;
    good.hasAttendance = true;
    good.attendancePercent = 92;
    good.hasMarks = true;
    good.continuousPercent = 80;
    check(RiskAssessor::assess(good, 75).level == "LOW" && RiskAssessor::assess(good, 75).score == 0, "low risk");
}

void testDocumentsAndAudit() {
    check(DocumentService::normalizeCode("3f9a c21b-77d0") == "3F9A-C21B-77D0", "verification code normalised");
    check(DocumentService::normalizeCode("XYZ") == "", "bad verification code rejected");
    AuditEntry first;
    first.fill(1, "Admin", "LOGIN", "ok", "2026-11-18T10:00:00Z", AuditEntry::genesisHash());
    AuditEntry second;
    second.fill(1, "Admin", "MARKS_SAVED", "CS302", "2026-11-18T10:05:00Z", first.hash());
    check(second.prevHash() == first.hash() && second.recomputeHash() == second.hash(), "audit chain links");
    check(AuditEntry::computeHash(first.hash(), 1, "Admin", "MARKS_SAVED", "CS303", "2026-11-18T10:05:00Z") != second.hash(),
          "audit hash changes when details change");
}

int main() {
    std::cout << "Running ADYPU Student Portal unit tests...\n";
    testJson();
    testCrypto();
    testDates();
    testStringsAndValidation();
    testCsvAndQuery();
    testGrades();
    testGuardianPlannerRisk();
    testDocumentsAndAudit();
    std::cout << "\n  " << passed << " passed, " << failed << " failed\n";
    return failed == 0 ? 0 : 1;
}
