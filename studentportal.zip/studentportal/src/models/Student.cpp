#include "models/Student.hpp"

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

std::string Student::headline() const {
    return "B.Tech CSE | Semester " + std::to_string(semester_) + " (" + yearLabel() + ") | Division " + division_;
}

std::string Student::yearLabel() const {
    switch (yearOfStudy()) {
        case 1: return "First Year";
        case 2: return "Second Year";
        case 3: return "Third Year";
        default: return "Final Year";
    }
}

std::string Student::academicYearForSemester(int semester) const {
    const int start = admissionYear_ + (semester - 1) / 2;
    return std::to_string(start) + "-" + str::zeroPad((start + 1) % 100, 2);
}

void Student::printProfile(std::ostream& os) const {
    User::printProfile(os);  // reuse the base-class part, then extend it
    os << "  ---- Academic details ----\n";
    printField(os, "PRN", prn_);
    printField(os, "Program", "B.Tech Computer Science & Engineering");
    printField(os, "Semester", std::to_string(semester_) + " (" + yearLabel() + ")");
    printField(os, "Division", division_);
    printField(os, "Admission year", admissionYear_ ? std::to_string(admissionYear_) : "");
    printField(os, "Date of birth", dateOfBirth_.isEmpty() ? "" : dateOfBirth_.toDisplay());
    printField(os, "Gender", gender_);
    printField(os, "Guardian", guardianName_);
    printField(os, "Guardian mobile", guardianPhone_);
    printField(os, "Address", address_);
}

Json Student::toJson() const {
    auto optional = [](const std::string& v) { return v.empty() ? Json() : Json(v); };
    Json json = Json::object();
    if (id_ > 0) json["id"] = id_;
    json["prn"] = prn_;
    json["semester"] = semester_;
    json["division"] = division_;
    json["admission_year"] = admissionYear_;
    json["date_of_birth"] = dateOfBirth_.isEmpty() ? Json() : Json(dateOfBirth_.toIso());
    json["gender"] = optional(gender_);
    json["guardian_name"] = optional(guardianName_);
    json["guardian_phone"] = optional(guardianPhone_);
    json["address"] = optional(address_);
    return json;
}

Student Student::fromJson(const Json& row) {
    Student s;
    s.id_ = row.getInt("id");
    if (row["users"].isObject()) s.loadAccount(row["users"]);
    s.prn_ = row.getString("prn");
    s.semester_ = static_cast<int>(row.getInt("semester", 1));
    s.division_ = row.getString("division", "A");
    s.admissionYear_ = static_cast<int>(row.getInt("admission_year", 0));
    Date::tryParse(row.getString("date_of_birth"), s.dateOfBirth_);
    s.gender_ = row.getString("gender");
    s.guardianName_ = row.getString("guardian_name");
    s.guardianPhone_ = row.getString("guardian_phone");
    s.address_ = row.getString("address");
    return s;
}

void Student::setPrn(const std::string& prn) {
    const std::string value = str::toUpper(str::trim(prn));
    Validator::require(Validator::isPrn(value), "PRN must be 6-20 letters/digits (e.g. 2024BTCS001).");
    prn_ = value;
}

void Student::setSemester(int semester) {
    Validator::require(Validator::isSemester(semester), "Semester must be between 1 and 8.");
    semester_ = semester;
}

void Student::setDivision(const std::string& division) {
    const std::string value = str::toUpper(str::trim(division));
    Validator::require(Validator::isDivision(value), "Division must be a letter such as A, B or C.");
    division_ = value;
}

void Student::setAdmissionYear(int year) {
    const int current = Date::today().year();
    Validator::require(year >= 2000 && year <= current + 1,
                       "Admission year must be between 2000 and " + std::to_string(current + 1) + ".");
    admissionYear_ = year;
}

void Student::setDateOfBirth(const Date& dob) {
    if (!dob.isEmpty()) {
        const int age = dob.ageOn(Date::today());
        Validator::require(age >= 15 && age <= 60, "Date of birth looks wrong (age must be 15-60 years).");
    }
    dateOfBirth_ = dob;
}

void Student::setGender(const std::string& gender) {
    const std::string value = str::toLower(str::trim(gender));
    if (value.empty()) gender_.clear();
    else if (value == "m" || value == "male") gender_ = "Male";
    else if (value == "f" || value == "female") gender_ = "Female";
    else if (value == "o" || value == "other") gender_ = "Other";
    else throw ValidationException("Gender must be Male, Female or Other.");
}

void Student::setGuardianName(const std::string& name) {
    const std::string value = str::trim(name);
    Validator::require(value.empty() || Validator::isPersonName(value), "Guardian name contains invalid characters.");
    guardianName_ = value;
}

void Student::setGuardianPhone(const std::string& phone) {
    if (str::trim(phone).empty()) {
        guardianPhone_.clear();
        return;
    }
    Validator::require(Validator::isIndianMobile(phone), "Guardian mobile must have 10 digits and start with 6-9.");
    guardianPhone_ = Validator::normalizePhone(phone);
}

void Student::setAddress(const std::string& address) {
    const std::string value = str::trim(address);
    Validator::require(value.size() <= 200, "Address must be at most 200 characters.");
    address_ = value;
}

}  // namespace portal
