#include "models/Admin.hpp"

namespace portal {

void Admin::printProfile(std::ostream& os) const {
    User::printProfile(os);
    os << "  ---- Permissions ----\n";
    printField(os, "Access level", "Full access (students, faculty, courses, fees, reports)");
}

Admin Admin::fromJson(const Json& row) {
    Admin admin;
    admin.loadAccount(row);
    return admin;
}

}  // namespace portal
