#include "models/Faculty.hpp"

#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

std::string Faculty::headline() const { return designation_ + " | Dept. of Computer Science & Engineering"; }

void Faculty::printProfile(std::ostream& os) const {
    User::printProfile(os);
    os << "  ---- Faculty details ----\n";
    printField(os, "Employee code", employeeCode_);
    printField(os, "Designation", designation_);
    printField(os, "Qualification", qualification_);
    printField(os, "Specialization", specialization_);
    printField(os, "Joining date", joiningDate_.isEmpty() ? "" : joiningDate_.toDisplay());
}

Json Faculty::toJson() const {
    auto optional = [](const std::string& v) { return v.empty() ? Json() : Json(v); };
    Json json = Json::object();
    if (id_ > 0) json["id"] = id_;
    json["employee_code"] = employeeCode_;
    json["designation"] = designation_;
    json["qualification"] = optional(qualification_);
    json["specialization"] = optional(specialization_);
    json["joining_date"] = joiningDate_.isEmpty() ? Json() : Json(joiningDate_.toIso());
    return json;
}

Faculty Faculty::fromJson(const Json& row) {
    Faculty f;
    f.id_ = row.getInt("id");
    if (row["users"].isObject()) f.loadAccount(row["users"]);
    f.employeeCode_ = row.getString("employee_code");
    f.designation_ = row.getString("designation", "Assistant Professor");
    f.qualification_ = row.getString("qualification");
    f.specialization_ = row.getString("specialization");
    Date::tryParse(row.getString("joining_date"), f.joiningDate_);
    return f;
}

void Faculty::setEmployeeCode(const std::string& code) {
    const std::string value = str::toUpper(str::trim(code));
    Validator::require(Validator::isPrn(value) || (value.size() >= 3 && Validator::isPrn(value + "000")),
                       "Employee code must be 3-20 letters/digits (e.g. FAC001).");
    employeeCode_ = value;
}

void Faculty::setDesignation(const std::string& designation) {
    const std::string value = str::trim(designation);
    Validator::require(!value.empty() && value.size() <= 60, "Designation is required (max 60 characters).");
    designation_ = value;
}

void Faculty::setQualification(const std::string& qualification) {
    const std::string value = str::trim(qualification);
    Validator::require(value.size() <= 80, "Qualification must be at most 80 characters.");
    qualification_ = value;
}

void Faculty::setSpecialization(const std::string& specialization) {
    const std::string value = str::trim(specialization);
    Validator::require(value.size() <= 80, "Specialization must be at most 80 characters.");
    specialization_ = value;
}

void Faculty::setJoiningDate(const Date& date) {
    Validator::require(date.isEmpty() || date <= Date::today(), "Joining date cannot be in the future.");
    joiningDate_ = date;
}

}  // namespace portal
