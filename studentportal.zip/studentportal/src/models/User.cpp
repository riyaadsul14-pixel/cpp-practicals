#include "models/User.hpp"

#include "core/Date.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

std::string roleToString(Role role) {
    switch (role) {
        case Role::Admin: return "admin";
        case Role::Faculty: return "faculty";
        case Role::Student: return "student";
    }
    return "student";
}

std::string roleTitle(Role role) {
    switch (role) {
        case Role::Admin: return "Administrator";
        case Role::Faculty: return "Faculty";
        case Role::Student: return "Student";
    }
    return "Student";
}

Role roleFromString(const std::string& text) {
    const std::string value = str::toLower(str::trim(text));
    if (value == "admin") return Role::Admin;
    if (value == "faculty") return Role::Faculty;
    if (value == "student") return Role::Student;
    throw ValidationException("Unknown role: " + text);
}

void User::setUsername(const std::string& username) {
    const std::string value = str::toLower(str::trim(username));
    Validator::require(Validator::isUsername(value),
                       "Username must be 3-30 characters: letters, digits, '.', '_' or '-'.");
    username_ = value;
}

void User::setFullName(const std::string& name) {
    const std::string value = str::trim(name);
    Validator::require(Validator::isPersonName(value),
                       "Name must be 2-80 characters (letters, spaces, '.', '-' and apostrophes).");
    fullName_ = value;
}

void User::setEmail(const std::string& email) {
    const std::string value = str::toLower(str::trim(email));
    Validator::require(Validator::isEmail(value), "Please enter a valid email address.");
    email_ = value;
}

void User::setPhone(const std::string& phone) {
    if (str::trim(phone).empty()) {
        phone_.clear();
        return;
    }
    Validator::require(Validator::isIndianMobile(phone), "Mobile number must have 10 digits and start with 6-9.");
    phone_ = Validator::normalizePhone(phone);
}

Json User::accountJson(bool includePasswordHash) const {
    Json json = Json::object();
    json["username"] = username_;
    json["role"] = roleToString(role());
    json["full_name"] = fullName_;
    json["email"] = email_;
    json["phone"] = phone_.empty() ? Json() : Json(phone_);
    json["is_active"] = active_;
    json["must_change_password"] = mustChangePassword_;
    if (includePasswordHash) json["password_hash"] = passwordHash_;
    return json;
}

void User::loadAccount(const Json& row) {
    if (id_ == 0) id_ = row.getInt("id");
    username_ = row.getString("username");
    passwordHash_ = row.getString("password_hash");
    fullName_ = row.getString("full_name");
    email_ = row.getString("email");
    phone_ = row.getString("phone");
    active_ = row.getBool("is_active", true);
    mustChangePassword_ = row.getBool("must_change_password", false);
    failedLogins_ = static_cast<int>(row.getInt("failed_logins", 0));
    lockedUntil_ = row.getInt("locked_until", 0);
    lastLoginAt_ = row.getString("last_login_at");
    createdAt_ = row.getString("created_at");
}

void User::printField(std::ostream& os, const std::string& label, const std::string& value) {
    os << "  " << str::padRight(label, 18) << ": " << (value.empty() ? "-" : value) << '\n';
}

void User::printProfile(std::ostream& os) const {
    printField(os, "Name", fullName_);
    printField(os, "Role", roleTitle(role()));
    printField(os, "Username", username_);
    printField(os, "Email", email_);
    printField(os, "Mobile", phone_);
    printField(os, "Account status", active_ ? "Active" : "Deactivated");
    printField(os, "Last login", DateTime::formatIsoAsLocal(lastLoginAt_));
}

}  // namespace portal
