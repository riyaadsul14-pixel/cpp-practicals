#include "models/Academic.hpp"

#include <algorithm>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

namespace {
Json optionalNumber(const std::optional<double>& value) { return value ? Json(*value) : Json(); }

std::optional<double> readOptional(const Json& row, const std::string& key) {
    if (row.isNullOrMissing(key)) return std::nullopt;
    return row.getDouble(key);
}
}  // namespace

// ------------------------------------------------------------------ Course --
const std::vector<std::string>& Course::types() {
    static const std::vector<std::string> values = {"Theory", "Lab", "Elective", "Project"};
    return values;
}

Json Course::toJson() const {
    Json json = Json::object();
    json["code"] = code_;
    json["name"] = name_;
    json["semester"] = semester_;
    json["credits"] = credits_;
    json["course_type"] = type_;
    json["faculty_id"] = facultyId_ > 0 ? Json(facultyId_) : Json();
    return json;
}

Course Course::fromJson(const Json& row) {
    Course c;
    c.id_ = row.getInt("id");
    c.code_ = row.getString("code");
    c.name_ = row.getString("name");
    c.semester_ = static_cast<int>(row.getInt("semester", 1));
    c.credits_ = static_cast<int>(row.getInt("credits", 3));
    c.type_ = row.getString("course_type", "Theory");
    c.facultyId_ = row.getInt("faculty_id", 0);
    return c;
}

void Course::setCode(const std::string& code) {
    const std::string value = str::toUpper(str::trim(code));
    Validator::require(Validator::isCourseCode(value), "Course code must look like CS301 (3-12 letters/digits).");
    code_ = value;
}

void Course::setName(const std::string& name) {
    const std::string value = str::trim(name);
    Validator::require(value.size() >= 3 && value.size() <= 100, "Course name must be 3-100 characters.");
    name_ = value;
}

void Course::setSemester(int semester) {
    Validator::require(Validator::isSemester(semester), "Semester must be between 1 and 8.");
    semester_ = semester;
}

void Course::setCredits(int credits) {
    Validator::require(credits >= 1 && credits <= 10, "Credits must be between 1 and 10.");
    credits_ = credits;
}

void Course::setType(const std::string& type) {
    for (const auto& allowed : types()) {
        if (str::equalsIgnoreCase(allowed, str::trim(type))) {
            type_ = allowed;
            return;
        }
    }
    throw ValidationException("Course type must be Theory, Lab, Elective or Project.");
}

// -------------------------------------------------------------- Enrollment --
Json Enrollment::toJson() const {
    Json json = Json::object();
    json["student_id"] = studentId_;
    json["course_id"] = courseId_;
    json["academic_year"] = academicYear_;
    return json;
}

Enrollment Enrollment::fromJson(const Json& row) {
    Enrollment e(row.getInt("student_id"), row.getInt("course_id"), row.getString("academic_year"));
    e.id_ = row.getInt("id");
    return e;
}

// -------------------------------------------------------- AttendanceRecord --
Json AttendanceRecord::toJson() const {
    Json json = Json::object();
    json["course_id"] = courseId_;
    json["student_id"] = studentId_;
    json["class_date"] = classDate_.toIso();
    json["is_present"] = present_;
    json["marked_by"] = markedBy_ > 0 ? Json(markedBy_) : Json();
    return json;
}

AttendanceRecord AttendanceRecord::fromJson(const Json& row) {
    AttendanceRecord r;
    r.id_ = row.getInt("id");
    r.courseId_ = row.getInt("course_id");
    r.studentId_ = row.getInt("student_id");
    Date::tryParse(row.getString("class_date"), r.classDate_);
    r.present_ = row.getBool("is_present");
    r.markedBy_ = row.getInt("marked_by", 0);
    return r;
}

// ------------------------------------------------------------- MarkRecord --
std::string componentLabel(ExamComponent component) {
    switch (component) {
        case ExamComponent::Internal: return "Internal / CA";
        case ExamComponent::MidSem: return "Mid-Semester";
        case ExamComponent::EndSem: return "End-Semester";
    }
    return "";
}

std::string componentColumn(ExamComponent component) {
    switch (component) {
        case ExamComponent::Internal: return "internal_marks";
        case ExamComponent::MidSem: return "midsem_marks";
        case ExamComponent::EndSem: return "endsem_marks";
    }
    return "";
}

double componentMax(ExamComponent component) {
    switch (component) {
        case ExamComponent::Internal: return 20.0;
        case ExamComponent::MidSem: return 30.0;
        case ExamComponent::EndSem: return 50.0;
    }
    return 0.0;
}

Json MarkRecord::toJson() const {
    Json json = Json::object();
    json["student_id"] = studentId_;
    json["course_id"] = courseId_;
    json["internal_marks"] = optionalNumber(internal_);
    json["midsem_marks"] = optionalNumber(midsem_);
    json["endsem_marks"] = optionalNumber(endsem_);
    return json;
}

MarkRecord MarkRecord::fromJson(const Json& row) {
    MarkRecord m;
    m.id_ = row.getInt("id");
    m.studentId_ = row.getInt("student_id");
    m.courseId_ = row.getInt("course_id");
    m.internal_ = readOptional(row, "internal_marks");
    m.midsem_ = readOptional(row, "midsem_marks");
    m.endsem_ = readOptional(row, "endsem_marks");
    return m;
}

std::optional<double> MarkRecord::get(ExamComponent component) const {
    switch (component) {
        case ExamComponent::Internal: return internal_;
        case ExamComponent::MidSem: return midsem_;
        case ExamComponent::EndSem: return endsem_;
    }
    return std::nullopt;
}

void MarkRecord::set(ExamComponent component, std::optional<double> value) {
    if (value) {
        Validator::require(*value >= 0 && *value <= componentMax(component),
                           componentLabel(component) + " marks must be between 0 and " +
                               str::formatFixed(componentMax(component), 0) + ".");
    }
    switch (component) {
        case ExamComponent::Internal: internal_ = value; break;
        case ExamComponent::MidSem: midsem_ = value; break;
        case ExamComponent::EndSem: endsem_ = value; break;
    }
}

double MarkRecord::total() const { return internal_.value_or(0) + midsem_.value_or(0) + endsem_.value_or(0); }

double MarkRecord::continuousTotal() const { return internal_.value_or(0) + midsem_.value_or(0); }

}  // namespace portal
