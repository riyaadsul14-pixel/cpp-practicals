#include "models/Campus.hpp"

#include "core/Crypto.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

namespace {
Json optionalText(const std::string& v) { return v.empty() ? Json() : Json(v); }
Json optionalId(long long id) { return id > 0 ? Json(id) : Json(); }
}  // namespace

// ------------------------------------------------------------------ Notice --
Json Notice::toJson() const {
    Json json = Json::object();
    json["title"] = title_;
    json["body"] = body_;
    json["audience"] = audience_;
    json["posted_by"] = optionalId(postedBy_);
    return json;
}

Notice Notice::fromJson(const Json& row) {
    Notice n;
    n.id_ = row.getInt("id");
    n.title_ = row.getString("title");
    n.body_ = row.getString("body");
    n.audience_ = row.getString("audience", "all");
    n.postedBy_ = row.getInt("posted_by", 0);
    n.postedByName_ = row["users"].getString("full_name", "Portal");
    n.createdAt_ = row.getString("created_at");
    return n;
}

void Notice::setTitle(const std::string& title) {
    const std::string value = str::trim(title);
    Validator::require(value.size() >= 3 && value.size() <= 150, "Title must be 3-150 characters.");
    title_ = value;
}

void Notice::setBody(const std::string& body) {
    const std::string value = str::trim(body);
    Validator::require(!value.empty() && value.size() <= 2000, "Notice text must be 1-2000 characters.");
    body_ = value;
}

void Notice::setAudience(const std::string& audience) {
    const std::string value = str::toLower(str::trim(audience));
    Validator::require(value == "all" || value == "students" || value == "faculty",
                       "Audience must be all, students or faculty.");
    audience_ = value;
}

// -------------------------------------------------------------- FeeAccount --
Json FeeAccount::toJson() const {
    Json json = Json::object();
    json["student_id"] = studentId_;
    json["academic_year"] = academicYear_;
    json["description"] = description_;
    json["amount"] = amount_;
    json["due_date"] = dueDate_.toIso();
    return json;
}

FeeAccount FeeAccount::fromJson(const Json& row) {
    FeeAccount f;
    f.id_ = row.getInt("id");
    f.studentId_ = row.getInt("student_id");
    f.academicYear_ = row.getString("academic_year");
    f.description_ = row.getString("description");
    f.amount_ = row.getDouble("amount");
    Date::tryParse(row.getString("due_date"), f.dueDate_);
    return f;
}

void FeeAccount::setAcademicYear(const std::string& year) {
    Validator::require(Validator::isAcademicYear(str::trim(year)), "Academic year must look like 2026-27.");
    academicYear_ = str::trim(year);
}

void FeeAccount::setDescription(const std::string& description) {
    const std::string value = str::trim(description);
    Validator::require(value.size() >= 3 && value.size() <= 80, "Fee description must be 3-80 characters.");
    description_ = value;
}

void FeeAccount::setAmount(double amount) {
    Validator::require(amount > 0 && amount <= 10000000, "Fee amount must be between 1 and 1,00,00,000.");
    amount_ = amount;
}

// ----------------------------------------------------------------- Payment --
const std::vector<std::string>& Payment::modes() {
    static const std::vector<std::string> values = {"UPI", "Card", "NetBanking", "Cash", "Cheque", "DD"};
    return values;
}

Json Payment::toJson() const {
    Json json = Json::object();
    json["fee_id"] = feeId_;
    json["student_id"] = studentId_;
    json["amount"] = amount_;
    json["mode"] = mode_;
    json["reference"] = optionalText(reference_);
    json["paid_on"] = paidOn_.toIso();
    json["recorded_by"] = optionalId(recordedBy_);
    return json;
}

Payment Payment::fromJson(const Json& row) {
    Payment p;
    p.id_ = row.getInt("id");
    p.feeId_ = row.getInt("fee_id");
    p.studentId_ = row.getInt("student_id");
    p.amount_ = row.getDouble("amount");
    p.mode_ = row.getString("mode");
    p.reference_ = row.getString("reference");
    Date::tryParse(row.getString("paid_on"), p.paidOn_);
    p.recordedBy_ = row.getInt("recorded_by", 0);
    return p;
}

std::string Payment::receiptNumber() const {
    return "ADYPU/FEE/" + std::to_string(paidOn_.isEmpty() ? 0 : paidOn_.year()) + "/" + str::zeroPad(id_, 6);
}

void Payment::setAmount(double amount) {
    Validator::require(amount > 0, "Payment amount must be greater than zero.");
    amount_ = amount;
}

void Payment::setMode(const std::string& mode) {
    for (const auto& allowed : modes()) {
        if (str::equalsIgnoreCase(allowed, str::trim(mode))) {
            mode_ = allowed;
            return;
        }
    }
    throw ValidationException("Payment mode must be one of: " + str::join(modes(), ", "));
}

void Payment::setReference(const std::string& reference) {
    const std::string value = str::trim(reference);
    Validator::require(value.size() <= 60, "Reference must be at most 60 characters.");
    reference_ = value;
}

void Payment::setPaidOn(const Date& date) {
    Validator::require(!date.isEmpty() && date <= Date::today(), "Payment date cannot be in the future.");
    paidOn_ = date;
}

// ---------------------------------------------------------- DocumentRecord --
Json DocumentRecord::toJson() const {
    Json json = Json::object();
    json["student_id"] = studentId_;
    json["doc_type"] = docType_;
    json["purpose"] = purpose_;
    json["status"] = status_;
    return json;
}

DocumentRecord DocumentRecord::fromJson(const Json& row) {
    DocumentRecord d;
    d.id_ = row.getInt("id");
    d.studentId_ = row.getInt("student_id");
    d.docType_ = row.getString("doc_type", "bonafide");
    d.purpose_ = row.getString("purpose");
    d.status_ = row.getString("status", "pending");
    d.verificationCode_ = row.getString("verification_code");
    d.contentDigest_ = row.getString("content_digest");
    Date::tryParse(row.getString("issued_on"), d.issuedOn_);
    d.remarks_ = row.getString("remarks");
    d.requestedAt_ = row.getString("requested_at");
    return d;
}

void DocumentRecord::setDocType(const std::string& type) {
    Validator::require(type == "bonafide" || type == "report_card", "Unknown document type.");
    docType_ = type;
}

void DocumentRecord::setPurpose(const std::string& purpose) {
    const std::string value = str::trim(purpose);
    Validator::require(value.size() >= 3 && value.size() <= 120, "Purpose must be 3-120 characters.");
    purpose_ = value;
}

// -------------------------------------------------------------- AuditEntry --
const std::string& AuditEntry::genesisHash() {
    static const std::string zeros(64, '0');
    return zeros;
}

std::string AuditEntry::computeHash(const std::string& prevHash, long long actorId, const std::string& actorName,
                                    const std::string& action, const std::string& details,
                                    const std::string& createdAt) {
    return Sha256::hexDigest(prevHash + "|" + std::to_string(actorId) + "|" + actorName + "|" + action + "|" +
                             details + "|" + createdAt);
}

std::string AuditEntry::recomputeHash() const {
    return computeHash(prevHash_, actorId_, actorName_, action_, details_, createdAt_);
}

void AuditEntry::fill(long long actorId, const std::string& actorName, const std::string& action,
                      const std::string& details, const std::string& createdAt, const std::string& prevHash) {
    actorId_ = actorId;
    actorName_ = actorName;
    action_ = action;
    details_ = details;
    createdAt_ = createdAt;
    prevHash_ = prevHash;
    hash_ = recomputeHash();
}

Json AuditEntry::toJson() const {
    Json json = Json::object();
    json["actor_id"] = actorId_;
    json["actor_name"] = actorName_;
    json["action"] = action_;
    json["details"] = details_;
    json["created_at"] = createdAt_;
    json["prev_hash"] = prevHash_;
    json["hash"] = hash_;
    return json;
}

AuditEntry AuditEntry::fromJson(const Json& row) {
    AuditEntry e;
    e.id_ = row.getInt("id");
    e.actorId_ = row.getInt("actor_id");
    e.actorName_ = row.getString("actor_name");
    e.action_ = row.getString("action");
    e.details_ = row.getString("details");
    e.createdAt_ = row.getString("created_at");
    e.prevHash_ = row.getString("prev_hash");
    e.hash_ = row.getString("hash");
    return e;
}

}  // namespace portal
