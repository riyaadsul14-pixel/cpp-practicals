#include "app/PortalContext.hpp"

namespace portal {

PortalContext::PortalContext(const Config& config)
    : config_(config),
      profile_(UniversityProfile::fromConfig(config_)),
      db_(config_.require("SUPABASE_URL"), config_.require("SUPABASE_KEY"),
          HttpClient::createDefault(config_.getInt("HTTP_TIMEOUT_SECONDS", 25))),
      audit_(db_),
      users_(db_, audit_),
      auth_(db_, users_, audit_),
      academic_(db_, users_, audit_, profile_.academicYear()),
      attendance_(db_, academic_, audit_),
      results_(db_, academic_, audit_),
      notices_(db_, audit_),
      fees_(db_, users_, audit_),
      documents_(db_, users_, audit_, profile_),
      reports_(db_, users_, academic_, attendance_, results_, fees_, documents_, profile_) {}

const std::vector<std::string>& PortalContext::requiredTables() {
    static const std::vector<std::string> tables = {"users",   "students", "faculty",      "courses",   "enrollments",
                                                    "attendance", "marks", "notices",      "fees",      "fee_payments",
                                                    "documents",  "audit_log"};
    return tables;
}

std::vector<std::string> PortalContext::missingTables() const {
    std::vector<std::string> missing;
    for (const auto& table : requiredTables()) {
        if (!db_.tableExists(table)) missing.push_back(table);
    }
    return missing;
}

}  // namespace portal
