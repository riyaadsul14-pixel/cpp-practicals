#include "app/DataSeeder.hpp"

#include <algorithm>
#include <cmath>
#include <map>
#include <random>

#include "core/Crypto.hpp"
#include "core/Csv.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"

namespace portal {

namespace {

constexpr const char* kAdminPassword = "Admin@123";
constexpr const char* kFacultyPassword = "Faculty@123";
constexpr const char* kStudentPassword = "Student@123";

/// Stable pseudo-random number in [0,1) derived from a text key (same data on every run).
double stableUnit(const std::string& key) {
    const auto d = Sha256::digest(key);
    const unsigned value = (static_cast<unsigned>(d[0]) << 16) | (static_cast<unsigned>(d[1]) << 8) | d[2];
    return value / 16777216.0;
}

double toHalf(double v) { return std::round(v * 2.0) / 2.0; }

double clampMarks(double v, double low, double high) { return std::min(high, std::max(low, toHalf(v))); }

Date clampToToday(const Date& d) { return std::min(d, Date::today()); }

}  // namespace

bool DataSeeder::isDatabaseEmpty() const { return ctx_.db().count(User::ACCOUNT_TABLE) == 0; }

void DataSeeder::wipeAllData() {
    // children first so foreign keys never block a delete
    const std::vector<std::string> order = {"documents", "audit_log", "fee_payments", "fees",    "marks",   "attendance",
                                            "enrollments", "notices", "courses",      "students", "faculty", "users"};
    for (const auto& table : order) {
        const std::size_t removed = ctx_.db().remove(table, Query().gt("id", 0));
        log_ << "  cleared " << str::padRight(table, 14) << removed << " row(s)\n";
    }
}

void DataSeeder::seed() {
    auto& db = ctx_.db();
    const auto& profile = ctx_.profile();
    const auto dataDir = profile.dataDir();
    const int ayStart = profile.academicYearStart();
    const Date today = Date::today();

    // ---------------------------------------------------------------- admin --
    log_ << "  [1/9] Administrator account\n";
    Admin admin;
    admin.setUsername("admin");
    admin.setFullName("Portal Administrator");
    admin.setEmail("admin@adypu-portal.example.edu");
    admin = ctx_.users().createAdmin(admin, kAdminPassword);

    // -------------------------------------------------------------- faculty --
    log_ << "  [2/9] Faculty (data/faculty.csv)\n";
    std::map<std::string, long long> facultyIdByCode;
    std::vector<Faculty> facultyList;
    for (const auto& r : Csv::readRecords(dataDir / "faculty.csv")) {
        Faculty f;
        f.setEmployeeCode(r.get("employee_code"));
        f.setFullName(r.get("full_name"));
        f.setEmail(r.get("email"));
        f.setPhone(r.get("phone"));
        f.setDesignation(r.get("designation"));
        f.setQualification(r.get("qualification"));
        f.setSpecialization(r.get("specialization"));
        if (!r.get("joining_date").empty()) f.setJoiningDate(Date::parse(r.get("joining_date")));
        const Faculty created = ctx_.users().createFaculty(f, kFacultyPassword, false, admin);
        facultyIdByCode[created.employeeCode()] = created.id();
        facultyList.push_back(created);
    }

    // -------------------------------------------------------------- courses --
    log_ << "  [3/9] Curriculum (data/courses.csv)\n";
    Json courseRows = Json::array();
    for (const auto& r : Csv::readRecords(dataDir / "courses.csv")) {
        Course c;
        c.setCode(r.get("code"));
        c.setName(r.get("name"));
        long long semester = 0, credits = 0;
        str::parseInt(r.get("semester"), semester);
        str::parseInt(r.get("credits"), credits);
        c.setSemester(static_cast<int>(semester));
        c.setCredits(static_cast<int>(credits));
        c.setType(r.get("course_type"));
        const auto f = facultyIdByCode.find(str::toUpper(r.get("faculty_code")));
        if (f != facultyIdByCode.end()) c.setFacultyId(f->second);
        courseRows.push(c.toJson());
    }
    std::vector<Course> courses;
    const Json insertedCourses = db.insert(Course::TABLE, courseRows);
    for (const auto& row : insertedCourses.items()) courses.push_back(Course::fromJson(row));

    // ------------------------------------------------------------- students --
    log_ << "  [4/9] Students (data/students.csv)\n";
    std::vector<Student> parsed;
    for (const auto& r : Csv::readRecords(dataDir / "students.csv")) parsed.push_back(UserService::studentFromRecord(r));
    const ImportResult imported = ctx_.users().createStudents(parsed, kStudentPassword, false, &admin);
    for (const auto& e : imported.errors) log_ << "      ! " << e << "\n";
    const auto students = ctx_.users().listStudents();

    // ---------------------------------------------------------- enrollments --
    log_ << "  [5/9] Enrollments (all courses up to the current semester)\n";
    Json enrollRows = Json::array();
    for (const auto& s : students) {
        for (const auto& c : courses) {
            if (c.semester() > s.semester()) continue;
            enrollRows.push(Enrollment(s.id(), c.id(), s.academicYearForSemester(c.semester())).toJson());
        }
    }
    db.insert(Enrollment::TABLE, enrollRows, "id");

    // ---------------------------------------------------------------- marks --
    log_ << "  [6/9] Marks (completed semesters + current internal/mid-sem)\n";
    std::mt19937 rng(20262027u);
    std::normal_distribution<double> noise(0.0, 0.08);
    Json markRows = Json::array();
    for (const auto& s : students) {
        const double ability = 0.56 + 0.40 * stableUnit("ability|" + s.prn());
        for (const auto& c : courses) {
            if (c.semester() > s.semester()) continue;
            MarkRecord m;
            m.setStudentId(s.id());
            m.setCourseId(c.id());
            m.set(ExamComponent::Internal, clampMarks(20 * (ability + 0.08 + noise(rng)), 6, 20));
            m.set(ExamComponent::MidSem, clampMarks(30 * (ability + noise(rng)), 6, 30));
            if (c.semester() < s.semester()) {
                m.set(ExamComponent::EndSem, clampMarks(50 * (ability + 0.7 * noise(rng)), 14, 50));
            }
            markRows.push(m.toJson());
        }
    }
    db.insert(MarkRecord::TABLE, markRows, "id");

    // ----------------------------------------------------------- attendance --
    log_ << "  [7/9] Attendance (last 8 weeks of the current semester)\n";
    Json attendanceRows = Json::array();
    std::uniform_real_distribution<double> unit(0.0, 1.0);
    std::map<int, int> courseIndexInSemester;
    for (const auto& c : courses) {
        const int index = courseIndexInSemester[c.semester()]++;
        const bool mwf = index % 2 == 0;  // Mon/Wed/Fri or Tue/Thu timetable
        for (Date d = today.addDays(-56); d < today; d = d.addDays(1)) {
            const int w = d.weekday();
            if (w == 0 || w == 6 || (mwf ? (w % 2 == 0) : (w % 2 == 1))) continue;
            for (const auto& s : students) {
                if (s.semester() != c.semester()) continue;
                const double rate = 0.58 + 0.41 * stableUnit("attendance|" + s.prn());
                const AttendanceRecord r(c.id(), s.id(), d, unit(rng) < rate, c.facultyId());
                attendanceRows.push(r.toJson());
            }
        }
    }
    db.insert(AttendanceRecord::TABLE, attendanceRows, "id");

    // ----------------------------------------------------------------- fees --
    log_ << "  [8/9] Fees and payments (" << profile.academicYear() << ")\n";
    Json feeRows = Json::array();
    for (const auto& s : students) {
        FeeAccount tuition;
        tuition.setStudentId(s.id());
        tuition.setAcademicYear(profile.academicYear());
        tuition.setDescription("Tuition Fee");
        tuition.setAmount(185000);
        tuition.setDueDate(Date(ayStart, 8, 31));
        feeRows.push(tuition.toJson());
        FeeAccount exam = tuition;
        exam.setDescription("Examination Fee");
        exam.setAmount(3500);
        exam.setDueDate(Date(ayStart, 11, 30));
        feeRows.push(exam.toJson());
    }
    std::vector<FeeAccount> fees;
    const Json insertedFees = db.insert(FeeAccount::TABLE, feeRows);
    for (const auto& row : insertedFees.items()) fees.push_back(FeeAccount::fromJson(row));
    Json paymentRows = Json::array();
    int index = 0;
    for (const auto& s : students) {
        const int pattern = index++ % 10;
        for (const auto& f : fees) {
            if (f.studentId() != s.id()) continue;
            auto pay = [&](double amount, const Date& on, const std::string& mode, const std::string& ref) {
                Payment p;
                p.setFeeId(f.id());
                p.setStudentId(s.id());
                p.setAmount(amount);
                p.setMode(mode);
                p.setReference(ref);
                p.setPaidOn(clampToToday(on));
                p.setRecordedBy(admin.id());
                paymentRows.push(p.toJson());
            };
            if (f.description() == "Tuition Fee") {
                if (pattern <= 7) pay(100000, Date(ayStart, 7, 10), "NetBanking", "NB" + s.prn());
                if (pattern <= 5) pay(85000, Date(ayStart, 8, 25), "UPI", "UPI" + s.prn());
            } else if (pattern % 3 == 0) {
                pay(3500, Date(ayStart, 11, 5), "UPI", "EX" + s.prn());
            }
        }
    }
    db.insert(Payment::TABLE, paymentRows, "id");

    // ------------------------------------------------- notices + documents --
    log_ << "  [9/9] Notices, a pending bonafide request and the audit trail\n";
    const Faculty& hod = facultyList.front();
    ctx_.notices().post("End-Semester Examination Timetable - Nov/Dec " + std::to_string(ayStart),
                         "End-semester theory examinations for all B.Tech CSE semesters begin on 1st December. "
                         "Seat numbers and hall tickets will be available in the department office from 25th November.",
                         "all", admin);
    ctx_.notices().post("Examination fee - last date 30th November",
                        "Students who have not paid the examination fee of Rs. 3,500 must pay it before 30th November "
                        "to receive their hall ticket.",
                        "students", admin);
    ctx_.notices().post("Minimum 75% attendance is mandatory",
                        "As per university rules, students below 75% attendance in any course will not be eligible "
                        "for the end-semester examination of that course. Check 'My attendance' for your status.",
                        "students", hod);
    ctx_.notices().post("CSE Hackathon 'CodeQuest " + std::to_string(ayStart) + "' - registrations open",
                        "Teams of 2-4 students can register with their class coordinator. Problem statements will "
                        "be released on the day of the event.",
                        "students", hod);
    ctx_.notices().post("Course file submission",
                        "All faculty members are requested to submit updated course files (lesson plan, attendance, "
                        "internal assessment) to the HoD office by 28th November.",
                        "faculty", admin);
    for (const auto& s : students) {
        if (s.semester() == 5) {
            ctx_.documents().requestBonafide(s, "Education loan application");
            break;
        }
    }
    ctx_.audit().record(admin, "DEMO_DATA_SEEDED",
                        std::to_string(students.size()) + " students, " + std::to_string(facultyList.size()) +
                            " faculty, " + std::to_string(courses.size()) + " courses");

    log_ << "\n  Seeded: " << students.size() << " students, " << facultyList.size() << " faculty, " << courses.size()
         << " courses, " << enrollRows.size() << " enrollments,\n          " << markRows.size() << " mark rows, "
         << attendanceRows.size() << " attendance rows, " << fees.size() << " fee items, " << paymentRows.size()
         << " payments.\n";
    log_ << "\n  Demo logins:  admin / " << kAdminPassword << "   |   fac001 / " << kFacultyPassword
         << "   |   <prn in lower case> / " << kStudentPassword << " (e.g. 2024btcs001)\n";
}

}  // namespace portal
