#include "app/UniversityProfile.hpp"

#include "core/Crypto.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

UniversityProfile UniversityProfile::fromConfig(const Config& config) {
    UniversityProfile p;
    p.name_ = config.get("UNIVERSITY_NAME", p.name_);
    p.shortName_ = config.get("UNIVERSITY_SHORT_NAME", p.shortName_);
    p.campus_ = config.get("UNIVERSITY_CAMPUS", p.campus_);
    p.school_ = config.get("SCHOOL", p.school_);
    p.department_ = config.get("DEPARTMENT", p.department_);
    p.program_ = config.get("PROGRAM", p.program_);
    p.website_ = config.get("UNIVERSITY_WEBSITE", p.website_);
    p.academicYear_ = config.get("ACADEMIC_YEAR", p.academicYear_);
    p.minAttendance_ = config.getDouble("MIN_ATTENDANCE_PERCENT", p.minAttendance_);
    p.exportDir_ = config.resolvePath("EXPORT_DIR", "exports");
    p.dataDir_ = config.resolvePath("DATA_DIR", "data");

    if (!Validator::isAcademicYear(p.academicYear_)) {
        throw ConfigException("ACADEMIC_YEAR must look like 2026-27 (found '" + p.academicYear_ + "')");
    }
    if (p.minAttendance_ <= 0 || p.minAttendance_ >= 100) {
        throw ConfigException("MIN_ATTENDANCE_PERCENT must be between 1 and 99");
    }
    // Secret used to sign certificates. Falls back to a value derived from the
    // Supabase key so verification codes stay stable for this installation.
    p.documentSecret_ = config.get("DOCUMENT_SECRET");
    if (p.documentSecret_.empty()) p.documentSecret_ = Sha256::hexDigest("adypu-docs|" + config.get("SUPABASE_KEY"));
    return p;
}

int UniversityProfile::academicYearStart() const {
    long long year = 0;
    str::parseInt(academicYear_.substr(0, 4), year);
    return static_cast<int>(year);
}

}  // namespace portal
