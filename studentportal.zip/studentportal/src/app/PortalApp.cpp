#include "app/PortalApp.hpp"

#include <filesystem>
#include <iostream>

#include "app/DataSeeder.hpp"
#include "app/PortalContext.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "ui/Console.hpp"
#include "ui/Dashboard.hpp"

namespace portal {

namespace fs = std::filesystem;

PortalApp::Options PortalApp::parseArguments(int argc, char** argv) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--config" && i + 1 < argc) o.configPath = argv[++i];
        else if (arg == "--check") o.check = true;
        else if (arg == "--seed") o.seed = true;
        else if (arg == "--reset-and-seed") o.resetAndSeed = true;
        else if (arg == "--version" || arg == "-v") o.version = true;
        else if (arg == "--help" || arg == "-h") o.help = true;
        else throw ConfigException("Unknown option: " + arg + "  (use --help)");
    }
    return o;
}

void PortalApp::printUsage() {
    std::cout << "ADYPU B.Tech CSE Student Portal " << kVersion << "\n\n"
              << "Usage: student_portal [options]\n"
              << "  (no option)        start the portal (login screen)\n"
              << "  --check            test the Supabase connection and the database tables\n"
              << "  --seed             load the sample ADYPU CSE data into an EMPTY database\n"
              << "  --reset-and-seed   DELETE all portal data, then load the sample data\n"
              << "  --config <file>    use another configuration file\n"
              << "  --version, --help\n";
}

int PortalApp::run(int argc, char** argv) {
    Console::init();
    try {
        const Options options = parseArguments(argc, argv);
        if (options.help) {
            printUsage();
            return 0;
        }
        if (options.version) {
            std::cout << "ADYPU Student Portal " << kVersion << '\n';
            return 0;
        }
        std::error_code ec;
        const fs::path exeDir = fs::absolute(fs::path(argv[0]), ec).parent_path();
        const Config config = Config::loadFile(Config::locate(options.configPath, exeDir));
        PortalContext ctx(config);

        if (options.check) return runCheck(ctx);
        if (!requireSchema(ctx)) return 2;
        if (options.seed || options.resetAndSeed) return runSeeder(ctx, options.resetAndSeed);
        ensureAdministrator(ctx);
        loginLoop(ctx);
        return 0;
    } catch (const InputClosedException&) {
        std::cout << "\nGoodbye!\n";
        return 0;
    } catch (const ConfigException& e) {
        Console::error(std::string("Configuration problem: ") + e.what());
        return 3;
    } catch (const NetworkException& e) {
        Console::error(std::string(e.what()) + "\n        Check your internet connection and SUPABASE_URL.");
        return 4;
    } catch (const std::exception& e) {
        Console::error(e.what());
        return 1;
    }
}

bool PortalApp::requireSchema(PortalContext& ctx) {
    const auto missing = ctx.missingTables();
    if (missing.empty()) return true;
    Console::error("The database is not set up yet. Missing table(s): " + str::join(missing, ", "));
    std::cout << "\n  One-time setup:\n"
              << "   1. Open https://supabase.com/dashboard -> your project -> SQL Editor -> New query\n"
              << "   2. Paste the contents of database/schema.sql and click RUN\n"
              << "   3. Run this program again (use --seed to load the sample data)\n";
    return false;
}

int PortalApp::runCheck(PortalContext& ctx) {
    Console::heading("Connection check");
    std::cout << "  Supabase project : " << ctx.db().projectUrl() << '\n'
              << "  HTTP backend     : " << ctx.db().backendName() << '\n'
              << "  Config file      : " << ctx.config().sourcePath().string() << '\n';
    int missing = 0;
    for (const auto& table : PortalContext::requiredTables()) {
        const bool ok = ctx.db().tableExists(table);
        if (!ok) ++missing;
        std::cout << "  " << str::padRight(table, 14) << (ok ? Console::paint("OK", Color::Green) : Console::paint("MISSING", Color::Red))
                  << (ok ? "  (" + std::to_string(ctx.db().count(table)) + " rows)" : "") << '\n';
    }
    if (missing) {
        Console::error(std::to_string(missing) + " table(s) missing - run database/schema.sql in the Supabase SQL Editor.");
        return 2;
    }
    Console::success("Supabase connection and database schema are OK.");
    return 0;
}

int PortalApp::runSeeder(PortalContext& ctx, bool reset) {
    DataSeeder seeder(ctx, std::cout);
    if (reset) {
        Console::warning("This deletes ALL students, faculty, marks, attendance, fees and documents.");
        if (str::toUpper(Console::readLine("Type RESET to continue: ")) != "RESET") {
            Console::info("Cancelled.");
            return 1;
        }
        Console::heading("Deleting existing data");
        seeder.wipeAllData();
    } else if (!seeder.isDatabaseEmpty()) {
        Console::error("The database already contains users. Use --reset-and-seed to replace everything.");
        return 1;
    }
    Console::heading("Loading sample data for " + ctx.profile().name());
    seeder.seed();
    Console::success("Sample data loaded.");
    return 0;
}

void PortalApp::ensureAdministrator(PortalContext& ctx) {
    if (ctx.users().countAdmins() > 0) return;
    Console::banner({ctx.profile().name(), "First-time setup: create the administrator account"});
    while (true) {
        try {
            Admin admin;
            admin.setUsername(Console::readRequired("Admin username: "));
            admin.setFullName(Console::readRequired("Full name: "));
            admin.setEmail(Console::readRequired("Email: "));
            const std::string password = Console::readPassword("Password: ");
            if (password != Console::readPassword("Confirm password: ")) throw ValidationException("Passwords do not match.");
            ctx.users().createAdmin(admin, password);
            Console::success("Administrator created. You can log in now.");
            return;
        } catch (const ValidationException& e) {
            Console::error(e.what());
        } catch (const DatabaseException& e) {
            Console::error(e.what());
        }
    }
}

void PortalApp::loginLoop(PortalContext& ctx) {
    const auto& p = ctx.profile();
    while (true) {
        Console::clear();
        Console::banner({str::toUpper(p.name()), p.campus(), p.school() + "  |  " + p.department(),
                         "STUDENT PORTAL  -  " + p.program() + "  -  A.Y. " + p.academicYear()});
        const int choice = Console::menu({"Login", "Verify a certificate / report card", "About this portal"}, "Exit");
        try {
            if (choice == 0) {
                std::cout << "Thank you for using the " << p.shortName() << " Student Portal.\n";
                return;
            }
            if (choice == 1) login(ctx);
            if (choice == 2) verifyCertificate(ctx);
            if (choice == 3) about(ctx);
        } catch (const InputClosedException&) {
            throw;
        } catch (const PortalException& e) {
            Console::error(e.what());
            Console::pause();
        }
    }
}

void PortalApp::login(PortalContext& ctx) {
    Console::heading("Login");
    Console::info("Students: PRN   |   Faculty: employee code   |   or your email");
    const std::string username = Console::readRequired("Username : ");
    const std::string password = Console::readPassword("Password : ");
    std::unique_ptr<User> user;
    try {
        user = ctx.auth().login(username, password);
    } catch (const AuthException& e) {
        Console::error(e.what());
        Console::pause();
        return;
    }
    Console::success("Welcome, " + user->fullName() + " (" + roleTitle(user->role()) + ")");
    if (user->mustChangePassword()) forcePasswordChange(ctx, *user);
    DashboardFactory::create(ctx, *user)->run();  // polymorphic dashboard
}

void PortalApp::forcePasswordChange(PortalContext& ctx, User& user) {
    Console::warning("You are using a temporary password. Please set your own password now.");
    while (true) {
        try {
            const std::string current = Console::readPassword("Temporary password : ");
            const std::string next = Console::readPassword("New password       : ");
            if (next != Console::readPassword("Confirm password   : ")) throw ValidationException("Passwords do not match.");
            ctx.auth().changePassword(user, current, next);
            Console::success("Password updated.");
            return;
        } catch (const ValidationException& e) {
            Console::error(e.what());
        } catch (const AuthException& e) {
            Console::error(e.what());
        }
    }
}

void PortalApp::verifyCertificate(PortalContext& ctx) {
    Console::heading("Verify a certificate");
    Console::info("Enter the 12-character verification code printed on the certificate (e.g. 3F9A-C21B-77D0).");
    const VerificationResult r = ctx.documents().verify(Console::readRequired("Verification code: "));
    if (r.status == VerifyStatus::NotFound) {
        Console::error("NOT FOUND - no certificate with this code was issued by " + ctx.profile().name() + ".");
    } else if (r.status == VerifyStatus::Tampered) {
        Console::error("INVALID - the record exists but its signature does not match. It may have been altered.");
    } else {
        Console::success(Console::paint("GENUINE", Color::Green) + " - issued by " + ctx.profile().name());
        std::cout << "  Document   : " << r.document->typeTitle() << '\n'
                  << "  Student    : " << r.student->fullName() << "  (PRN " << r.student->prn() << ")\n"
                  << "  Program    : " << ctx.profile().program() << '\n'
                  << "  Issued on  : " << r.document->issuedOn().toDisplay() << '\n'
                  << "  Purpose    : " << r.document->purpose() << '\n';
    }
    Console::pause();
}

void PortalApp::about(PortalContext& ctx) {
    const auto& p = ctx.profile();
    Console::heading("About");
    std::cout << "  " << p.shortName() << " Student Portal v" << kVersion << "  -  " << p.program() << '\n'
              << "  " << p.name() << ", " << p.campus() << '\n'
              << "  Built in C++17 (object-oriented design) with a Supabase (PostgreSQL) cloud database.\n"
              << "  Highlights: Attendance Guardian, Grade Target Planner, Student Success Radar,\n"
              << "              verifiable certificates (HMAC-SHA256), tamper-evident audit trail,\n"
              << "              PBKDF2 password hashing with account lock-out.\n";
    Console::pause();
}

}  // namespace portal
