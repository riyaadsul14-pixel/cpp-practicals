// ============================================================================
//  ADYPU Student Portal - B.Tech Computer Science & Engineering
//  Ajeenkya DY Patil University, Pune
//  Language: C++17 (object-oriented)   Database: Supabase (PostgreSQL)
// ============================================================================
#include "app/PortalApp.hpp"

int main(int argc, char** argv) {
    portal::PortalApp app;
    return app.run(argc, argv);
}
