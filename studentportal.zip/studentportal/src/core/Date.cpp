#include "core/Date.hpp"

#include <cctype>
#include <cstdio>
#include <ctime>
#include <vector>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"

namespace portal {

namespace {

const char* kMonthNames[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
const char* kWeekdayNames[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

// Howard Hinnant's civil-date algorithms (proleptic Gregorian calendar)
long long daysFromCivil(long long y, int m, int d) {
    y -= m <= 2 ? 1 : 0;
    const long long era = (y >= 0 ? y : y - 399) / 400;
    const long long yoe = y - era * 400;
    const long long mp = m > 2 ? m - 3 : m + 9;
    const long long doy = (153 * mp + 2) / 5 + d - 1;
    const long long doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + doe - 719468;
}

void civilFromDays(long long z, int& year, int& month, int& day) {
    z += 719468;
    const long long era = (z >= 0 ? z : z - 146096) / 146097;
    const long long doe = z - era * 146097;
    const long long yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    const long long y = yoe + era * 400;
    const long long doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    const long long mp = (5 * doy + 2) / 153;
    day = static_cast<int>(doy - (153 * mp + 2) / 5 + 1);
    month = static_cast<int>(mp < 10 ? mp + 3 : mp - 9);
    year = static_cast<int>(y + (month <= 2 ? 1 : 0));
}

bool readNumber(const std::string& text, std::size_t& pos, std::size_t digits, int& out) {
    if (pos + digits > text.size()) return false;
    int value = 0;
    for (std::size_t i = 0; i < digits; ++i) {
        const char c = text[pos + i];
        if (!std::isdigit(static_cast<unsigned char>(c))) return false;
        value = value * 10 + (c - '0');
    }
    pos += digits;
    out = value;
    return true;
}

std::tm localTime(long long epoch) {
    const std::time_t t = static_cast<std::time_t>(epoch);
    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    return tm;
}

std::tm utcTime(long long epoch) {
    const std::time_t t = static_cast<std::time_t>(epoch);
    std::tm tm{};
#ifdef _WIN32
    gmtime_s(&tm, &t);
#else
    gmtime_r(&t, &tm);
#endif
    return tm;
}

}  // namespace

// ------------------------------------------------------------------ Date ----
Date::Date(int year, int month, int day) {
    if (!isValid(year, month, day)) {
        throw ValidationException("Invalid date: " + std::to_string(day) + "-" + std::to_string(month) + "-" +
                                  std::to_string(year));
    }
    year_ = year;
    month_ = month;
    day_ = day;
}

bool Date::isLeapYear(int year) { return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0; }

int Date::daysInMonth(int year, int month) {
    static const int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (month < 1 || month > 12) return 0;
    return month == 2 && isLeapYear(year) ? 29 : days[month - 1];
}

bool Date::isValid(int year, int month, int day) {
    return year >= 1900 && year <= 2200 && month >= 1 && month <= 12 && day >= 1 && day <= daysInMonth(year, month);
}

Date Date::today() {
    const std::tm tm = localTime(DateTime::nowEpoch());
    return Date(tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
}

Date Date::fromDays(long long daysSinceEpoch) {
    int y = 0, m = 0, d = 0;
    civilFromDays(daysSinceEpoch, y, m, d);
    return Date(y, m, d);
}

bool Date::tryParse(const std::string& input, Date& out) {
    const std::string text = str::trim(input);
    int y = 0, m = 0, d = 0;
    std::size_t pos = 0;
    if (text.size() >= 10 && (text[4] == '-' || text[4] == '/')) {  // YYYY-MM-DD[...]
        const char sep = text[4];
        if (!readNumber(text, pos, 4, y) || text[pos++] != sep || !readNumber(text, pos, 2, m) ||
            text[pos++] != sep || !readNumber(text, pos, 2, d)) {
            return false;
        }
        if (pos != text.size() && text[pos] != 'T' && text[pos] != ' ') return false;
    } else if (text.size() == 10 && (text[2] == '-' || text[2] == '/' || text[2] == '.')) {  // DD-MM-YYYY
        const char sep = text[2];
        if (!readNumber(text, pos, 2, d) || text[pos++] != sep || !readNumber(text, pos, 2, m) ||
            text[pos++] != sep || !readNumber(text, pos, 4, y)) {
            return false;
        }
    } else {
        return false;
    }
    if (!isValid(y, m, d)) return false;
    out = Date(y, m, d);
    return true;
}

Date Date::parse(const std::string& text) {
    Date result;
    if (!tryParse(text, result)) {
        throw ValidationException("Invalid date '" + text + "'. Use DD-MM-YYYY or YYYY-MM-DD.");
    }
    return result;
}

long long Date::toDays() const { return isEmpty() ? 0 : daysFromCivil(year_, month_, day_); }

int Date::weekday() const {
    const long long days = toDays();
    const long long w = (days % 7 + 7 + 4) % 7;  // 1970-01-01 was a Thursday
    return static_cast<int>(w);
}

bool Date::isWeekend() const {
    const int w = weekday();
    return w == 0 || w == 6;
}

Date Date::addDays(long long days) const { return fromDays(toDays() + days); }

int Date::ageOn(const Date& reference) const {
    if (isEmpty() || reference.isEmpty()) return 0;
    int age = reference.year_ - year_;
    if (reference.month_ < month_ || (reference.month_ == month_ && reference.day_ < day_)) --age;
    return age;
}

std::string Date::toIso() const {
    if (isEmpty()) return "";
    char buffer[16];
    std::snprintf(buffer, sizeof buffer, "%04d-%02d-%02d", year_, month_, day_);
    return buffer;
}

std::string Date::toDisplay() const {
    if (isEmpty()) return "-";
    char buffer[24];
    std::snprintf(buffer, sizeof buffer, "%02d-%s-%04d", day_, kMonthNames[month_ - 1], year_);
    return buffer;
}

std::string Date::weekdayName() const { return isEmpty() ? "" : kWeekdayNames[weekday()]; }

// -------------------------------------------------------------- DateTime ----
long long DateTime::nowEpoch() { return static_cast<long long>(std::time(nullptr)); }

std::string DateTime::nowIsoUtc() {
    const std::tm tm = utcTime(nowEpoch());
    char buffer[32];
    std::snprintf(buffer, sizeof buffer, "%04d-%02d-%02dT%02d:%02d:%02dZ", tm.tm_year + 1900, tm.tm_mon + 1,
                  tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
    return buffer;
}

bool DateTime::parseIso(const std::string& input, long long& epochSeconds) {
    const std::string text = str::trim(input);
    std::size_t pos = 0;
    int y = 0, mo = 0, d = 0, h = 0, mi = 0, s = 0;
    if (!readNumber(text, pos, 4, y) || pos >= text.size() || text[pos++] != '-') return false;
    if (!readNumber(text, pos, 2, mo) || pos >= text.size() || text[pos++] != '-') return false;
    if (!readNumber(text, pos, 2, d)) return false;
    if (!Date::isValid(y, mo, d)) return false;
    if (pos < text.size() && (text[pos] == 'T' || text[pos] == ' ')) {
        ++pos;
        if (!readNumber(text, pos, 2, h) || pos >= text.size() || text[pos++] != ':') return false;
        if (!readNumber(text, pos, 2, mi)) return false;
        if (pos < text.size() && text[pos] == ':') {
            ++pos;
            if (!readNumber(text, pos, 2, s)) return false;
        }
        if (pos < text.size() && text[pos] == '.') {
            ++pos;
            while (pos < text.size() && std::isdigit(static_cast<unsigned char>(text[pos]))) ++pos;
        }
    }
    long long offsetSeconds = 0;
    if (pos < text.size()) {
        const char sign = text[pos];
        if (sign == 'Z' || sign == 'z') {
            ++pos;
        } else if (sign == '+' || sign == '-') {
            ++pos;
            int oh = 0, om = 0;
            if (!readNumber(text, pos, 2, oh)) return false;
            if (pos < text.size() && text[pos] == ':') ++pos;
            if (pos < text.size()) {
                if (!readNumber(text, pos, 2, om)) return false;
            }
            offsetSeconds = (oh * 3600LL + om * 60LL) * (sign == '-' ? -1 : 1);
        } else {
            return false;
        }
    }
    if (pos != text.size() || h > 23 || mi > 59 || s > 60) return false;
    epochSeconds = daysFromCivil(y, mo, d) * 86400LL + h * 3600LL + mi * 60LL + s - offsetSeconds;
    return true;
}

bool DateTime::parseHttpDate(const std::string& text, long long& epochSeconds) {
    // IMF-fixdate: "Wed, 18 Nov 2026 10:00:00 GMT"
    std::vector<std::string> parts;
    for (const auto& p : str::split(str::trim(text), ' ')) {
        if (!p.empty()) parts.push_back(p);
    }
    if (parts.size() != 6 || parts[5] != "GMT") return false;
    long long day = 0, year = 0;
    if (!str::parseInt(parts[1], day) || !str::parseInt(parts[3], year)) return false;
    int month = 0;
    for (int i = 0; i < 12; ++i) {
        if (parts[2] == kMonthNames[i]) month = i + 1;
    }
    const auto hms = str::split(parts[4], ':');
    long long h = 0, m = 0, s = 0;
    if (month == 0 || hms.size() != 3 || !str::parseInt(hms[0], h) || !str::parseInt(hms[1], m) ||
        !str::parseInt(hms[2], s)) {
        return false;
    }
    if (!Date::isValid(static_cast<int>(year), month, static_cast<int>(day)) || h > 23 || m > 59 || s > 60) return false;
    epochSeconds = daysFromCivil(year, month, static_cast<int>(day)) * 86400LL + h * 3600 + m * 60 + s;
    return true;
}

std::string DateTime::formatLocal(long long epochSeconds) {
    const std::tm tm = localTime(epochSeconds);
    int hour12 = tm.tm_hour % 12;
    if (hour12 == 0) hour12 = 12;
    char buffer[40];
    std::snprintf(buffer, sizeof buffer, "%02d-%s-%04d %02d:%02d %s", tm.tm_mday, kMonthNames[tm.tm_mon],
                  tm.tm_year + 1900, hour12, tm.tm_min, tm.tm_hour < 12 ? "AM" : "PM");
    return buffer;
}

std::string DateTime::formatIsoAsLocal(const std::string& iso) {
    long long epoch = 0;
    if (iso.empty() || !parseIso(iso, epoch)) return "-";
    return formatLocal(epoch);
}

std::string DateTime::fileStamp() {
    const std::tm tm = localTime(nowEpoch());
    char buffer[32];
    std::snprintf(buffer, sizeof buffer, "%04d%02d%02d_%02d%02d%02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
                  tm.tm_hour, tm.tm_min, tm.tm_sec);
    return buffer;
}

}  // namespace portal
