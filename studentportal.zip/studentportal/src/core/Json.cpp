// ============================================================================
//  Json.cpp - recursive-descent JSON parser and serializer
// ============================================================================
#include "core/Json.hpp"

#include <cmath>
#include <cstdio>
#include <cstdlib>

#include "core/Exceptions.hpp"

namespace portal {

namespace {

const Json& nullJson() {
    static const Json instance;
    return instance;
}

void appendUtf8(std::string& out, unsigned long cp) {
    if (cp < 0x80) {
        out += static_cast<char>(cp);
    } else if (cp < 0x800) {
        out += static_cast<char>(0xC0 | (cp >> 6));
        out += static_cast<char>(0x80 | (cp & 0x3F));
    } else if (cp < 0x10000) {
        out += static_cast<char>(0xE0 | (cp >> 12));
        out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
        out += static_cast<char>(0x80 | (cp & 0x3F));
    } else {
        out += static_cast<char>(0xF0 | (cp >> 18));
        out += static_cast<char>(0x80 | ((cp >> 12) & 0x3F));
        out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
        out += static_cast<char>(0x80 | (cp & 0x3F));
    }
}

std::string formatNumber(double value) {
    if (!std::isfinite(value)) return "null";
    char buffer[40];
    if (std::floor(value) == value && std::fabs(value) < 1e15) {
        std::snprintf(buffer, sizeof buffer, "%lld", static_cast<long long>(value));
        return buffer;
    }
    std::snprintf(buffer, sizeof buffer, "%.15g", value);
    if (std::strtod(buffer, nullptr) != value) std::snprintf(buffer, sizeof buffer, "%.17g", value);
    return buffer;
}

void escapeString(const std::string& text, std::string& out) {
    out += '"';
    for (const char ch : text) {
        const auto c = static_cast<unsigned char>(ch);
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buffer[8];
                    std::snprintf(buffer, sizeof buffer, "\\u%04x", static_cast<unsigned>(c));
                    out += buffer;
                } else {
                    out += ch;
                }
        }
    }
    out += '"';
}

bool parseWholeNumber(const std::string& text, double& out) {
    if (text.empty()) return false;
    char* end = nullptr;
    const double value = std::strtod(text.c_str(), &end);
    if (end == text.c_str() || *end != '\0' || !std::isfinite(value)) return false;
    out = value;
    return true;
}

/// Recursive-descent parser (RFC 8259).
class Parser {
public:
    explicit Parser(const std::string& text) : text_(text) {}

    Json parseDocument() {
        Json value = parseValue(0);
        skipWhitespace();
        if (pos_ != text_.size()) fail("unexpected trailing characters");
        return value;
    }

private:
    static constexpr int kMaxDepth = 200;

    [[noreturn]] void fail(const std::string& message) const {
        throw JsonException("Invalid JSON at position " + std::to_string(pos_) + ": " + message);
    }

    static bool isDigit(char c) { return c >= '0' && c <= '9'; }
    bool atEnd() const { return pos_ >= text_.size(); }

    char current() const {
        if (atEnd()) fail("unexpected end of input");
        return text_[pos_];
    }

    void skipWhitespace() {
        while (pos_ < text_.size()) {
            const char c = text_[pos_];
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                ++pos_;
            } else {
                break;
            }
        }
    }

    void expect(char c) {
        if (current() != c) fail(std::string("expected '") + c + "'");
        ++pos_;
    }

    void expectLiteral(const char* literal) {
        for (const char* p = literal; *p != '\0'; ++p) {
            if (atEnd() || text_[pos_] != *p) fail(std::string("invalid literal, expected ") + literal);
            ++pos_;
        }
    }

    Json parseValue(int depth) {
        if (depth > kMaxDepth) fail("nesting too deep");
        skipWhitespace();
        const char c = current();
        if (c == '{') return parseObject(depth);
        if (c == '[') return parseArray(depth);
        if (c == '"') return Json(parseString());
        if (c == 't') {
            expectLiteral("true");
            return Json(true);
        }
        if (c == 'f') {
            expectLiteral("false");
            return Json(false);
        }
        if (c == 'n') {
            expectLiteral("null");
            return Json();
        }
        if (c == '-' || isDigit(c)) return parseNumber();
        fail(std::string("unexpected character '") + c + "'");
    }

    Json parseObject(int depth) {
        expect('{');
        Json object = Json::object();
        skipWhitespace();
        if (current() == '}') {
            ++pos_;
            return object;
        }
        while (true) {
            skipWhitespace();
            if (current() != '"') fail("expected string key");
            const std::string key = parseString();
            skipWhitespace();
            expect(':');
            object[key] = parseValue(depth + 1);
            skipWhitespace();
            const char c = current();
            ++pos_;
            if (c == ',') continue;
            if (c == '}') return object;
            --pos_;
            fail("expected ',' or '}' in object");
        }
    }

    Json parseArray(int depth) {
        expect('[');
        Json array = Json::array();
        skipWhitespace();
        if (current() == ']') {
            ++pos_;
            return array;
        }
        while (true) {
            array.push(parseValue(depth + 1));
            skipWhitespace();
            const char c = current();
            ++pos_;
            if (c == ',') continue;
            if (c == ']') return array;
            --pos_;
            fail("expected ',' or ']' in array");
        }
    }

    unsigned long parseHex4() {
        if (pos_ + 4 > text_.size()) fail("truncated unicode escape");
        unsigned long value = 0;
        for (int i = 0; i < 4; ++i) {
            const char c = text_[pos_++];
            value <<= 4;
            if (c >= '0' && c <= '9') {
                value |= static_cast<unsigned long>(c - '0');
            } else if (c >= 'a' && c <= 'f') {
                value |= static_cast<unsigned long>(c - 'a' + 10);
            } else if (c >= 'A' && c <= 'F') {
                value |= static_cast<unsigned long>(c - 'A' + 10);
            } else {
                fail("invalid hex digit in unicode escape");
            }
        }
        return value;
    }

    std::string parseString() {
        expect('"');
        std::string out;
        while (true) {
            if (atEnd()) fail("unterminated string");
            const char c = text_[pos_++];
            if (c == '"') return out;
            if (c == '\\') {
                if (atEnd()) fail("unterminated escape sequence");
                const char e = text_[pos_++];
                switch (e) {
                    case '"': out += '"'; break;
                    case '\\': out += '\\'; break;
                    case '/': out += '/'; break;
                    case 'b': out += '\b'; break;
                    case 'f': out += '\f'; break;
                    case 'n': out += '\n'; break;
                    case 'r': out += '\r'; break;
                    case 't': out += '\t'; break;
                    case 'u': {
                        unsigned long cp = parseHex4();
                        if (cp >= 0xD800 && cp <= 0xDBFF) {
                            if (pos_ + 2 <= text_.size() && text_[pos_] == '\\' && text_[pos_ + 1] == 'u') {
                                pos_ += 2;
                                const unsigned long low = parseHex4();
                                if (low < 0xDC00 || low > 0xDFFF) fail("invalid low surrogate");
                                cp = 0x10000 + ((cp - 0xD800) << 10) + (low - 0xDC00);
                            } else {
                                fail("missing low surrogate");
                            }
                        } else if (cp >= 0xDC00 && cp <= 0xDFFF) {
                            fail("unexpected low surrogate");
                        }
                        appendUtf8(out, cp);
                        break;
                    }
                    default:
                        fail("invalid escape character");
                }
            } else if (static_cast<unsigned char>(c) < 0x20) {
                fail("control character inside string");
            } else {
                out += c;
            }
        }
    }

    Json parseNumber() {
        const std::size_t start = pos_;
        if (text_[pos_] == '-') ++pos_;
        if (atEnd()) fail("incomplete number");
        if (text_[pos_] == '0') {
            ++pos_;
        } else if (isDigit(text_[pos_])) {
            while (!atEnd() && isDigit(text_[pos_])) ++pos_;
        } else {
            fail("invalid number");
        }
        if (!atEnd() && text_[pos_] == '.') {
            ++pos_;
            if (atEnd() || !isDigit(text_[pos_])) fail("digit expected after decimal point");
            while (!atEnd() && isDigit(text_[pos_])) ++pos_;
        }
        if (!atEnd() && (text_[pos_] == 'e' || text_[pos_] == 'E')) {
            ++pos_;
            if (!atEnd() && (text_[pos_] == '+' || text_[pos_] == '-')) ++pos_;
            if (atEnd() || !isDigit(text_[pos_])) fail("digit expected in exponent");
            while (!atEnd() && isDigit(text_[pos_])) ++pos_;
        }
        const std::string token = text_.substr(start, pos_ - start);
        return Json(std::strtod(token.c_str(), nullptr));
    }

    const std::string& text_;
    std::size_t pos_ = 0;
};

}  // namespace

// ---------------------------------------------------------------------------
Json Json::array() {
    Json j;
    j.type_ = Type::Array;
    return j;
}

Json Json::object() {
    Json j;
    j.type_ = Type::Object;
    return j;
}

Json Json::parse(const std::string& text) { return Parser(text).parseDocument(); }

bool Json::asBool() const {
    if (type_ != Type::Bool) throw JsonException("JSON value is not a boolean");
    return bool_;
}

double Json::asDouble() const {
    if (type_ == Type::Number) return number_;
    double parsed = 0;
    if (type_ == Type::String && parseWholeNumber(string_, parsed)) return parsed;
    throw JsonException("JSON value is not a number");
}

long long Json::asInt() const { return std::llround(asDouble()); }

const std::string& Json::asString() const {
    if (type_ != Type::String) throw JsonException("JSON value is not a string");
    return string_;
}

std::size_t Json::size() const {
    return (type_ == Type::Array || type_ == Type::Object) ? items_.size() : 0;
}

void Json::push(Json value) {
    if (type_ == Type::Null) type_ = Type::Array;
    if (type_ != Type::Array) throw JsonException("push() called on a non-array JSON value");
    items_.push_back(std::move(value));
}

const Json& Json::at(std::size_t index) const {
    if (type_ != Type::Array || index >= items_.size()) throw JsonException("JSON array index out of range");
    return items_[index];
}

Json& Json::at(std::size_t index) {
    if (type_ != Type::Array || index >= items_.size()) throw JsonException("JSON array index out of range");
    return items_[index];
}

bool Json::has(const std::string& key) const {
    if (type_ != Type::Object) return false;
    for (const auto& k : keys_) {
        if (k == key) return true;
    }
    return false;
}

Json& Json::operator[](const std::string& key) {
    if (type_ == Type::Null) type_ = Type::Object;
    if (type_ != Type::Object) throw JsonException("key '" + key + "' accessed on a non-object JSON value");
    for (std::size_t i = 0; i < keys_.size(); ++i) {
        if (keys_[i] == key) return items_[i];
    }
    keys_.push_back(key);
    items_.emplace_back();
    return items_.back();
}

const Json& Json::operator[](const std::string& key) const {
    if (type_ != Type::Object) return nullJson();
    for (std::size_t i = 0; i < keys_.size(); ++i) {
        if (keys_[i] == key) return items_[i];
    }
    return nullJson();
}

bool Json::erase(const std::string& key) {
    if (type_ != Type::Object) return false;
    for (std::size_t i = 0; i < keys_.size(); ++i) {
        if (keys_[i] == key) {
            keys_.erase(keys_.begin() + static_cast<std::ptrdiff_t>(i));
            items_.erase(items_.begin() + static_cast<std::ptrdiff_t>(i));
            return true;
        }
    }
    return false;
}

std::string Json::getString(const std::string& key, const std::string& fallback) const {
    const Json& v = (*this)[key];
    switch (v.type_) {
        case Type::String: return v.string_;
        case Type::Number: return formatNumber(v.number_);
        case Type::Bool: return v.bool_ ? "true" : "false";
        default: return fallback;
    }
}

long long Json::getInt(const std::string& key, long long fallback) const {
    const Json& v = (*this)[key];
    double parsed = 0;
    switch (v.type_) {
        case Type::Number: return std::llround(v.number_);
        case Type::Bool: return v.bool_ ? 1 : 0;
        case Type::String: return parseWholeNumber(v.string_, parsed) ? std::llround(parsed) : fallback;
        default: return fallback;
    }
}

double Json::getDouble(const std::string& key, double fallback) const {
    const Json& v = (*this)[key];
    double parsed = 0;
    switch (v.type_) {
        case Type::Number: return v.number_;
        case Type::String: return parseWholeNumber(v.string_, parsed) ? parsed : fallback;
        default: return fallback;
    }
}

bool Json::getBool(const std::string& key, bool fallback) const {
    const Json& v = (*this)[key];
    switch (v.type_) {
        case Type::Bool: return v.bool_;
        case Type::Number: return v.number_ != 0.0;
        case Type::String:
            if (v.string_ == "true") return true;
            if (v.string_ == "false") return false;
            return fallback;
        default: return fallback;
    }
}

bool Json::isNullOrMissing(const std::string& key) const { return (*this)[key].isNull(); }

std::string Json::dump() const {
    std::string out;
    dumpTo(out);
    return out;
}

void Json::dumpTo(std::string& out) const {
    switch (type_) {
        case Type::Null: out += "null"; break;
        case Type::Bool: out += bool_ ? "true" : "false"; break;
        case Type::Number: out += formatNumber(number_); break;
        case Type::String: escapeString(string_, out); break;
        case Type::Array:
            out += '[';
            for (std::size_t i = 0; i < items_.size(); ++i) {
                if (i) out += ',';
                items_[i].dumpTo(out);
            }
            out += ']';
            break;
        case Type::Object:
            out += '{';
            for (std::size_t i = 0; i < keys_.size(); ++i) {
                if (i) out += ',';
                escapeString(keys_[i], out);
                out += ':';
                items_[i].dumpTo(out);
            }
            out += '}';
            break;
    }
}

bool Json::operator==(const Json& other) const {
    if (type_ != other.type_) return false;
    switch (type_) {
        case Type::Null: return true;
        case Type::Bool: return bool_ == other.bool_;
        case Type::Number: return number_ == other.number_;
        case Type::String: return string_ == other.string_;
        case Type::Array: return items_ == other.items_;
        case Type::Object:
            if (keys_.size() != other.keys_.size()) return false;
            for (std::size_t i = 0; i < keys_.size(); ++i) {
                if (!other.has(keys_[i]) || other[keys_[i]] != items_[i]) return false;
            }
            return true;
    }
    return false;
}

}  // namespace portal
