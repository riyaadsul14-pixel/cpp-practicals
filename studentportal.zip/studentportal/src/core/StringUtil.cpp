#include "core/StringUtil.hpp"

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <sstream>

namespace portal::str {

std::string trim(const std::string& text) {
    const char* whitespace = " \t\r\n\f\v";
    const auto first = text.find_first_not_of(whitespace);
    if (first == std::string::npos) return "";
    const auto last = text.find_last_not_of(whitespace);
    return text.substr(first, last - first + 1);
}

std::string toLower(std::string text) {
    std::transform(text.begin(), text.end(), text.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return text;
}

std::string toUpper(std::string text) {
    std::transform(text.begin(), text.end(), text.begin(),
                   [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
    return text;
}

std::vector<std::string> split(const std::string& text, char delimiter) {
    std::vector<std::string> parts;
    std::string current;
    for (const char c : text) {
        if (c == delimiter) {
            parts.push_back(current);
            current.clear();
        } else {
            current += c;
        }
    }
    parts.push_back(current);
    return parts;
}

std::string join(const std::vector<std::string>& parts, const std::string& separator) {
    std::string out;
    for (std::size_t i = 0; i < parts.size(); ++i) {
        if (i) out += separator;
        out += parts[i];
    }
    return out;
}

bool startsWith(const std::string& text, const std::string& prefix) {
    return text.size() >= prefix.size() && text.compare(0, prefix.size(), prefix) == 0;
}

bool endsWith(const std::string& text, const std::string& suffix) {
    return text.size() >= suffix.size() &&
           text.compare(text.size() - suffix.size(), suffix.size(), suffix) == 0;
}

bool equalsIgnoreCase(const std::string& a, const std::string& b) { return toLower(a) == toLower(b); }

bool containsIgnoreCase(const std::string& haystack, const std::string& needle) {
    return toLower(haystack).find(toLower(needle)) != std::string::npos;
}

std::string replaceAll(std::string text, const std::string& from, const std::string& to) {
    if (from.empty()) return text;
    std::size_t pos = 0;
    while ((pos = text.find(from, pos)) != std::string::npos) {
        text.replace(pos, from.size(), to);
        pos += to.size();
    }
    return text;
}

std::size_t displayWidth(const std::string& utf8) {
    std::size_t width = 0;
    for (std::size_t i = 0; i < utf8.size(); ++i) {
        if (utf8[i] == '\033' && i + 1 < utf8.size() && utf8[i + 1] == '[') {  // skip ANSI colour codes
            i += 2;
            while (i < utf8.size() && utf8[i] != 'm') ++i;
            continue;
        }
        if ((static_cast<unsigned char>(utf8[i]) & 0xC0) != 0x80) ++width;
    }
    return width;
}

std::string truncate(const std::string& utf8, std::size_t width) {
    if (displayWidth(utf8) <= width) return utf8;
    if (utf8.find('\033') != std::string::npos) return utf8;  // never cut through colour codes
    const std::size_t keep = width > 3 ? width - 3 : width;
    std::string out;
    std::size_t count = 0;
    for (std::size_t i = 0; i < utf8.size(); ++i) {
        const auto c = static_cast<unsigned char>(utf8[i]);
        if ((c & 0xC0) != 0x80) {
            if (count == keep) break;
            ++count;
        }
        out += utf8[i];
    }
    if (width > 3) out += "...";
    return out;
}

std::string padRight(const std::string& text, std::size_t width) {
    const std::size_t w = displayWidth(text);
    return w >= width ? text : text + std::string(width - w, ' ');
}

std::string padLeft(const std::string& text, std::size_t width) {
    const std::size_t w = displayWidth(text);
    return w >= width ? text : std::string(width - w, ' ') + text;
}

std::string center(const std::string& text, std::size_t width) {
    const std::size_t w = displayWidth(text);
    if (w >= width) return text;
    const std::size_t left = (width - w) / 2;
    return std::string(left, ' ') + text + std::string(width - w - left, ' ');
}

std::vector<std::string> wrap(const std::string& text, std::size_t width) {
    std::vector<std::string> lines;
    std::istringstream paragraphs(text);
    std::string paragraph;
    while (std::getline(paragraphs, paragraph)) {
        std::istringstream words(paragraph);
        std::string word, line;
        while (words >> word) {
            if (!line.empty() && displayWidth(line) + 1 + displayWidth(word) > width) {
                lines.push_back(line);
                line.clear();
            }
            line += (line.empty() ? "" : " ") + word;
        }
        lines.push_back(line);
    }
    if (lines.empty()) lines.emplace_back();
    return lines;
}

std::string formatFixed(double value, int decimals) {
    if (!std::isfinite(value)) return "-";
    if (std::fabs(value) < 0.5 * std::pow(10.0, -decimals)) value = 0.0;  // avoid "-0.00"
    char buffer[64];
    std::snprintf(buffer, sizeof buffer, "%.*f", decimals, value);
    return buffer;
}

std::string formatMoney(double amount) {
    const bool negative = amount < 0;
    const long long paise = std::llround(std::fabs(amount) * 100.0);
    const std::string rupees = std::to_string(paise / 100);
    std::string grouped;
    // Indian system: last three digits, then groups of two (1,85,00,000)
    if (rupees.size() <= 3) {
        grouped = rupees;
    } else {
        grouped = rupees.substr(rupees.size() - 3);
        std::string rest = rupees.substr(0, rupees.size() - 3);
        while (rest.size() > 2) {
            grouped = rest.substr(rest.size() - 2) + "," + grouped;
            rest = rest.substr(0, rest.size() - 2);
        }
        if (!rest.empty()) grouped = rest + "," + grouped;
    }
    const std::string fraction = zeroPad(paise % 100, 2);
    return std::string(negative && paise != 0 ? "-" : "") + "Rs. " + grouped + "." + fraction;
}

std::string formatPercent(double value, int decimals) { return formatFixed(value, decimals) + "%"; }

std::string zeroPad(long long value, int width) {
    std::string digits = std::to_string(value < 0 ? -value : value);
    while (static_cast<int>(digits.size()) < width) digits.insert(digits.begin(), '0');
    return (value < 0 ? "-" : "") + digits;
}

std::string urlEncode(const std::string& text) {
    static const char* hex = "0123456789ABCDEF";
    std::string out;
    for (const char ch : text) {
        const auto c = static_cast<unsigned char>(ch);
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            out += ch;
        } else {
            out += '%';
            out += hex[c >> 4];
            out += hex[c & 0x0F];
        }
    }
    return out;
}

bool parseInt(const std::string& text, long long& out) {
    const std::string t = trim(text);
    if (t.empty()) return false;
    errno = 0;
    char* end = nullptr;
    const long long value = std::strtoll(t.c_str(), &end, 10);
    if (errno == ERANGE || end == t.c_str() || *end != '\0') return false;
    out = value;
    return true;
}

bool parseDouble(const std::string& text, double& out) {
    const std::string t = trim(text);
    if (t.empty()) return false;
    errno = 0;
    char* end = nullptr;
    const double value = std::strtod(t.c_str(), &end);
    if (errno == ERANGE || end == t.c_str() || *end != '\0' || !std::isfinite(value)) return false;
    out = value;
    return true;
}

}  // namespace portal::str
