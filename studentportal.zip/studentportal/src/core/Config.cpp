#include "core/Config.hpp"

#include <fstream>
#include <vector>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"

namespace portal {

namespace fs = std::filesystem;

Config Config::loadFile(const fs::path& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw ConfigException("Cannot open configuration file: " + path.string());
    Config config;
    std::error_code ec;
    config.source_ = fs::absolute(path, ec);
    if (ec) config.source_ = path;

    std::string line;
    int lineNumber = 0;
    while (std::getline(in, line)) {
        ++lineNumber;
        if (lineNumber == 1 && line.size() >= 3 && static_cast<unsigned char>(line[0]) == 0xEF &&
            static_cast<unsigned char>(line[1]) == 0xBB && static_cast<unsigned char>(line[2]) == 0xBF) {
            line.erase(0, 3);
        }
        const std::string text = str::trim(line);
        if (text.empty() || text[0] == '#' || text[0] == ';') continue;
        const auto eq = text.find('=');
        if (eq == std::string::npos) {
            throw ConfigException(path.string() + " line " + std::to_string(lineNumber) +
                                  " is not in KEY=VALUE form: " + text);
        }
        const std::string key = str::toUpper(str::trim(text.substr(0, eq)));
        std::string value = str::trim(text.substr(eq + 1));
        if (value.size() >= 2 && ((value.front() == '"' && value.back() == '"') ||
                                  (value.front() == '\'' && value.back() == '\''))) {
            value = value.substr(1, value.size() - 2);
        }
        config.values_[key] = value;
    }
    return config;
}

Config Config::fromValues(const std::map<std::string, std::string>& values) {
    Config config;
    for (const auto& [key, value] : values) config.values_[str::toUpper(key)] = value;
    return config;
}

fs::path Config::locate(const std::string& explicitPath, const fs::path& exeDir) {
    if (!explicitPath.empty()) {
        if (!fs::exists(explicitPath)) throw ConfigException("Config file not found: " + explicitPath);
        return fs::path(explicitPath);
    }
    std::error_code ec;
    const std::vector<fs::path> candidates = {
        fs::current_path(ec) / "config" / "portal.conf",
        exeDir / "config" / "portal.conf",
        exeDir.parent_path() / "config" / "portal.conf",
        exeDir.parent_path().parent_path() / "config" / "portal.conf",
    };
    for (const auto& candidate : candidates) {
        if (fs::exists(candidate, ec)) return candidate;
    }
    throw ConfigException(
        "Could not find config/portal.conf.\n"
        "  Copy config/portal.conf.example to config/portal.conf, fill in SUPABASE_URL and SUPABASE_KEY,\n"
        "  then run the portal from the project folder (or pass --config <file>).");
}

bool Config::has(const std::string& key) const {
    const auto it = values_.find(str::toUpper(key));
    return it != values_.end() && !it->second.empty();
}

std::string Config::get(const std::string& key, const std::string& fallback) const {
    const auto it = values_.find(str::toUpper(key));
    return (it == values_.end() || it->second.empty()) ? fallback : it->second;
}

std::string Config::require(const std::string& key) const {
    const std::string value = get(key);
    if (value.empty()) {
        throw ConfigException("Missing setting " + key + " in " +
                              (source_.empty() ? std::string("configuration") : source_.string()));
    }
    return value;
}

int Config::getInt(const std::string& key, int fallback) const {
    long long value = 0;
    return str::parseInt(get(key), value) ? static_cast<int>(value) : fallback;
}

double Config::getDouble(const std::string& key, double fallback) const {
    double value = 0;
    return str::parseDouble(get(key), value) ? value : fallback;
}

fs::path Config::projectRoot() const {
    if (source_.empty()) return fs::current_path();
    const fs::path dir = source_.parent_path();
    return dir.filename() == "config" ? dir.parent_path() : dir;
}

fs::path Config::resolvePath(const std::string& key, const std::string& fallback) const {
    fs::path path = fs::u8path(get(key, fallback));
    if (path.is_relative()) path = projectRoot() / path;
    return path.lexically_normal();
}

}  // namespace portal
