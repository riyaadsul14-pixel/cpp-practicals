#include "core/Validator.hpp"

#include <cctype>
#include <regex>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"

namespace portal {

bool Validator::isEmail(const std::string& email) {
    static const std::regex pattern(R"(^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$)");
    return email.size() <= 100 && std::regex_match(email, pattern);
}

std::string Validator::normalizePhone(const std::string& phone) {
    std::string digits;
    for (const char c : phone) {
        if (std::isdigit(static_cast<unsigned char>(c))) digits += c;
    }
    if (digits.size() == 12 && str::startsWith(digits, "91")) digits = digits.substr(2);
    if (digits.size() == 11 && digits[0] == '0') digits = digits.substr(1);
    return digits;
}

bool Validator::isIndianMobile(const std::string& phone) {
    const std::string digits = normalizePhone(phone);
    return digits.size() == 10 && digits[0] >= '6' && digits[0] <= '9';
}

bool Validator::isPrn(const std::string& prn) {
    static const std::regex pattern("^[A-Z0-9]{6,20}$");
    return std::regex_match(prn, pattern);
}

bool Validator::isUsername(const std::string& username) {
    static const std::regex pattern("^[a-z0-9][a-z0-9._-]{2,29}$");
    return std::regex_match(username, pattern);
}

bool Validator::isPersonName(const std::string& name) {
    static const std::regex pattern(R"(^[A-Za-z][A-Za-z .'-]{1,79}$)");
    return std::regex_match(name, pattern);
}

bool Validator::isCourseCode(const std::string& code) {
    static const std::regex pattern("^[A-Z][A-Z0-9-]{2,11}$");
    return std::regex_match(code, pattern);
}

bool Validator::isDivision(const std::string& division) {
    static const std::regex pattern("^[A-Z][A-Z0-9]{0,2}$");
    return std::regex_match(division, pattern);
}

bool Validator::isAcademicYear(const std::string& year) {
    static const std::regex pattern(R"(^(\d{4})-(\d{2})$)");
    std::smatch match;
    if (!std::regex_match(year, match, pattern)) return false;
    const int start = std::stoi(match[1].str());
    const int end = std::stoi(match[2].str());
    return start >= 2000 && start <= 2100 && end == (start + 1) % 100;
}

void Validator::require(bool condition, const std::string& message) {
    if (!condition) throw ValidationException(message);
}

}  // namespace portal
