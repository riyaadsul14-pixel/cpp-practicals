#include "core/Csv.hpp"

#include <fstream>
#include <sstream>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"

namespace portal {

namespace {

bool isBlank(const Csv::Row& row) {
    for (const auto& field : row) {
        if (!str::trim(field).empty()) return false;
    }
    return true;
}

}  // namespace

std::string CsvRecord::get(const std::string& column) const {
    const auto it = fields_.find(str::toLower(column));
    return it == fields_.end() ? "" : str::trim(it->second);
}

std::vector<Csv::Row> Csv::parse(const std::string& content) {
    std::vector<Row> rows;
    Row row;
    std::string field;
    bool inQuotes = false;
    bool atLineStart = true;
    std::size_t i = 0;
    if (content.size() >= 3 && static_cast<unsigned char>(content[0]) == 0xEF &&
        static_cast<unsigned char>(content[1]) == 0xBB && static_cast<unsigned char>(content[2]) == 0xBF) {
        i = 3;  // skip UTF-8 BOM written by Excel
    }
    for (; i < content.size(); ++i) {
        const char c = content[i];
        if (atLineStart && !inQuotes) {
            atLineStart = false;
            if (c == '#') {  // comment line
                while (i < content.size() && content[i] != '\n') ++i;
                atLineStart = true;
                continue;
            }
        }
        if (inQuotes) {
            if (c == '"') {
                if (i + 1 < content.size() && content[i + 1] == '"') {
                    field += '"';
                    ++i;
                } else {
                    inQuotes = false;
                }
            } else {
                field += c;
            }
            continue;
        }
        if (c == '"' && field.empty()) {
            inQuotes = true;
        } else if (c == ',') {
            row.push_back(field);
            field.clear();
        } else if (c == '\n') {
            row.push_back(field);
            field.clear();
            if (!isBlank(row)) rows.push_back(row);
            row.clear();
            atLineStart = true;
        } else if (c != '\r') {
            field += c;
        }
    }
    if (!field.empty() || !row.empty()) {
        row.push_back(field);
        if (!isBlank(row)) rows.push_back(row);
    }
    return rows;
}

std::vector<Csv::Row> Csv::readFile(const std::filesystem::path& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw ValidationException("Cannot open CSV file: " + path.string());
    std::ostringstream buffer;
    buffer << in.rdbuf();
    return parse(buffer.str());
}

std::vector<CsvRecord> Csv::readRecords(const std::filesystem::path& path) {
    const auto rows = readFile(path);
    std::vector<CsvRecord> records;
    if (rows.empty()) return records;
    std::vector<std::string> header;
    for (const auto& h : rows.front()) header.push_back(str::toLower(str::trim(h)));
    for (std::size_t r = 1; r < rows.size(); ++r) {
        std::map<std::string, std::string> fields;
        for (std::size_t c = 0; c < header.size(); ++c) {
            fields[header[c]] = c < rows[r].size() ? rows[r][c] : "";
        }
        records.emplace_back(r, std::move(fields));
    }
    return records;
}

std::string Csv::escape(const std::string& field) {
    const bool needsQuotes = field.find_first_of(",\"\r\n") != std::string::npos ||
                             (!field.empty() && (field.front() == ' ' || field.back() == ' ' || field.front() == '#'));
    if (!needsQuotes) return field;
    return "\"" + str::replaceAll(field, "\"", "\"\"") + "\"";
}

std::string Csv::format(const std::vector<Row>& rows) {
    std::string out;
    for (const auto& row : rows) {
        for (std::size_t i = 0; i < row.size(); ++i) {
            if (i) out += ',';
            out += escape(row[i]);
        }
        out += "\r\n";
    }
    return out;
}

void Csv::writeFile(const std::filesystem::path& path, const std::vector<Row>& rows) {
    if (path.has_parent_path()) std::filesystem::create_directories(path.parent_path());
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) throw ValidationException("Cannot write file: " + path.string());
    out << format(rows);
}

}  // namespace portal
