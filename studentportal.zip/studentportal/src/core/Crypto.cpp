#include "core/Crypto.hpp"

#include <algorithm>
#include <cctype>
#include <cstring>
#include <random>
#include <stdexcept>

#include "core/StringUtil.hpp"

namespace portal {

namespace {

constexpr std::uint32_t kRoundConstants[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};

inline std::uint32_t rotr(std::uint32_t x, std::uint32_t n) { return (x >> n) | (x << (32 - n)); }

/// HMAC with the key already absorbed into two SHA-256 states (fast PBKDF2).
struct HmacState {
    Sha256 inner;
    Sha256 outer;

    explicit HmacState(const std::string& key) {
        std::array<std::uint8_t, 64> block{};
        if (key.size() > 64) {
            const auto d = Sha256::digest(key);
            std::copy(d.begin(), d.end(), block.begin());
        } else {
            std::memcpy(block.data(), key.data(), key.size());
        }
        std::array<std::uint8_t, 64> ipad{}, opad{};
        for (std::size_t i = 0; i < 64; ++i) {
            ipad[i] = static_cast<std::uint8_t>(block[i] ^ 0x36);
            opad[i] = static_cast<std::uint8_t>(block[i] ^ 0x5c);
        }
        inner.update(ipad.data(), ipad.size());
        outer.update(opad.data(), opad.size());
    }

    Sha256::Digest mac(const std::uint8_t* data, std::size_t length) const {
        Sha256 in = inner;
        in.update(data, length);
        const auto innerDigest = in.finish();
        Sha256 out = outer;
        out.update(innerDigest.data(), innerDigest.size());
        return out.finish();
    }
};

bool constantTimeEquals(const std::string& a, const std::string& b) {
    if (a.size() != b.size()) return false;
    unsigned char diff = 0;
    for (std::size_t i = 0; i < a.size(); ++i) diff |= static_cast<unsigned char>(a[i] ^ b[i]);
    return diff == 0;
}

}  // namespace

// ---------------------------------------------------------------- Sha256 ----
Sha256::Sha256()
    : state_{0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19} {}

void Sha256::update(const std::uint8_t* data, std::size_t length) {
    totalLength_ += length;
    while (length > 0) {
        const std::size_t take = std::min(length, buffer_.size() - bufferLength_);
        std::memcpy(buffer_.data() + bufferLength_, data, take);
        bufferLength_ += take;
        data += take;
        length -= take;
        if (bufferLength_ == buffer_.size()) {
            transform(buffer_.data());
            bufferLength_ = 0;
        }
    }
}

void Sha256::update(const std::string& data) {
    update(reinterpret_cast<const std::uint8_t*>(data.data()), data.size());
}

Sha256::Digest Sha256::finish() {
    const std::uint64_t bitLength = totalLength_ * 8;
    buffer_[bufferLength_++] = 0x80;
    if (bufferLength_ > 56) {
        std::fill(buffer_.begin() + static_cast<std::ptrdiff_t>(bufferLength_), buffer_.end(), 0);
        transform(buffer_.data());
        bufferLength_ = 0;
    }
    std::fill(buffer_.begin() + static_cast<std::ptrdiff_t>(bufferLength_), buffer_.begin() + 56, 0);
    for (int i = 0; i < 8; ++i) buffer_[63 - i] = static_cast<std::uint8_t>(bitLength >> (8 * i));
    transform(buffer_.data());

    Digest out{};
    for (std::size_t i = 0; i < 8; ++i) {
        out[4 * i] = static_cast<std::uint8_t>(state_[i] >> 24);
        out[4 * i + 1] = static_cast<std::uint8_t>(state_[i] >> 16);
        out[4 * i + 2] = static_cast<std::uint8_t>(state_[i] >> 8);
        out[4 * i + 3] = static_cast<std::uint8_t>(state_[i]);
    }
    return out;
}

void Sha256::transform(const std::uint8_t* block) {
    std::uint32_t w[64];
    for (int i = 0; i < 16; ++i) {
        w[i] = (static_cast<std::uint32_t>(block[4 * i]) << 24) | (static_cast<std::uint32_t>(block[4 * i + 1]) << 16) |
               (static_cast<std::uint32_t>(block[4 * i + 2]) << 8) | static_cast<std::uint32_t>(block[4 * i + 3]);
    }
    for (int i = 16; i < 64; ++i) {
        const std::uint32_t s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
        const std::uint32_t s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    std::uint32_t a = state_[0], b = state_[1], c = state_[2], d = state_[3];
    std::uint32_t e = state_[4], f = state_[5], g = state_[6], h = state_[7];
    for (int i = 0; i < 64; ++i) {
        const std::uint32_t S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const std::uint32_t ch = (e & f) ^ (~e & g);
        const std::uint32_t t1 = h + S1 + ch + kRoundConstants[i] + w[i];
        const std::uint32_t S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const std::uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
        const std::uint32_t t2 = S0 + maj;
        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }
    state_[0] += a;
    state_[1] += b;
    state_[2] += c;
    state_[3] += d;
    state_[4] += e;
    state_[5] += f;
    state_[6] += g;
    state_[7] += h;
}

Sha256::Digest Sha256::digest(const std::string& data) {
    Sha256 sha;
    sha.update(data);
    return sha.finish();
}

std::string Sha256::hexDigest(const std::string& data) {
    const auto d = digest(data);
    return toHex(d.data(), d.size());
}

// --------------------------------------------------------------- helpers ----
std::string toHex(const std::uint8_t* data, std::size_t length) {
    static const char* digits = "0123456789abcdef";
    std::string out;
    out.reserve(length * 2);
    for (std::size_t i = 0; i < length; ++i) {
        out += digits[data[i] >> 4];
        out += digits[data[i] & 0x0F];
    }
    return out;
}

std::vector<std::uint8_t> fromHex(const std::string& hex) {
    if (hex.size() % 2 != 0) throw std::invalid_argument("hex string has odd length");
    auto nibble = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        throw std::invalid_argument("invalid hex digit");
    };
    std::vector<std::uint8_t> out(hex.size() / 2);
    for (std::size_t i = 0; i < out.size(); ++i) {
        out[i] = static_cast<std::uint8_t>((nibble(hex[2 * i]) << 4) | nibble(hex[2 * i + 1]));
    }
    return out;
}

Sha256::Digest hmacSha256(const std::string& key, const std::string& message) {
    return HmacState(key).mac(reinterpret_cast<const std::uint8_t*>(message.data()), message.size());
}

std::vector<std::uint8_t> pbkdf2HmacSha256(const std::string& password, const std::string& salt,
                                           std::uint32_t iterations, std::size_t keyLength) {
    if (iterations == 0) throw std::invalid_argument("PBKDF2 iterations must be > 0");
    const HmacState hmac(password);
    std::vector<std::uint8_t> output;
    output.reserve(keyLength);
    for (std::uint32_t blockIndex = 1; output.size() < keyLength; ++blockIndex) {
        std::string first = salt;
        first += static_cast<char>((blockIndex >> 24) & 0xFF);
        first += static_cast<char>((blockIndex >> 16) & 0xFF);
        first += static_cast<char>((blockIndex >> 8) & 0xFF);
        first += static_cast<char>(blockIndex & 0xFF);
        auto u = hmac.mac(reinterpret_cast<const std::uint8_t*>(first.data()), first.size());
        auto t = u;
        for (std::uint32_t i = 1; i < iterations; ++i) {
            u = hmac.mac(u.data(), u.size());
            for (std::size_t j = 0; j < t.size(); ++j) t[j] ^= u[j];
        }
        const std::size_t take = std::min<std::size_t>(t.size(), keyLength - output.size());
        output.insert(output.end(), t.begin(), t.begin() + static_cast<std::ptrdiff_t>(take));
    }
    return output;
}

// -------------------------------------------------------- PasswordHasher ----
std::string PasswordHasher::randomBytes(std::size_t count) {
    std::random_device device;
    std::string out(count, '\0');
    for (auto& c : out) c = static_cast<char>(device() & 0xFF);
    return out;
}

std::string PasswordHasher::hash(const std::string& password, std::uint32_t iterations) {
    const std::string salt = randomBytes(16);
    const auto derived = pbkdf2HmacSha256(password, salt, iterations, 32);
    return "pbkdf2_sha256$" + std::to_string(iterations) + "$" +
           toHex(reinterpret_cast<const std::uint8_t*>(salt.data()), salt.size()) + "$" +
           toHex(derived.data(), derived.size());
}

bool PasswordHasher::verify(const std::string& password, const std::string& storedHash) {
    const auto parts = str::split(storedHash, '$');
    if (parts.size() != 4 || parts[0] != "pbkdf2_sha256") return false;
    long long iterations = 0;
    if (!str::parseInt(parts[1], iterations) || iterations < 1 || iterations > 10000000) return false;
    try {
        const auto saltBytes = fromHex(parts[2]);
        const std::string salt(saltBytes.begin(), saltBytes.end());
        const auto expected = fromHex(parts[3]);
        if (expected.empty()) return false;
        const auto derived =
            pbkdf2HmacSha256(password, salt, static_cast<std::uint32_t>(iterations), expected.size());
        return constantTimeEquals(toHex(derived.data(), derived.size()), str::toLower(parts[3]));
    } catch (const std::invalid_argument&) {
        return false;
    }
}

std::string PasswordHasher::strengthProblem(const std::string& password) {
    if (password.size() < 8) return "Password must be at least 8 characters long.";
    if (password.size() > 64) return "Password must be at most 64 characters long.";
    bool upper = false, lower = false, digit = false, special = false;
    for (const char ch : password) {
        const auto c = static_cast<unsigned char>(ch);
        if (std::isspace(c)) return "Password must not contain spaces.";
        if (std::isupper(c)) upper = true;
        else if (std::islower(c)) lower = true;
        else if (std::isdigit(c)) digit = true;
        else special = true;
    }
    if (!upper || !lower || !digit || !special)
        return "Password needs an uppercase letter, a lowercase letter, a digit and a special character.";
    return "";
}

std::string PasswordHasher::generateTemporaryPassword() {
    std::random_device device;
    std::string password = "Adypu@";
    for (int i = 0; i < 4; ++i) password += static_cast<char>('0' + device() % 10);
    for (int i = 0; i < 2; ++i) password += static_cast<char>('a' + device() % 26);
    return password;
}

}  // namespace portal
