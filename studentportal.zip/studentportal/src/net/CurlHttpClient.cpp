// ============================================================================
//  CurlHttpClient.cpp - HTTPS on Linux / macOS through libcurl
//  (Windows builds use WinHttpClient.cpp instead.)
// ============================================================================
#ifndef _WIN32

#include <curl/curl.h>

#include <mutex>
#include <string>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "net/HttpClient.hpp"

namespace portal {

namespace {

std::once_flag curlInitFlag;

std::size_t writeBody(char* data, std::size_t size, std::size_t count, void* userData) {
    auto* body = static_cast<std::string*>(userData);
    body->append(data, size * count);
    return size * count;
}

std::size_t writeHeader(char* data, std::size_t size, std::size_t count, void* userData) {
    auto* headers = static_cast<HeaderList*>(userData);
    const std::string line(data, size * count);
    const auto colon = line.find(':');
    if (colon != std::string::npos) {
        headers->emplace_back(str::trim(line.substr(0, colon)), str::trim(line.substr(colon + 1)));
    }
    return size * count;
}

/// RAII wrappers for the libcurl handles.
struct EasyHandle {
    CURL* handle = curl_easy_init();
    ~EasyHandle() {
        if (handle) curl_easy_cleanup(handle);
    }
};

struct HeaderSlist {
    curl_slist* list = nullptr;
    ~HeaderSlist() {
        if (list) curl_slist_free_all(list);
    }
};

}  // namespace

CurlHttpClient::CurlHttpClient(int timeoutSeconds) : timeoutSeconds_(timeoutSeconds) {
    std::call_once(curlInitFlag, [] { curl_global_init(CURL_GLOBAL_DEFAULT); });
}

CurlHttpClient::~CurlHttpClient() = default;

HttpResponse CurlHttpClient::send(const HttpRequest& request) {
    EasyHandle easy;
    if (!easy.handle) throw NetworkException("Could not initialise libcurl");

    HttpResponse response;
    HeaderSlist headers;
    for (const auto& [name, value] : request.headers) {
        headers.list = curl_slist_append(headers.list, (name + ": " + value).c_str());
    }

    curl_easy_setopt(easy.handle, CURLOPT_URL, request.url.c_str());
    curl_easy_setopt(easy.handle, CURLOPT_CUSTOMREQUEST, request.method.c_str());
    curl_easy_setopt(easy.handle, CURLOPT_HTTPHEADER, headers.list);
    curl_easy_setopt(easy.handle, CURLOPT_USERAGENT, "ADYPU-StudentPortal/1.0 (C++; libcurl)");
    curl_easy_setopt(easy.handle, CURLOPT_TIMEOUT, static_cast<long>(timeoutSeconds_));
    curl_easy_setopt(easy.handle, CURLOPT_CONNECTTIMEOUT, static_cast<long>(timeoutSeconds_));
    curl_easy_setopt(easy.handle, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(easy.handle, CURLOPT_WRITEFUNCTION, writeBody);
    curl_easy_setopt(easy.handle, CURLOPT_WRITEDATA, &response.body);
    curl_easy_setopt(easy.handle, CURLOPT_HEADERFUNCTION, writeHeader);
    curl_easy_setopt(easy.handle, CURLOPT_HEADERDATA, &response.headers);
    if (!request.body.empty() || request.method == "POST" || request.method == "PATCH") {
        curl_easy_setopt(easy.handle, CURLOPT_POSTFIELDS, request.body.c_str());
        curl_easy_setopt(easy.handle, CURLOPT_POSTFIELDSIZE, static_cast<long>(request.body.size()));
    }

    const CURLcode result = curl_easy_perform(easy.handle);
    if (result != CURLE_OK) {
        throw NetworkException(std::string("Network error: ") + curl_easy_strerror(result));
    }
    long status = 0;
    curl_easy_getinfo(easy.handle, CURLINFO_RESPONSE_CODE, &status);
    response.status = static_cast<int>(status);
    return response;
}

}  // namespace portal

#endif  // !_WIN32
