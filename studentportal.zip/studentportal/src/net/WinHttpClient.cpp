// ============================================================================
//  WinHttpClient.cpp - HTTPS on Windows through WinHTTP (ships with Windows)
// ============================================================================
#ifdef _WIN32

#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winhttp.h>

#include <string>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "net/HttpClient.hpp"

namespace portal {

namespace {

std::wstring toWide(const std::string& text) {
    if (text.empty()) return L"";
    const int length = MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0);
    std::wstring out(static_cast<std::size_t>(length), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), &out[0], length);
    return out;
}

std::string toUtf8(const std::wstring& text) {
    if (text.empty()) return "";
    const int length =
        WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0, nullptr, nullptr);
    std::string out(static_cast<std::size_t>(length), '\0');
    WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), &out[0], length, nullptr, nullptr);
    return out;
}

std::string describeError(DWORD code) {
    switch (code) {
        case ERROR_WINHTTP_TIMEOUT: return "the request timed out";
        case ERROR_WINHTTP_NAME_NOT_RESOLVED: return "the server name could not be resolved (check internet / SUPABASE_URL)";
        case ERROR_WINHTTP_CANNOT_CONNECT: return "could not connect to the server";
        case ERROR_WINHTTP_CONNECTION_ERROR: return "the connection was reset";
        case ERROR_WINHTTP_SECURE_FAILURE: return "the TLS/SSL handshake failed";
        default: break;
    }
    wchar_t* buffer = nullptr;
    const DWORD length = FormatMessageW(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_FROM_SYSTEM |
            FORMAT_MESSAGE_IGNORE_INSERTS,
        GetModuleHandleW(L"winhttp.dll"), code, 0, reinterpret_cast<LPWSTR>(&buffer), 0, nullptr);
    std::string message = length && buffer ? str::trim(toUtf8(std::wstring(buffer, length))) : "unknown error";
    if (buffer) LocalFree(buffer);
    return message;
}

[[noreturn]] void throwLastError(const std::string& step) {
    const DWORD code = GetLastError();
    throw NetworkException("Network error during " + step + ": " + describeError(code) + " (code " +
                           std::to_string(code) + ")");
}

/// RAII wrapper so every HINTERNET handle is always closed.
class InternetHandle {
public:
    explicit InternetHandle(HINTERNET handle = nullptr) : handle_(handle) {}
    ~InternetHandle() {
        if (handle_) WinHttpCloseHandle(handle_);
    }
    InternetHandle(const InternetHandle&) = delete;
    InternetHandle& operator=(const InternetHandle&) = delete;
    HINTERNET get() const { return handle_; }
    explicit operator bool() const { return handle_ != nullptr; }

private:
    HINTERNET handle_;
};

}  // namespace

WinHttpClient::WinHttpClient(int timeoutSeconds) : timeoutMs_(timeoutSeconds * 1000) {
    HINTERNET session = WinHttpOpen(L"ADYPU-StudentPortal/1.0 (C++; WinHTTP)", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                                    WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!session) throwLastError("WinHttpOpen");
    WinHttpSetTimeouts(session, timeoutMs_, timeoutMs_, timeoutMs_, timeoutMs_);
    DWORD protocols = WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2;
#ifdef WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_3
    protocols |= WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_3;
#endif
    if (!WinHttpSetOption(session, WINHTTP_OPTION_SECURE_PROTOCOLS, &protocols, sizeof protocols)) {
        protocols = WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2;  // older Windows: TLS 1.2 only
        WinHttpSetOption(session, WINHTTP_OPTION_SECURE_PROTOCOLS, &protocols, sizeof protocols);
    }
    session_ = session;
}

WinHttpClient::~WinHttpClient() {
    if (session_) WinHttpCloseHandle(static_cast<HINTERNET>(session_));
}

HttpResponse WinHttpClient::send(const HttpRequest& request) {
    const std::wstring url = toWide(request.url);
    URL_COMPONENTS parts{};
    parts.dwStructSize = sizeof parts;
    parts.dwSchemeLength = static_cast<DWORD>(-1);
    parts.dwHostNameLength = static_cast<DWORD>(-1);
    parts.dwUrlPathLength = static_cast<DWORD>(-1);
    parts.dwExtraInfoLength = static_cast<DWORD>(-1);
    if (!WinHttpCrackUrl(url.c_str(), 0, 0, &parts)) {
        throw NetworkException("Invalid URL: " + request.url);
    }
    const std::wstring host(parts.lpszHostName, parts.dwHostNameLength);
    std::wstring path(parts.lpszUrlPath, parts.dwUrlPathLength);
    if (parts.lpszExtraInfo && parts.dwExtraInfoLength) path.append(parts.lpszExtraInfo, parts.dwExtraInfoLength);
    if (path.empty()) path = L"/";
    const bool secure = parts.nScheme == INTERNET_SCHEME_HTTPS;

    InternetHandle connection(WinHttpConnect(static_cast<HINTERNET>(session_), host.c_str(), parts.nPort, 0));
    if (!connection) throwLastError("connect");

    const std::wstring method = toWide(request.method);
    InternetHandle handle(WinHttpOpenRequest(connection.get(), method.c_str(), path.c_str(), nullptr,
                                             WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                             secure ? WINHTTP_FLAG_SECURE : 0));
    if (!handle) throwLastError("open request");

    std::wstring headerBlock;
    for (const auto& [name, value] : request.headers) headerBlock += toWide(name + ": " + value) + L"\r\n";

    const BOOL sent = WinHttpSendRequest(
        handle.get(), headerBlock.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS : headerBlock.c_str(),
        headerBlock.empty() ? 0 : static_cast<DWORD>(-1L),
        request.body.empty() ? WINHTTP_NO_REQUEST_DATA : const_cast<char*>(request.body.data()),
        static_cast<DWORD>(request.body.size()), static_cast<DWORD>(request.body.size()), 0);
    if (!sent) throwLastError("send");
    if (!WinHttpReceiveResponse(handle.get(), nullptr)) throwLastError("receive");

    HttpResponse response;
    DWORD status = 0;
    DWORD size = sizeof status;
    if (!WinHttpQueryHeaders(handle.get(), WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                             WINHTTP_HEADER_NAME_BY_INDEX, &status, &size, WINHTTP_NO_HEADER_INDEX)) {
        throwLastError("read status");
    }
    response.status = static_cast<int>(status);

    DWORD headerBytes = 0;
    WinHttpQueryHeaders(handle.get(), WINHTTP_QUERY_RAW_HEADERS_CRLF, WINHTTP_HEADER_NAME_BY_INDEX,
                        WINHTTP_NO_OUTPUT_BUFFER, &headerBytes, WINHTTP_NO_HEADER_INDEX);
    if (GetLastError() == ERROR_INSUFFICIENT_BUFFER && headerBytes > 0) {
        std::wstring raw(headerBytes / sizeof(wchar_t), L'\0');
        if (WinHttpQueryHeaders(handle.get(), WINHTTP_QUERY_RAW_HEADERS_CRLF, WINHTTP_HEADER_NAME_BY_INDEX, &raw[0],
                                &headerBytes, WINHTTP_NO_HEADER_INDEX)) {
            for (const auto& line : str::split(toUtf8(raw.c_str()), '\n')) {
                const auto colon = line.find(':');
                if (colon == std::string::npos) continue;
                response.headers.emplace_back(str::trim(line.substr(0, colon)), str::trim(line.substr(colon + 1)));
            }
        }
    }

    for (;;) {
        DWORD available = 0;
        if (!WinHttpQueryDataAvailable(handle.get(), &available)) throwLastError("read body");
        if (available == 0) break;
        std::string chunk(available, '\0');
        DWORD read = 0;
        if (!WinHttpReadData(handle.get(), &chunk[0], available, &read)) throwLastError("read body");
        if (read == 0) break;
        response.body.append(chunk.data(), read);
    }
    return response;
}

}  // namespace portal

#endif  // _WIN32
