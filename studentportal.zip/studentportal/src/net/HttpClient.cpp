#include "net/HttpClient.hpp"

#include "core/StringUtil.hpp"

namespace portal {

std::string HttpResponse::header(const std::string& name) const {
    for (const auto& [key, value] : headers) {
        if (str::equalsIgnoreCase(key, name)) return value;
    }
    return "";
}

std::unique_ptr<HttpClient> HttpClient::createDefault(int timeoutSeconds) {
#ifdef _WIN32
    return std::make_unique<WinHttpClient>(timeoutSeconds);
#else
    return std::make_unique<CurlHttpClient>(timeoutSeconds);
#endif
}

}  // namespace portal
