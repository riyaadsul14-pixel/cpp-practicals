#include <iostream>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "ui/Console.hpp"
#include "ui/Dashboard.hpp"
#include "ui/Table.hpp"

namespace portal {

std::vector<std::string> StudentDashboard::menuItems() const {
    return {"My dashboard (summary)",
            "My profile",
            "Attendance Guardian",
            "Results - SGPA & CGPA",
            "Grade Target Planner",
            "Fees & receipts",
            "Notice board",
            "Certificates (bonafide / report card)",
            "Update mobile / email",
            "Change password"};
}

void StudentDashboard::handle(int choice) {
    switch (choice) {
        case 1: showHome(); break;
        case 2: showProfile(); break;
        case 3: attendanceGuardian(); break;
        case 4: results(); break;
        case 5: targetPlanner(); break;
        case 6: fees(); break;
        case 7: showNotices(); break;
        case 8: certificates(); break;
        case 9: updateContact(); break;
        case 10: changePassword(); break;
        default: break;
    }
}

void StudentDashboard::showHome() {
    const auto radar = ctx_.reports().successRadar({student_});
    const RadarRow& me = radar.front();
    const Transcript transcript = ctx_.results().transcriptFor(student_);
    double balance = 0;
    for (const auto& st : ctx_.fees().statementsFor(student_.id())) balance += st.balance;

    Console::heading("My dashboard");
    std::cout << "  Attendance   : "
              << (me.hasAttendance ? Console::bar(me.attendance) + " " + str::formatPercent(me.attendance) : "-") << '\n';
    std::cout << "  CGPA         : " << (transcript.hasCgpa ? str::formatFixed(transcript.cgpa, 2) + "  (" +
                                                                 GradeCalculator::classification(transcript.cgpa) + ")"
                                                           : "available after first semester")
              << '\n';
    std::cout << "  Backlogs     : " << transcript.backlogs << '\n';
    std::cout << "  Fee balance  : " << (balance > 0 ? Console::paint(str::formatMoney(balance), Color::Yellow)
                                                     : Console::paint("No dues", Color::Green))
              << '\n';
    const Color riskColor = me.risk.level == "HIGH" ? Color::Red : (me.risk.level == "MEDIUM" ? Color::Yellow : Color::Green);
    std::cout << "  Success Radar: " << Console::paint(me.risk.level, riskColor) << " - " << me.risk.reasons.front() << '\n';
    const auto notices = ctx_.notices().listFor(Role::Student, 2);
    for (const auto& n : notices) std::cout << "  Latest notice: " << n.title() << '\n';
}

void StudentDashboard::attendanceGuardian() {
    Console::heading("Attendance Guardian - Semester " + std::to_string(student_.semester()));
    printAttendance(ctx_.attendance().studentSummary(student_.id(), student_.semester()));
    Console::info("Guardian advice tells you how many lectures you can still miss, or must attend, to stay at " +
                  str::formatFixed(ctx_.profile().minAttendance(), 0) + "%.");
}

void StudentDashboard::results() {
    Console::heading("Results - " + student_.prn());
    printTranscript(ctx_.results().transcriptFor(student_));
}

void StudentDashboard::targetPlanner() {
    Console::heading("Grade Target Planner - Semester " + std::to_string(student_.semester()));
    Console::info("Uses your internal + mid-sem marks to find the end-sem marks you need.");
    const double target = Console::readDouble("Target SGPA for this semester (e.g. 8.5): ", 4.0, 10.0);
    const TargetPlan plan = ctx_.results().planTarget(student_, target);
    if (plan.rows.empty()) {
        Console::warning("No courses registered for this semester.");
        return;
    }
    Table t({"Code", "Course", "Cr", "Int+Mid", "Need in End-Sem", "Grade", "O needs", "A+ needs", "A needs"});
    t.maxWidth(1, 30);
    for (std::size_t c : {2u, 3u, 4u, 6u, 7u, 8u}) t.align(c, Table::Align::Right);
    for (const auto& row : plan.rows) {
        auto need = [&](std::size_t i) {
            return row.ladder[i].endsemNeeded ? str::formatFixed(*row.ladder[i].endsemNeeded, 1) : std::string("n/a");
        };
        t.addRow({row.course.code(), row.course.name(), std::to_string(row.course.credits()),
                  str::formatFixed(row.continuous, 1) + "/50" + (row.continuousComplete ? "" : "*"),
                  row.requiredEndsem ? str::formatFixed(*row.requiredEndsem, 1) + " / 50" : "not passable",
                  row.plannedGrade.letter, need(0), need(1), need(2)});
    }
    t.print();
    if (plan.achievable) {
        Console::success("Target " + str::formatFixed(target, 2) + " is achievable. Score at least the marks above to get SGPA " +
                         str::formatFixed(plan.plannedSgpa, 2) + ".");
    } else {
        Console::warning("Target " + str::formatFixed(target, 2) + " is not reachable. Best possible SGPA this semester: " +
                         str::formatFixed(plan.maxPossibleSgpa, 2) + ".");
    }
    Console::info("Pass rule: at least 20/50 in end-sem and 40/100 overall. * = some internal marks not entered yet.");
}

void StudentDashboard::fees() {
    Console::heading("Fees - " + ctx_.profile().academicYear());
    const auto statements = ctx_.fees().statementsFor(student_.id());
    printFeeStatements(statements);
    Table receipts({"Receipt No.", "Date", "Amount", "Mode", "Reference"});
    receipts.align(2, Table::Align::Right);
    for (const auto& st : statements) {
        for (const auto& p : st.payments) {
            receipts.addRow({p.receiptNumber(), p.paidOn().toDisplay(), str::formatMoney(p.amount()), p.mode(), p.reference()});
        }
    }
    std::cout << "\n  Payment receipts\n";
    receipts.print();
}

void StudentDashboard::certificates() {
    Console::heading("Certificates");
    const auto docs = ctx_.documents().forStudent(student_.id());
    Table t({"ID", "Document", "Purpose", "Status", "Verification code", "Issued"});
    t.align(0, Table::Align::Right).maxWidth(2, 30);
    for (const auto& d : docs) {
        t.addRow({std::to_string(d.id()), d.typeTitle(), d.purpose(), str::toUpper(d.status()), d.verificationCode(),
                  d.issuedOn().toDisplay()});
    }
    t.print();
    const int choice = Console::menu({"Request a bonafide certificate", "Download an approved bonafide certificate",
                                      "Generate my signed report card"},
                                     "Back");
    if (choice == 1) {
        const std::string purpose = Console::readRequired("Purpose (e.g. Education loan, Scholarship, Passport): ");
        const auto doc = ctx_.documents().requestBonafide(student_, purpose);
        Console::success("Request #" + std::to_string(doc.id()) + " sent to the academic office for approval.");
    } else if (choice == 2) {
        const long long id = Console::readInt("Certificate ID: ", 1, 1000000000);
        const auto doc = ctx_.documents().find(id);
        if (!doc || doc->studentId() != student_.id()) throw NotFoundException("No such certificate in your account.");
        const auto path = ctx_.reports().writeBonafide(*doc, student_);
        Console::success("Saved: " + path.string());
    } else if (choice == 3) {
        std::string code;
        const auto path = ctx_.reports().writeReportCard(student_, code);
        Console::success("Report card saved: " + path.string());
        Console::info("Verification code: " + code + "  (anyone can verify it from the login screen)");
    }
}

void StudentDashboard::updateContact() {
    Console::heading("Update contact details");
    Console::info("Press Enter to keep the current value.");
    const std::string email = Console::readOptional("Email", student_.email());
    const std::string phone = Console::readOptional("Mobile", student_.phone());
    ctx_.users().updateContact(student_, email, phone);
    Console::success("Contact details updated.");
}

}  // namespace portal
