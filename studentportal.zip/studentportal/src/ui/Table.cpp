#include "ui/Table.hpp"

#include <algorithm>

#include "core/StringUtil.hpp"

namespace portal {

Table::Table(std::vector<std::string> headers)
    : headers_(std::move(headers)), align_(headers_.size(), Align::Left), maxWidth_(headers_.size(), 40) {}

Table& Table::align(std::size_t column, Align alignment) {
    if (column < align_.size()) align_[column] = alignment;
    return *this;
}

Table& Table::maxWidth(std::size_t column, std::size_t width) {
    if (column < maxWidth_.size()) maxWidth_[column] = width;
    return *this;
}

void Table::addRow(std::vector<std::string> cells) {
    cells.resize(headers_.size());
    rows_.push_back(std::move(cells));
}

void Table::print(std::ostream& os) const {
    std::vector<std::size_t> width(headers_.size());
    for (std::size_t c = 0; c < headers_.size(); ++c) {
        width[c] = str::displayWidth(headers_[c]);
        for (const auto& row : rows_) width[c] = std::max(width[c], str::displayWidth(row[c]));
        width[c] = std::min(width[c], std::max(maxWidth_[c], str::displayWidth(headers_[c])));
    }
    auto separator = [&]() {
        os << "  +";
        for (const auto w : width) os << std::string(w + 2, '-') << '+';
        os << '\n';
    };
    auto line = [&](const std::vector<std::string>& cells) {
        os << "  |";
        for (std::size_t c = 0; c < cells.size(); ++c) {
            const std::string text = str::truncate(cells[c], width[c]);
            os << ' ' << (align_[c] == Align::Right ? str::padLeft(text, width[c]) : str::padRight(text, width[c])) << " |";
        }
        os << '\n';
    };
    separator();
    line(headers_);
    separator();
    for (const auto& row : rows_) line(row);
    separator();
    if (rows_.empty()) os << "  (no records)\n";
}

}  // namespace portal
