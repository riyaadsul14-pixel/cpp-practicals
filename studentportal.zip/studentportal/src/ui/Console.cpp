#include "ui/Console.hpp"

#include <cmath>
#include <iostream>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <conio.h>
#include <io.h>
#include <windows.h>
#else
#include <termios.h>
#include <unistd.h>
#endif

namespace portal {

bool Console::interactive_ = true;
bool Console::colors_ = false;

void Console::init() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    interactive_ = _isatty(_fileno(stdin)) != 0;
    const bool stdoutIsTerminal = _isatty(_fileno(stdout)) != 0;
    HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD mode = 0;
    if (stdoutIsTerminal && out != INVALID_HANDLE_VALUE && GetConsoleMode(out, &mode)) {
        colors_ = SetConsoleMode(out, mode | 0x0004 /* ENABLE_VIRTUAL_TERMINAL_PROCESSING */) != 0;
    }
#else
    interactive_ = isatty(fileno(stdin)) != 0;
    colors_ = isatty(fileno(stdout)) != 0;
#endif
}

std::string Console::paint(const std::string& text, Color color) {
    if (!colors_) return text;
    const char* code = "0";
    switch (color) {
        case Color::Reset: code = "0"; break;
        case Color::Red: code = "91"; break;
        case Color::Green: code = "92"; break;
        case Color::Yellow: code = "93"; break;
        case Color::Blue: code = "94"; break;
        case Color::Magenta: code = "95"; break;
        case Color::Cyan: code = "96"; break;
        case Color::Gray: code = "90"; break;
        case Color::Bold: code = "1"; break;
    }
    return std::string("\033[") + code + "m" + text + "\033[0m";
}

void Console::banner(const std::vector<std::string>& lines) {
    std::size_t width = 60;
    for (const auto& l : lines) width = std::max(width, str::displayWidth(l) + 4);
    const std::string border = "+" + std::string(width, '=') + "+";
    std::cout << '\n' << paint(border, Color::Cyan) << '\n';
    for (std::size_t i = 0; i < lines.size(); ++i) {
        const std::string text = str::center(lines[i], width);
        std::cout << paint("|", Color::Cyan) << (i == 0 ? paint(text, Color::Bold) : text) << paint("|", Color::Cyan)
                  << '\n';
    }
    std::cout << paint(border, Color::Cyan) << '\n';
}

void Console::heading(const std::string& text) {
    std::cout << '\n' << paint(":: " + text + " ::", Color::Yellow) << '\n';
    std::cout << paint(std::string(str::displayWidth(text) + 6, '-'), Color::Gray) << '\n';
}

void Console::success(const std::string& message) { std::cout << paint("[OK] ", Color::Green) << message << '\n'; }
void Console::error(const std::string& message) { std::cout << paint("[ERROR] ", Color::Red) << message << '\n'; }
void Console::warning(const std::string& message) { std::cout << paint("[!] ", Color::Yellow) << message << '\n'; }
void Console::info(const std::string& message) { std::cout << paint("[i] ", Color::Cyan) << message << '\n'; }

std::string Console::bar(double percent, int width) {
    const double p = std::max(0.0, std::min(100.0, percent));
    const int filled = static_cast<int>(std::lround(p / 100.0 * width));
    const std::string text = "[" + std::string(static_cast<std::size_t>(filled), '#') +
                             std::string(static_cast<std::size_t>(width - filled), '-') + "]";
    return paint(text, p >= 75 ? Color::Green : (p >= 60 ? Color::Yellow : Color::Red));
}

void Console::clear() {
    if (interactive_ && colors_) std::cout << "\033[2J\033[H" << std::flush;
}

void Console::pause() {
    if (!interactive_) return;
    std::cout << paint("\nPress Enter to continue...", Color::Gray) << std::flush;
    rawLine();
}

std::string Console::rawLine() {
    std::string line;
    if (!std::getline(std::cin, line)) throw InputClosedException();
    if (!line.empty() && line.back() == '\r') line.pop_back();
    return line;
}

std::string Console::readLine(const std::string& prompt) {
    std::cout << paint(prompt, Color::Bold) << std::flush;
    const std::string line = rawLine();
    if (!interactive_) std::cout << line << '\n';  // echo scripted input into the transcript
    return str::trim(line);
}

std::string Console::readRequired(const std::string& prompt) {
    while (true) {
        const std::string value = readLine(prompt);
        if (!value.empty()) return value;
        error("This field is required.");
    }
}

std::string Console::readOptional(const std::string& prompt, const std::string& current) {
    const std::string value = readLine(prompt + " [" + (current.empty() ? "-" : current) + "]: ");
    return value.empty() ? current : value;
}

long long Console::readInt(const std::string& prompt, long long min, long long max) {
    while (true) {
        long long value = 0;
        if (str::parseInt(readLine(prompt), value) && value >= min && value <= max) return value;
        error("Please enter a whole number from " + std::to_string(min) + " to " + std::to_string(max) + ".");
    }
}

long long Console::readIntOr(const std::string& prompt, long long min, long long max, long long fallback) {
    while (true) {
        const std::string text = readLine(prompt + " [" + std::to_string(fallback) + "]: ");
        if (text.empty()) return fallback;
        long long value = 0;
        if (str::parseInt(text, value) && value >= min && value <= max) return value;
        error("Please enter a whole number from " + std::to_string(min) + " to " + std::to_string(max) + ".");
    }
}

double Console::readDouble(const std::string& prompt, double min, double max) {
    while (true) {
        double value = 0;
        if (str::parseDouble(readLine(prompt), value) && value >= min && value <= max) return value;
        error("Please enter a number from " + str::formatFixed(min, 2) + " to " + str::formatFixed(max, 2) + ".");
    }
}

bool Console::confirm(const std::string& question, bool defaultYes) {
    while (true) {
        const std::string answer = str::toLower(readLine(question + (defaultYes ? " [Y/n]: " : " [y/N]: ")));
        if (answer.empty()) return defaultYes;
        if (answer == "y" || answer == "yes") return true;
        if (answer == "n" || answer == "no") return false;
        error("Please answer y or n.");
    }
}

Date Console::readDate(const std::string& prompt, const Date& fallback) {
    while (true) {
        const std::string hint = fallback.isEmpty() ? " (DD-MM-YYYY): " : " (DD-MM-YYYY) [" + fallback.toDisplay() + "]: ";
        const std::string text = readLine(prompt + hint);
        if (text.empty() && !fallback.isEmpty()) return fallback;
        Date d;
        if (Date::tryParse(text, d)) return d;
        error("Invalid date. Example: 18-11-2026");
    }
}

std::string Console::readPassword(const std::string& prompt) {
    std::cout << paint(prompt, Color::Bold) << std::flush;
    if (!interactive_) {
        const std::string line = rawLine();
        std::cout << std::string(line.size(), '*') << '\n';
        return line;
    }
    std::string password;
#ifdef _WIN32
    while (true) {
        const int c = _getch();
        if (c == '\r' || c == '\n') break;
        if (c == 3) throw InputClosedException();  // Ctrl+C
        if (c == 0 || c == 224) {                   // arrow / function keys
            _getch();
            continue;
        }
        if (c == '\b') {
            if (!password.empty()) {
                password.pop_back();
                std::cout << "\b \b" << std::flush;
            }
            continue;
        }
        if (c >= 32 && c < 127) {
            password += static_cast<char>(c);
            std::cout << '*' << std::flush;
        }
    }
    std::cout << '\n';
#else
    termios oldSettings{};
    tcgetattr(STDIN_FILENO, &oldSettings);
    termios noEcho = oldSettings;
    noEcho.c_lflag &= ~static_cast<tcflag_t>(ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &noEcho);
    const bool ok = static_cast<bool>(std::getline(std::cin, password));
    tcsetattr(STDIN_FILENO, TCSANOW, &oldSettings);
    std::cout << '\n';
    if (!ok) throw InputClosedException();
#endif
    return password;
}

int Console::menu(const std::vector<std::string>& options, const std::string& zeroLabel) {
    for (std::size_t i = 0; i < options.size(); ++i) {
        std::cout << "  " << paint(str::padLeft(std::to_string(i + 1), 2) + ".", Color::Cyan) << ' ' << options[i] << '\n';
    }
    std::cout << "  " << paint(" 0.", Color::Cyan) << ' ' << zeroLabel << '\n';
    return static_cast<int>(readInt("\nChoose an option: ", 0, static_cast<long long>(options.size())));
}

}  // namespace portal
