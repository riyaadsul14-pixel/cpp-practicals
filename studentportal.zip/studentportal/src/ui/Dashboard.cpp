#include "ui/Dashboard.hpp"

#include <iostream>

#include "core/Crypto.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "ui/Console.hpp"
#include "ui/Table.hpp"

namespace portal {

// ------------------------------------------------------------------ factory --
std::unique_ptr<Dashboard> DashboardFactory::create(PortalContext& context, User& user) {
    if (auto* student = dynamic_cast<Student*>(&user)) return std::make_unique<StudentDashboard>(context, *student);
    if (auto* faculty = dynamic_cast<Faculty*>(&user)) return std::make_unique<FacultyDashboard>(context, *faculty);
    if (auto* admin = dynamic_cast<Admin*>(&user)) return std::make_unique<AdminDashboard>(context, *admin);
    throw AuthException("No dashboard is available for this account type.");
}

// ------------------------------------------------------------ main loop ----
void Dashboard::run() {
    bool firstScreen = true;
    while (true) {
        Console::clear();
        Console::banner({ctx_.profile().name() + "  -  Student Portal", title(),
                         user_.fullName() + "  |  " + user_.headline()});
        try {
            if (firstScreen) showHome();
        } catch (const InputClosedException&) {
            throw;
        } catch (const PortalException& e) {
            Console::warning(std::string("Summary unavailable: ") + e.what());
        }
        firstScreen = false;
        std::cout << '\n';
        const int choice = Console::menu(menuItems(), "Logout");
        if (choice == 0) {
            Console::success("Logged out. See you soon, " + user_.fullName() + "!");
            return;
        }
        try {
            handle(choice);
        } catch (const InputClosedException&) {
            throw;
        } catch (const NetworkException& e) {
            Console::error(std::string(e.what()) + "\n        Check your internet connection and try again.");
        } catch (const PortalException& e) {
            Console::error(e.what());
        }
        Console::pause();
    }
}

// --------------------------------------------------------- shared pieces ----
void Dashboard::showProfile() const {
    Console::heading("My profile");
    std::cout << user_;  // operator<< -> virtual printProfile() of Student / Faculty / Admin
}

void Dashboard::showNotices() const {
    Console::heading("Notice board");
    const auto notices = ctx_.notices().listFor(user_.role(), 15);
    if (notices.empty()) Console::info("No notices yet.");
    for (const auto& n : notices) {
        std::cout << '\n'
                  << "  " << Console::paint("#" + std::to_string(n.id()) + "  " + n.title(), Color::Bold) << '\n'
                  << "  " << Console::paint(DateTime::formatIsoAsLocal(n.createdAt()) + "  |  " + n.postedByName() +
                                                "  |  for: " + n.audience(),
                                            Color::Gray)
                  << '\n';
        for (const auto& line : str::wrap(n.body(), 72)) std::cout << "    " << line << '\n';
    }
}

void Dashboard::postNotice() {
    Console::heading("Post a notice");
    const std::string title = Console::readRequired("Title: ");
    const std::string body = Console::readRequired("Message: ");
    std::string audience = "students";
    if (user_.role() == Role::Admin) {
        const int a = Console::menu({"Everyone", "Students only", "Faculty only"}, "Cancel");
        if (a == 0) return;
        audience = a == 1 ? "all" : (a == 2 ? "students" : "faculty");
    }
    const Notice n = ctx_.notices().post(title, body, audience, user_);
    Console::success("Notice #" + std::to_string(n.id()) + " published.");
}

void Dashboard::changePassword() {
    Console::heading("Change password");
    Console::info("Rules: 8+ characters with upper-case, lower-case, digit and special character.");
    const std::string current = Console::readPassword("Current password : ");
    const std::string next = Console::readPassword("New password     : ");
    const std::string again = Console::readPassword("Confirm password : ");
    if (next != again) throw ValidationException("The two new passwords do not match.");
    ctx_.auth().changePassword(user_, current, next);
    Console::success("Password changed successfully.");
}

std::optional<Course> Dashboard::chooseCourse(const std::vector<Course>& courses) const {
    if (courses.empty()) {
        Console::warning("No courses available.");
        return std::nullopt;
    }
    std::vector<std::string> options;
    for (const auto& c : courses) options.push_back(c.label() + "  (Sem " + std::to_string(c.semester()) + ")");
    const int choice = Console::menu(options, "Cancel");
    if (choice == 0) return std::nullopt;
    return courses[static_cast<std::size_t>(choice - 1)];
}

int Dashboard::chooseSemester(const std::string& prompt, bool allowAll) const {
    return static_cast<int>(allowAll ? Console::readIntOr(prompt + " (1-8, 0 = all)", 0, 8, 0)
                                     : Console::readInt(prompt + " (1-8): ", 1, 8));
}

std::optional<Student> Dashboard::findStudentInteractive() const {
    const std::string text = Console::readRequired("Enter PRN or part of the name: ");
    const auto matches = ctx_.users().searchStudents(text);
    if (matches.empty()) {
        Console::warning("No student matches '" + text + "'.");
        return std::nullopt;
    }
    if (matches.size() == 1) return matches.front();
    std::vector<std::string> options;
    for (const auto& s : matches) options.push_back(s.prn() + "  " + s.fullName() + "  (Sem " + std::to_string(s.semester()) + ")");
    const int choice = Console::menu(options, "Cancel");
    if (choice == 0) return std::nullopt;
    return matches[static_cast<std::size_t>(choice - 1)];
}

void Dashboard::printStudents(const std::vector<Student>& students) const {
    Table t({"#", "PRN", "Name", "Sem", "Div", "Email", "Mobile", "Status"});
    t.align(0, Table::Align::Right).align(3, Table::Align::Right).maxWidth(2, 26).maxWidth(5, 34);
    int i = 0;
    for (const auto& s : students) {
        t.addRow({std::to_string(++i), s.prn(), s.fullName(), std::to_string(s.semester()), s.division(), s.email(),
                  s.phone(), s.isActive() ? "Active" : "Inactive"});
    }
    t.print();
}

void Dashboard::printAttendance(const std::vector<CourseAttendance>& rows) const {
    const double target = ctx_.profile().minAttendance();
    Table t({"Code", "Course", "Attended", "%", "Progress", "Attendance Guardian"});
    t.align(2, Table::Align::Right).align(3, Table::Align::Right).maxWidth(1, 30).maxWidth(5, 44);
    int attended = 0, total = 0;
    for (const auto& r : rows) {
        attended += r.attended;
        total += r.total;
        t.addRow({r.course.code(), r.course.name(), std::to_string(r.attended) + "/" + std::to_string(r.total),
                  r.total ? str::formatFixed(r.percent(), 1) : "-", r.total ? Console::bar(r.percent(), 12) : "",
                  AttendanceGuardian::advice(r.attended, r.total, target)});
    }
    t.print();
    if (total > 0) {
        const double overall = AttendanceGuardian::percent(attended, total);
        std::cout << "  Overall: " << Console::bar(overall) << ' ' << str::formatPercent(overall) << "  ("
                  << attended << "/" << total << " lectures, minimum " << str::formatFixed(target, 0) << "%)\n";
    }
}

void Dashboard::printTranscript(const Transcript& transcript) const {
    if (transcript.semesters.empty()) {
        Console::info("No courses registered yet.");
        return;
    }
    for (const auto& sem : transcript.semesters) {
        std::cout << '\n'
                  << Console::paint("  Semester " + std::to_string(sem.semester), Color::Bold)
                  << (sem.declared ? "   SGPA " + Console::paint(str::formatFixed(sem.sgpa, 2), Color::Green) +
                                         "   Credits earned " + std::to_string(sem.creditsEarned) + "/" +
                                         std::to_string(sem.creditsRegistered)
                                   : Console::paint("   (result in progress)", Color::Gray))
                  << '\n';
        Table t({"Code", "Course", "Cr", "Int/20", "Mid/30", "End/50", "Total", "Grade"});
        t.maxWidth(1, 34);
        for (std::size_t c = 2; c < 7; ++c) t.align(c, Table::Align::Right);
        for (const auto& c : sem.courses) {
            auto mark = [&](ExamComponent comp) {
                if (!c.marks) return std::string("-");
                const auto v = c.marks->get(comp);
                return v ? str::formatFixed(*v, 1) : std::string("-");
            };
            t.addRow({c.course.code(), c.course.name(), std::to_string(c.course.credits()), mark(ExamComponent::Internal),
                      mark(ExamComponent::MidSem), mark(ExamComponent::EndSem),
                      c.marks ? str::formatFixed(c.total, 1) : "-",
                      c.complete ? c.grade.letter + (c.grade.passed ? "" : " (backlog)") : "-"});
        }
        t.print();
    }
    if (transcript.hasCgpa) {
        std::cout << "\n  CGPA: " << Console::paint(str::formatFixed(transcript.cgpa, 2), Color::Green) << "   |  "
                  << GradeCalculator::classification(transcript.cgpa) << "   |  Credits earned: "
                  << transcript.creditsEarned << "   |  Backlogs: " << transcript.backlogs << '\n';
        std::string trend;
        for (const auto& [sem, sgpa] : transcript.sgpaHistory()) {
            trend += (trend.empty() ? "" : "  ->  ") + std::string("S") + std::to_string(sem) + ": " + str::formatFixed(sgpa, 2);
        }
        if (!trend.empty()) std::cout << "  SGPA trend: " << trend << '\n';
    } else {
        Console::info("CGPA will appear after the first semester result is complete.");
    }
}

void Dashboard::printFeeStatements(const std::vector<FeeStatement>& statements) const {
    Table t({"Fee ID", "Description", "A.Y.", "Amount", "Paid", "Balance", "Due date", "Status"});
    t.align(0, Table::Align::Right).align(3, Table::Align::Right).align(4, Table::Align::Right).align(5, Table::Align::Right);
    double balance = 0;
    for (const auto& st : statements) {
        balance += st.balance;
        t.addRow({std::to_string(st.fee.id()), st.fee.description(), st.fee.academicYear(),
                  str::formatMoney(st.fee.amount()), str::formatMoney(st.paid), str::formatMoney(st.balance),
                  st.fee.dueDate().toDisplay(), st.status()});
    }
    t.print();
    std::cout << "  Total balance: " << Console::paint(str::formatMoney(balance), balance > 0 ? Color::Yellow : Color::Green)
              << '\n';
}

void Dashboard::printRadar(const std::vector<RadarRow>& rows) const {
    Table t({"Risk", "Score", "PRN", "Name", "Sem", "Attend.", "Int+Mid", "Backlogs", "Main reason"});
    t.align(1, Table::Align::Right).align(5, Table::Align::Right).align(6, Table::Align::Right).align(7, Table::Align::Right);
    t.maxWidth(3, 22).maxWidth(8, 44);
    int high = 0, medium = 0;
    for (const auto& r : rows) {
        if (r.risk.level == "HIGH") ++high;
        if (r.risk.level == "MEDIUM") ++medium;
        t.addRow({r.risk.level, std::to_string(r.risk.score), r.student.prn(), r.student.fullName(),
                  std::to_string(r.student.semester()), r.hasAttendance ? str::formatPercent(r.attendance) : "-",
                  r.hasMarks ? str::formatPercent(r.continuous) : "-", std::to_string(r.backlogs),
                  r.risk.reasons.front()});
    }
    t.print();
    std::cout << "  " << Console::paint(std::to_string(high) + " HIGH", Color::Red) << "  |  "
              << Console::paint(std::to_string(medium) + " MEDIUM", Color::Yellow) << "  |  "
              << Console::paint(std::to_string(rows.size() - static_cast<std::size_t>(high + medium)) + " LOW", Color::Green)
              << "  risk students\n";
    for (const auto& r : rows) {
        if (r.risk.level != "HIGH") continue;
        std::cout << "\n  " << Console::paint(r.student.prn() + "  " + r.student.fullName(), Color::Bold) << '\n';
        for (const auto& reason : r.risk.reasons) std::cout << "    - " << reason << '\n';
        for (const auto& action : r.risk.actions) std::cout << "    > Action: " << action << '\n';
    }
}

}  // namespace portal
