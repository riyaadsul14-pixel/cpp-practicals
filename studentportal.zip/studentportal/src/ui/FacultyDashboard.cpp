#include <cmath>
#include <iostream>
#include <map>
#include <set>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "ui/Console.hpp"
#include "ui/Dashboard.hpp"
#include "ui/Table.hpp"

namespace portal {

namespace {
/// Parses "3, 7, 10-12" into {3,7,10,11,12}; every number must be within 1..max.
std::set<int> parseSerials(const std::string& text, int max) {
    std::set<int> out;
    for (const auto& rawPart : str::split(text, ',')) {
        const std::string part = str::trim(rawPart);
        if (part.empty()) continue;
        const auto dash = part.find('-');
        long long from = 0, to = 0;
        const bool ok = dash == std::string::npos
                            ? str::parseInt(part, from) && (to = from, true)
                            : str::parseInt(part.substr(0, dash), from) && str::parseInt(part.substr(dash + 1), to);
        if (!ok || from < 1 || to > max || from > to) {
            throw ValidationException("'" + part + "' is not a valid serial number or range (1-" + std::to_string(max) + ").");
        }
        for (long long i = from; i <= to; ++i) out.insert(static_cast<int>(i));
    }
    return out;
}
}  // namespace

std::vector<std::string> FacultyDashboard::menuItems() const {
    return {"My courses",
            "Mark attendance",
            "Course attendance report",
            "Enter / update marks",
            "Course result sheet",
            "Student Success Radar (my students)",
            "Notice board",
            "Post a notice for students",
            "Export attendance / results (CSV for Excel)",
            "My profile",
            "Change password"};
}

void FacultyDashboard::handle(int choice) {
    switch (choice) {
        case 1: myCourses(); break;
        case 2: markAttendance(); break;
        case 3: attendanceReport(); break;
        case 4: enterMarks(); break;
        case 5: resultSheet(); break;
        case 6: radar(); break;
        case 7: showNotices(); break;
        case 8: postNotice(); break;
        case 9: exportData(); break;
        case 10: showProfile(); break;
        case 11: changePassword(); break;
        default: break;
    }
}

void FacultyDashboard::showHome() {
    const auto courses = ctx_.academic().coursesForFaculty(faculty_.id());
    Console::heading("Today: " + Date::today().toDisplay() + " (" + Date::today().weekdayName() + ")");
    std::cout << "  You teach " << courses.size() << " course(s): ";
    std::vector<std::string> codes;
    for (const auto& c : courses) codes.push_back(c.code());
    std::cout << (codes.empty() ? "-" : str::join(codes, ", ")) << '\n';
}

std::optional<Course> FacultyDashboard::chooseMyCourse() const {
    return chooseCourse(ctx_.academic().coursesForFaculty(faculty_.id()));
}

void FacultyDashboard::myCourses() {
    Console::heading("My courses");
    Table t({"Code", "Course", "Sem", "Credits", "Type", "Students"});
    t.align(2, Table::Align::Right).align(3, Table::Align::Right).align(5, Table::Align::Right);
    for (const auto& c : ctx_.academic().coursesForFaculty(faculty_.id())) {
        t.addRow({c.code(), c.name(), std::to_string(c.semester()), std::to_string(c.credits()), c.type(),
                  std::to_string(ctx_.academic().studentsInCourse(c.id()).size())});
    }
    t.print();
}

void FacultyDashboard::markAttendance() {
    Console::heading("Mark attendance");
    const auto course = chooseMyCourse();
    if (!course) return;
    const Date date = Console::readDate("Lecture date", Date::today());
    if (date.isWeekend()) Console::warning(date.toDisplay() + " is a " + date.weekdayName() + ".");
    const auto students = ctx_.academic().studentsInCourse(course->id());
    if (students.empty()) throw ValidationException("No students are enrolled in " + course->code() + ".");

    std::set<long long> previouslyAbsent;
    if (ctx_.attendance().isMarked(course->id(), date)) {
        Console::warning("Attendance for " + date.toDisplay() + " already exists - saving again will correct it.");
        for (const auto& r : ctx_.attendance().recordsFor(course->id(), date)) {
            if (!r.present()) previouslyAbsent.insert(r.studentId());
        }
    }
    Table t({"No", "PRN", "Name", "Earlier"});
    t.align(0, Table::Align::Right);
    for (std::size_t i = 0; i < students.size(); ++i) {
        t.addRow({std::to_string(i + 1), students[i].prn(), students[i].fullName(),
                  previouslyAbsent.count(students[i].id()) ? "A" : ""});
    }
    t.print();
    const std::string input = Console::readLine(
        "Serial numbers of ABSENT students (e.g. 2,5,9-11). Press Enter if everyone is present: ");
    const auto absent = parseSerials(input, static_cast<int>(students.size()));

    std::vector<std::pair<long long, bool>> presence;
    for (std::size_t i = 0; i < students.size(); ++i) {
        presence.emplace_back(students[i].id(), absent.count(static_cast<int>(i + 1)) == 0);
    }
    std::cout << "  Present: " << students.size() - absent.size() << "   Absent: " << absent.size() << '\n';
    for (const int serial : absent) std::cout << "    A  " << students[static_cast<std::size_t>(serial - 1)].prn() << "  "
                                              << students[static_cast<std::size_t>(serial - 1)].fullName() << '\n';
    if (!Console::confirm("Save attendance for " + course->code() + " on " + date.toDisplay() + "?", true)) {
        Console::info("Nothing saved.");
        return;
    }
    const int saved = ctx_.attendance().mark(course->id(), date, presence, faculty_);
    Console::success("Attendance saved for " + std::to_string(saved) + " students.");
}

void FacultyDashboard::attendanceReport() {
    Console::heading("Course attendance report");
    const auto course = chooseMyCourse();
    if (!course) return;
    const double target = ctx_.profile().minAttendance();
    Table t({"PRN", "Name", "Attended", "%", "Progress", "Status"});
    t.align(2, Table::Align::Right).align(3, Table::Align::Right);
    int shortage = 0;
    for (const auto& r : ctx_.attendance().courseSummary(course->id())) {
        const bool low = r.total > 0 && r.percent() < target;
        if (low) ++shortage;
        t.addRow({r.student.prn(), r.student.fullName(), std::to_string(r.attended) + "/" + std::to_string(r.total),
                  r.total ? str::formatFixed(r.percent(), 1) : "-", r.total ? Console::bar(r.percent(), 12) : "",
                  r.total == 0 ? "-" : (low ? "SHORTAGE" : "OK")});
    }
    t.print();
    std::cout << "  " << shortage << " student(s) below " << str::formatFixed(target, 0) << "% in " << course->code() << '\n';
}

void FacultyDashboard::enterMarks() {
    Console::heading("Enter / update marks");
    const auto course = chooseMyCourse();
    if (!course) return;
    const int comp = Console::menu({"Internal / CA (out of 20)", "Mid-Semester (out of 30)", "End-Semester (out of 50)"}, "Cancel");
    if (comp == 0) return;
    const ExamComponent component = comp == 1 ? ExamComponent::Internal : (comp == 2 ? ExamComponent::MidSem : ExamComponent::EndSem);
    const double maximum = componentMax(component);

    std::map<long long, MarkRecord> existing;
    for (const auto& m : ctx_.results().marksForCourse(course->id())) existing[m.studentId()] = m;
    Console::info("Type marks (0-" + str::formatFixed(maximum, 0) + ", steps of 0.5). Enter = keep current / skip.");
    std::vector<std::pair<long long, double>> entries;
    for (const auto& s : ctx_.academic().studentsInCourse(course->id())) {
        const auto it = existing.find(s.id());
        const auto current = it == existing.end() ? std::nullopt : it->second.get(component);
        while (true) {
            const std::string text = Console::readLine("  " + s.prn() + "  " + str::padRight(s.fullName(), 24) + " [" +
                                                       (current ? str::formatFixed(*current, 1) : "-") + "]: ");
            if (text.empty()) break;
            double value = 0;
            if (str::parseDouble(text, value) && value >= 0 && value <= maximum &&
                std::fabs(value * 2 - std::round(value * 2)) < 1e-9) {
                if (!current || *current != value) entries.emplace_back(s.id(), value);
                break;
            }
            Console::error("Enter a number from 0 to " + str::formatFixed(maximum, 0) + " in steps of 0.5.");
        }
    }
    if (entries.empty()) {
        Console::info("No changes.");
        return;
    }
    if (!Console::confirm("Save " + std::to_string(entries.size()) + " change(s)?", true)) return;
    const int saved = ctx_.results().saveMarks(course->id(), component, entries, faculty_);
    Console::success(componentLabel(component) + " marks saved for " + std::to_string(saved) + " student(s).");
}

void FacultyDashboard::resultSheet() {
    Console::heading("Course result sheet");
    const auto course = chooseMyCourse();
    if (!course) return;
    Table t({"PRN", "Name", "Int/20", "Mid/30", "End/50", "Total", "Grade"});
    for (std::size_t c = 2; c < 6; ++c) t.align(c, Table::Align::Right);
    int complete = 0, passed = 0;
    double sum = 0, best = 0;
    for (const auto& r : ctx_.results().resultSheet(course->id())) {
        auto mark = [&](ExamComponent comp) {
            if (!r.marks) return std::string("-");
            const auto v = r.marks->get(comp);
            return v ? str::formatFixed(*v, 1) : std::string("-");
        };
        if (r.complete) {
            ++complete;
            if (r.grade.passed) ++passed;
            sum += r.marks->total();
            best = std::max(best, r.marks->total());
        }
        t.addRow({r.student.prn(), r.student.fullName(), mark(ExamComponent::Internal), mark(ExamComponent::MidSem),
                  mark(ExamComponent::EndSem), r.marks ? str::formatFixed(r.marks->total(), 1) : "-",
                  r.complete ? r.grade.letter : "-"});
    }
    t.print();
    if (complete > 0) {
        std::cout << "  Results complete: " << complete << "  |  Pass: " << passed << " ("
                  << str::formatPercent(100.0 * passed / complete) << ")  |  Average: " << str::formatFixed(sum / complete, 1)
                  << "  |  Highest: " << str::formatFixed(best, 1) << '\n';
    } else {
        Console::info("Grades appear once internal, mid-sem and end-sem marks are all entered.");
    }
}

void FacultyDashboard::radar() {
    Console::heading("Student Success Radar - my students");
    std::map<long long, Student> unique;
    for (const auto& c : ctx_.academic().coursesForFaculty(faculty_.id())) {
        for (const auto& s : ctx_.academic().studentsInCourse(c.id())) {
            if (s.semester() == c.semester()) unique[s.id()] = s;
        }
    }
    std::vector<Student> students;
    for (const auto& [id, s] : unique) students.push_back(s);
    printRadar(ctx_.reports().successRadar(students));
}

void FacultyDashboard::exportData() {
    Console::heading("Export to CSV (opens in Excel)");
    const auto course = chooseMyCourse();
    if (!course) return;
    const int what = Console::menu({"Attendance register", "Result sheet"}, "Cancel");
    if (what == 0) return;
    const auto path = what == 1 ? ctx_.reports().exportAttendance(course->id()) : ctx_.reports().exportResults(course->id());
    Console::success("Saved: " + path.string());
}

}  // namespace portal
