#include <iostream>

#include "core/Crypto.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "ui/Console.hpp"
#include "ui/Dashboard.hpp"
#include "ui/Table.hpp"

namespace portal {

std::vector<std::string> AdminDashboard::menuItems() const {
    return {"University overview",
            "Students",
            "Faculty",
            "Courses & enrollment",
            "Fees & payments",
            "Notices",
            "Student Success Radar",
            "Certificate requests",
            "Accounts, security & audit trail",
            "Change my password"};
}

void AdminDashboard::handle(int choice) {
    switch (choice) {
        case 1: overview(); break;
        case 2: studentMenu(); break;
        case 3: facultyMenu(); break;
        case 4: courseMenu(); break;
        case 5: feeMenu(); break;
        case 6: noticeMenu(); break;
        case 7: radar(); break;
        case 8: certificateRequests(); break;
        case 9: securityMenu(); break;
        case 10: changePassword(); break;
        default: break;
    }
}

void AdminDashboard::showHome() {
    const long long pending = ctx_.db().count(DocumentRecord::TABLE, Query().eq("status", "pending"));
    if (pending > 0) Console::warning(std::to_string(pending) + " certificate request(s) waiting for approval (option 8).");
}

void AdminDashboard::overview() {
    Console::heading("University overview - " + ctx_.profile().program());
    const Overview o = ctx_.reports().overview();
    std::cout << "  Active students : " << o.students << "     Faculty : " << o.faculty << "     Courses : " << o.courses << '\n';
    long long maxCount = 1;
    for (const auto& [sem, count] : o.studentsPerSemester) maxCount = std::max<long long>(maxCount, count);
    for (const auto& [sem, count] : o.studentsPerSemester) {
        std::cout << "    Semester " << sem << "  " << Console::paint(std::string(static_cast<std::size_t>(30 * count / maxCount), '#'), Color::Cyan)
                  << ' ' << count << '\n';
    }
    const double collectedPct = o.fees.billed > 0 ? 100.0 * o.fees.collected / o.fees.billed : 0;
    std::cout << "\n  Fees billed     : " << str::formatMoney(o.fees.billed) << '\n'
              << "  Collected       : " << str::formatMoney(o.fees.collected) << "  " << Console::bar(collectedPct) << ' '
              << str::formatPercent(collectedPct) << '\n'
              << "  Pending         : " << str::formatMoney(o.fees.pending) << "  (overdue "
              << Console::paint(str::formatMoney(o.fees.overdue), Color::Red) << ")\n"
              << "  Certificate requests pending: " << o.pendingDocuments << '\n';
}

// ================================================================ students ===
void AdminDashboard::studentMenu() {
    Console::heading("Students");
    const int c = Console::menu({"List students by semester", "Search student (360-degree view)", "Add a student",
                                 "Edit a student", "Import students from CSV", "Promote a semester",
                                 "Activate / deactivate a student", "Export student list (CSV)"});
    switch (c) {
        case 1: printStudents(ctx_.users().listStudents(chooseSemester("Semester", true))); break;
        case 2: studentView360(); break;
        case 3: addStudent(); break;
        case 4: editStudent(); break;
        case 5: {
            const std::string path = Console::readRequired("CSV file path (columns as in data/students.csv): ");
            const std::string password = Console::readPassword("Initial password for the new students: ");
            const auto result = ctx_.users().importStudentsCsv(path, password, user_);
            Console::success(std::to_string(result.added) + " student(s) imported (they must change password at first login).");
            for (const auto& e : result.errors) Console::warning(e);
            break;
        }
        case 6: {
            const int from = chooseSemester("Promote all students FROM semester", false);
            if (!Console::confirm("Move every semester " + std::to_string(from) + " student to semester " +
                                  std::to_string(from + 1) + "?", false)) break;
            Console::success(std::to_string(ctx_.users().promoteSemester(from, user_)) + " student(s) promoted.");
            break;
        }
        case 7: {
            const auto s = findStudentInteractive();
            if (!s) break;
            ctx_.users().setActive(s->id(), !s->isActive(), user_);
            Console::success(s->fullName() + " is now " + (s->isActive() ? "deactivated." : "active."));
            break;
        }
        case 8: Console::success("Saved: " + ctx_.reports().exportStudents(chooseSemester("Semester", true)).string()); break;
        default: break;
    }
}

void AdminDashboard::studentView360() {
    const auto s = findStudentInteractive();
    if (!s) return;
    Console::heading("360-degree view: " + s->fullName());
    std::cout << *s;
    Console::heading("Attendance - semester " + std::to_string(s->semester()));
    printAttendance(ctx_.attendance().studentSummary(s->id(), s->semester()));
    Console::heading("Results");
    printTranscript(ctx_.results().transcriptFor(*s));
    Console::heading("Fees");
    printFeeStatements(ctx_.fees().statementsFor(s->id()));
    const auto radar = ctx_.reports().successRadar({*s});
    Console::heading("Success Radar: " + radar.front().risk.level + " (" + std::to_string(radar.front().risk.score) + "/100)");
    for (const auto& r : radar.front().risk.reasons) std::cout << "  - " << r << '\n';
}

void AdminDashboard::addStudent() {
    Console::heading("Add a student");
    Student s;
    s.setPrn(Console::readRequired("PRN (e.g. 2026BTCS011): "));
    s.setFullName(Console::readRequired("Full name: "));
    s.setEmail(Console::readRequired("Email: "));
    s.setPhone(Console::readLine("Mobile (optional): "));
    s.setSemester(static_cast<int>(Console::readInt("Semester (1-8): ", 1, 8)));
    s.setDivision(Console::readOptional("Division", "A"));
    s.setAdmissionYear(static_cast<int>(Console::readIntOr("Admission year", 2000, Date::today().year() + 1,
                                                           ctx_.profile().academicYearStart() - (s.semester() - 1) / 2)));
    const std::string dob = Console::readLine("Date of birth DD-MM-YYYY (optional): ");
    if (!dob.empty()) s.setDateOfBirth(Date::parse(dob));
    s.setGender(Console::readLine("Gender M/F/O (optional): "));
    s.setGuardianName(Console::readLine("Guardian name (optional): "));
    s.setGuardianPhone(Console::readLine("Guardian mobile (optional): "));
    s.setAddress(Console::readLine("Address (optional): "));
    const std::string password = PasswordHasher::generateTemporaryPassword();
    const Student created = ctx_.users().createStudent(s, password, true, user_);
    Console::success("Student created. Login: " + created.username() + "   Temporary password: " + password);
    Console::info("The student must change this password at first login.");
    if (Console::confirm("Enroll in all semester " + std::to_string(created.semester()) + " courses now?", true)) {
        const int n = ctx_.academic().autoEnrollSemester(created.semester(), ctx_.profile().academicYear(), user_);
        Console::success(std::to_string(n) + " new enrollment(s).");
    }
}

void AdminDashboard::editStudent() {
    auto s = findStudentInteractive();
    if (!s) return;
    Console::heading("Edit " + s->prn() + " (Enter keeps the current value)");
    s->setFullName(Console::readOptional("Full name", s->fullName()));
    s->setEmail(Console::readOptional("Email", s->email()));
    s->setPhone(Console::readOptional("Mobile", s->phone()));
    s->setSemester(static_cast<int>(Console::readIntOr("Semester", 1, 8, s->semester())));
    s->setDivision(Console::readOptional("Division", s->division()));
    s->setGuardianName(Console::readOptional("Guardian name", s->guardianName()));
    s->setGuardianPhone(Console::readOptional("Guardian mobile", s->guardianPhone()));
    s->setAddress(Console::readOptional("Address", s->address()));
    ctx_.users().updateStudent(*s, user_);
    Console::success("Student updated.");
}

// ================================================================= faculty ===
void AdminDashboard::facultyMenu() {
    Console::heading("Faculty");
    const int c = Console::menu({"List faculty", "Add faculty member"});
    if (c == 1) {
        Table t({"Code", "Name", "Designation", "Specialization", "Email", "Courses"});
        t.maxWidth(3, 24);
        for (const auto& f : ctx_.users().listFaculty()) {
            std::vector<std::string> codes;
            for (const auto& course : ctx_.academic().coursesForFaculty(f.id())) codes.push_back(course.code());
            t.addRow({f.employeeCode(), f.fullName(), f.designation(), f.specialization(), f.email(), str::join(codes, " ")});
        }
        t.print();
    } else if (c == 2) {
        addFaculty();
    }
}

void AdminDashboard::addFaculty() {
    Faculty f;
    f.setEmployeeCode(Console::readRequired("Employee code (e.g. FAC008): "));
    f.setFullName(Console::readRequired("Full name: "));
    f.setEmail(Console::readRequired("Email: "));
    f.setPhone(Console::readLine("Mobile (optional): "));
    f.setDesignation(Console::readOptional("Designation", "Assistant Professor"));
    f.setQualification(Console::readLine("Qualification (optional): "));
    f.setSpecialization(Console::readLine("Specialization (optional): "));
    const std::string password = PasswordHasher::generateTemporaryPassword();
    const Faculty created = ctx_.users().createFaculty(f, password, true, user_);
    Console::success("Faculty created. Login: " + created.username() + "   Temporary password: " + password);
}

// ================================================================= courses ===
void AdminDashboard::courseMenu() {
    Console::heading("Courses & enrollment");
    const int c = Console::menu({"View curriculum by semester", "Add a course", "Assign faculty to a course",
                                 "Auto-enroll a semester into its courses"});
    if (c == 1) {
        const auto names = ctx_.users().facultyNames();
        Table t({"Sem", "Code", "Course", "Cr", "Type", "Faculty"});
        t.align(0, Table::Align::Right).align(3, Table::Align::Right).maxWidth(2, 40);
        int credits = 0;
        for (const auto& course : ctx_.academic().listCourses(chooseSemester("Semester", true))) {
            const auto it = names.find(course.facultyId());
            credits += course.credits();
            t.addRow({std::to_string(course.semester()), course.code(), course.name(), std::to_string(course.credits()),
                      course.type(), it == names.end() ? "(not assigned)" : it->second});
        }
        t.print();
        std::cout << "  Total credits: " << credits << '\n';
    } else if (c == 2) {
        addCourse();
    } else if (c == 3) {
        const auto course = chooseCourse(ctx_.academic().listCourses(chooseSemester("Semester", false)));
        if (!course) return;
        const auto faculty = ctx_.users().listFaculty();
        std::vector<std::string> options;
        for (const auto& f : faculty) options.push_back(f.displayName() + " - " + f.specialization());
        const int pick = Console::menu(options, "Cancel");
        if (pick == 0) return;
        ctx_.academic().assignFaculty(course->id(), faculty[static_cast<std::size_t>(pick - 1)].id(), user_);
        Console::success(course->code() + " assigned to " + faculty[static_cast<std::size_t>(pick - 1)].fullName() + ".");
    } else if (c == 4) {
        const int sem = chooseSemester("Semester", false);
        const std::string year = Console::readOptional("Academic year", ctx_.profile().academicYear());
        Console::success(std::to_string(ctx_.academic().autoEnrollSemester(sem, year, user_)) +
                         " new enrollment(s) created (existing ones were kept).");
    }
}

void AdminDashboard::addCourse() {
    Course c;
    c.setCode(Console::readRequired("Course code (e.g. CS309): "));
    c.setName(Console::readRequired("Course name: "));
    c.setSemester(static_cast<int>(Console::readInt("Semester (1-8): ", 1, 8)));
    c.setCredits(static_cast<int>(Console::readInt("Credits (1-10): ", 1, 10)));
    const int type = Console::menu(Course::types(), "Cancel");
    if (type == 0) return;
    c.setType(Course::types()[static_cast<std::size_t>(type - 1)]);
    const Course created = ctx_.academic().createCourse(c, user_);
    Console::success("Course " + created.label() + " added. Use 'Assign faculty' and 'Auto-enroll' next.");
}

// ==================================================================== fees ===
void AdminDashboard::feeMenu() {
    Console::heading("Fees & payments");
    const int c = Console::menu({"Bill a fee to a whole semester", "Record a payment", "Student fee statement",
                                 "Pending dues report"});
    if (c == 1) {
        const int sem = chooseSemester("Semester", false);
        const std::string description = Console::readRequired("Fee description (e.g. Tuition Fee): ");
        const double amount = Console::readDouble("Amount in Rs.: ", 1, 10000000);
        const Date due = Console::readDate("Due date", Date());
        const std::string year = Console::readOptional("Academic year", ctx_.profile().academicYear());
        const int n = ctx_.fees().assignToSemester(sem, year, description, amount, due, user_);
        Console::success(description + " billed to " + std::to_string(n) + " student(s).");
    } else if (c == 2) {
        recordPayment();
    } else if (c == 3) {
        const auto s = findStudentInteractive();
        if (s) printFeeStatements(ctx_.fees().statementsFor(s->id()));
    } else if (c == 4) {
        Table t({"PRN", "Name", "Sem", "Billed", "Paid", "Balance", "Overdue"});
        for (std::size_t i = 3; i < 6; ++i) t.align(i, Table::Align::Right);
        double total = 0;
        for (const auto& d : ctx_.fees().pendingDues(chooseSemester("Semester", true))) {
            total += d.balance;
            t.addRow({d.student.prn(), d.student.fullName(), std::to_string(d.student.semester()), str::formatMoney(d.billed),
                      str::formatMoney(d.paid), str::formatMoney(d.balance), d.overdue ? "YES" : ""});
        }
        t.print();
        std::cout << "  Total pending: " << str::formatMoney(total) << '\n';
    }
}

void AdminDashboard::recordPayment() {
    const auto s = findStudentInteractive();
    if (!s) return;
    const auto statements = ctx_.fees().statementsFor(s->id());
    printFeeStatements(statements);
    const long long feeId = Console::readInt("Fee ID to pay: ", 1, 1000000000);
    bool belongs = false;
    for (const auto& st : statements) belongs = belongs || st.fee.id() == feeId;
    if (!belongs) throw ValidationException("That fee ID does not belong to " + s->prn() + ".");
    const double amount = Console::readDouble("Amount received (Rs.): ", 1, 10000000);
    const int mode = Console::menu(Payment::modes(), "Cancel");
    if (mode == 0) return;
    const std::string reference = Console::readLine("Transaction / cheque reference (optional): ");
    const Date paidOn = Console::readDate("Payment date", Date::today());
    const Payment p = ctx_.fees().recordPayment(feeId, amount, Payment::modes()[static_cast<std::size_t>(mode - 1)],
                                                reference, paidOn, user_);
    Console::success("Payment recorded. Receipt No: " + p.receiptNumber() + "  (" + str::formatMoney(p.amount()) + ")");
}

// ================================================================= notices ===
void AdminDashboard::noticeMenu() {
    Console::heading("Notices");
    const int c = Console::menu({"View all notices", "Post a notice", "Delete a notice"});
    if (c == 1) showNotices();
    if (c == 2) postNotice();
    if (c == 3) {
        const long long id = Console::readInt("Notice # to delete: ", 1, 1000000000);
        if (Console::confirm("Delete notice #" + std::to_string(id) + "?", false)) {
            ctx_.notices().remove(id, user_);
            Console::success("Notice deleted.");
        }
    }
}

void AdminDashboard::radar() {
    Console::heading("Student Success Radar (early-warning system)");
    Console::info("Score = attendance shortage + weak internal/mid-sem marks + backlogs + overdue fees.");
    printRadar(ctx_.reports().successRadar(ctx_.users().listStudents(chooseSemester("Semester", true))));
}

// ============================================================ certificates ===
void AdminDashboard::certificateRequests() {
    Console::heading("Certificate requests");
    const auto pending = ctx_.documents().pending();
    Table t({"ID", "Student ID", "Document", "Purpose", "Requested"});
    for (const auto& d : pending) {
        t.addRow({std::to_string(d.id()), std::to_string(d.studentId()), d.typeTitle(), d.purpose(),
                  DateTime::formatIsoAsLocal(d.requestedAt())});
    }
    t.print();
    if (pending.empty()) return;
    const long long id = Console::readIntOr("Request ID to process (0 = back)", 0, 1000000000, 0);
    if (id == 0) return;
    const auto doc = ctx_.documents().find(id);
    if (!doc || doc->status() != "pending") throw NotFoundException("No pending request #" + std::to_string(id) + ".");
    const auto student = ctx_.users().findStudent(doc->studentId());
    if (!student) throw NotFoundException("Student not found.");
    std::cout << "  " << student->prn() << "  " << student->fullName() << "  |  " << student->headline() << '\n';
    const int action = Console::menu({"Approve and generate certificate", "Reject"}, "Back");
    if (action == 1) {
        const auto approved = ctx_.documents().approve(
            id, ReportService::bonafideDigest(*doc, *student, ctx_.profile().academicYear()), user_);
        const auto path = ctx_.reports().writeBonafide(approved, *student);
        Console::success("Approved. Verification code " + approved.verificationCode() + "\n     Certificate: " + path.string());
    } else if (action == 2) {
        ctx_.documents().reject(id, Console::readRequired("Reason: "), user_);
        Console::success("Request rejected.");
    }
}

// ================================================================ security ===
void AdminDashboard::securityMenu() {
    Console::heading("Accounts, security & audit trail");
    const int c = Console::menu({"List all accounts", "Reset a password", "Unlock an account",
                                 "Recent activity (audit trail)", "Verify audit-trail integrity"});
    if (c == 1) {
        Table t({"ID", "Username", "Name", "Role", "Status", "Last login"});
        t.align(0, Table::Align::Right);
        for (const auto& a : ctx_.users().listAccounts()) {
            t.addRow({std::to_string(a.id), a.username, a.fullName, roleTitle(a.role),
                      a.locked ? "LOCKED" : (a.active ? "Active" : "Inactive"), DateTime::formatIsoAsLocal(a.lastLoginAt)});
        }
        t.print();
    } else if (c == 2 || c == 3) {
        const auto row = ctx_.users().findAccountByLogin(Console::readRequired("Username or email: "));
        if (!row) throw NotFoundException("No such account.");
        if (c == 2) {
            const std::string temp = ctx_.auth().resetPassword(row->getInt("id"), user_);
            Console::success("Temporary password for " + row->getString("username") + ": " + temp +
                             "  (must be changed at next login)");
        } else {
            ctx_.auth().unlock(row->getInt("id"), user_);
            Console::success(row->getString("username") + " unlocked.");
        }
    } else if (c == 4) {
        Table t({"#", "When", "By", "Action", "Details"});
        t.maxWidth(4, 46);
        for (const auto& e : ctx_.audit().recent(20)) {
            t.addRow({std::to_string(e.id()), DateTime::formatIsoAsLocal(e.createdAt()), e.actorName(), e.action(), e.details()});
        }
        t.print();
    } else if (c == 5) {
        const auto result = ctx_.audit().verifyChain();
        if (result.intact) {
            Console::success("Audit trail intact: " + std::to_string(result.entries) +
                             " entries verified with SHA-256 hash chaining. No tampering detected.");
        } else {
            Console::error("TAMPERING DETECTED - " + result.problem);
        }
        std::cout << '\n' << Console::paint("  build 1.0.0 . created by Vedant Pravin Surve", Color::Gray) << '\n';
    }
}

}  // namespace portal
