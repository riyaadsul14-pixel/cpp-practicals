#include "db/Query.hpp"

#include "core/StringUtil.hpp"

namespace portal {

Query& Query::select(const std::string& columns) {
    select_ = columns;
    return *this;
}

Query& Query::addFilter(const std::string& column, const std::string& expression) {
    filters_.emplace_back(column, expression);
    return *this;
}

Query& Query::eq(const std::string& column, const std::string& value) { return addFilter(column, "eq." + value); }
Query& Query::eq(const std::string& column, long long value) { return addFilter(column, "eq." + std::to_string(value)); }
Query& Query::eqBool(const std::string& column, bool value) { return addFilter(column, value ? "is.true" : "is.false"); }
Query& Query::neq(const std::string& column, const std::string& value) { return addFilter(column, "neq." + value); }
Query& Query::gt(const std::string& column, long long value) { return addFilter(column, "gt." + std::to_string(value)); }
Query& Query::gte(const std::string& column, const std::string& value) { return addFilter(column, "gte." + value); }
Query& Query::lte(const std::string& column, const std::string& value) { return addFilter(column, "lte." + value); }
Query& Query::lt(const std::string& column, const std::string& value) { return addFilter(column, "lt." + value); }
Query& Query::ilike(const std::string& column, const std::string& pattern) { return addFilter(column, "ilike." + pattern); }
Query& Query::isNull(const std::string& column) { return addFilter(column, "is.null"); }

Query& Query::in(const std::string& column, const std::vector<long long>& values) {
    std::vector<std::string> parts;
    parts.reserve(values.size());
    for (const long long v : values) parts.push_back(std::to_string(v));
    return addFilter(column, "in.(" + str::join(parts, ",") + ")");
}

Query& Query::inText(const std::string& column, const std::vector<std::string>& values) {
    std::vector<std::string> parts;
    parts.reserve(values.size());
    for (const auto& v : values) parts.push_back("\"" + str::replaceAll(v, "\"", "\\\"") + "\"");
    return addFilter(column, "in.(" + str::join(parts, ",") + ")");
}

Query& Query::order(const std::string& column, bool ascending) {
    orders_.push_back(column + (ascending ? ".asc" : ".desc"));
    return *this;
}

Query& Query::limit(int count) {
    limit_ = count;
    return *this;
}

Query& Query::offset(int count) {
    offset_ = count;
    return *this;
}

std::string Query::build(bool includeSelect) const {
    std::vector<std::string> parts;
    if (includeSelect) parts.push_back("select=" + str::urlEncode(select_.empty() ? "*" : select_));
    for (const auto& [column, expression] : filters_) parts.push_back(str::urlEncode(column) + "=" + str::urlEncode(expression));
    if (!orders_.empty()) parts.push_back("order=" + str::urlEncode(str::join(orders_, ",")));
    if (limit_ >= 0) parts.push_back("limit=" + std::to_string(limit_));
    if (offset_ > 0) parts.push_back("offset=" + std::to_string(offset_));
    return str::join(parts, "&");
}

}  // namespace portal
