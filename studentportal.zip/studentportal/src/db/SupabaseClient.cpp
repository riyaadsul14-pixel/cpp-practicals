#include "db/SupabaseClient.hpp"

#include <chrono>
#include <thread>

#include "core/Date.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"

namespace portal {

namespace {

/// "0-999/5760" -> 5760 ; "*/0" -> 0 ; returns -1 when unknown
long long totalFromContentRange(const std::string& header) {
    const auto slash = header.find('/');
    if (slash == std::string::npos) return -1;
    long long total = -1;
    return str::parseInt(header.substr(slash + 1), total) ? total : -1;
}

/// PostgREST detail "Key (email)=(a@b.com) already exists." -> "email 'a@b.com'"
std::string describeDuplicate(const std::string& details) {
    const auto open = details.find('(');
    const auto close = details.find(")=(");
    const auto end = details.rfind(')');
    if (open == std::string::npos || close == std::string::npos || end == std::string::npos || end <= close + 3) {
        return details;
    }
    const std::string column = details.substr(open + 1, close - open - 1);
    const std::string value = details.substr(close + 3, end - close - 3);
    return str::replaceAll(column, "_", " ") + " '" + value + "'";
}

}  // namespace

SupabaseClient::SupabaseClient(std::string projectUrl, std::string apiKey, std::unique_ptr<HttpClient> http)
    : url_(str::trim(projectUrl)), key_(str::trim(apiKey)), http_(std::move(http)) {
    while (!url_.empty() && url_.back() == '/') url_.pop_back();
    if (str::endsWith(url_, "/rest/v1")) url_.resize(url_.size() - 8);
    if (!str::startsWith(url_, "https://") && !str::startsWith(url_, "http://")) {
        throw ConfigException("SUPABASE_URL must look like https://<project-ref>.supabase.co");
    }
    if (key_.empty()) throw ConfigException("SUPABASE_KEY is empty");
    if (!http_) throw ConfigException("No HTTP client available");
}

HttpResponse SupabaseClient::execute(const std::string& method, const std::string& table, const std::string& query,
                                     const std::string& body, const HeaderList& extraHeaders) const {
    HttpRequest request;
    request.method = method;
    request.url = url_ + "/rest/v1/" + table + (query.empty() ? "" : "?" + query);
    request.headers = {{"apikey", key_}, {"Authorization", "Bearer " + key_}, {"Accept", "application/json"}};
    if (!body.empty()) request.headers.emplace_back("Content-Type", "application/json");
    request.headers.insert(request.headers.end(), extraHeaders.begin(), extraHeaders.end());
    request.body = body;

    // Reads are safe to retry; writes are sent exactly once.
    const int maxAttempts = method == "GET" ? 3 : 1;
    for (int attempt = 1;; ++attempt) {
        try {
            ++requests_;
            HttpResponse response = http_->send(request);
            long long serverEpoch = 0;
            if (DateTime::parseHttpDate(response.header("Date"), serverEpoch)) {
                clockSkew_ = serverEpoch - DateTime::nowEpoch();
            }
            const bool transient = response.status == 502 || response.status == 503 || response.status == 504;
            if (!transient || attempt >= maxAttempts) return response;
        } catch (const NetworkException&) {
            if (attempt >= maxAttempts) throw;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(400 * attempt));
    }
}

void SupabaseClient::raiseError(const HttpResponse& response, const std::string& action) const {
    std::string code, message, details, hint;
    try {
        const Json error = Json::parse(response.body);
        code = error.getString("code");
        message = error.getString("message");
        details = error.getString("details");
        hint = error.getString("hint");
    } catch (const JsonException&) {
        message = str::truncate(str::trim(response.body), 300);
    }
    const int status = response.status;
    if (code == "PGRST205" || code == "42P01") {
        throw DatabaseException("A database table is missing (while " + action +
                                    "). Run database/schema.sql once in the Supabase SQL Editor.",
                                status, code);
    }
    if (code == "42501") {
        throw DatabaseException("Permission denied while " + action +
                                    ". Use the secret/service_role key as SUPABASE_KEY and re-run database/schema.sql.",
                                status, code);
    }
    if (status == 401 || status == 403) {
        throw DatabaseException("Supabase rejected the API key (HTTP " + std::to_string(status) +
                                    "). Check SUPABASE_KEY in config/portal.conf. " + message,
                                status, code);
    }
    if (code == "23505") {
        throw DatabaseException("Duplicate entry: " + describeDuplicate(details) + " already exists.", status, code);
    }
    if (code == "23503") {
        throw DatabaseException("This record is linked to other data and cannot be changed that way. " + details,
                                status, code);
    }
    if (code == "23514") {
        throw DatabaseException("A value is outside the allowed range (" + message + ").", status, code);
    }
    if (code == "22P02" || code == "22007" || code == "22008" || code == "22003") {
        throw DatabaseException("Invalid value: " + message, status, code);
    }
    std::string text = "Database error while " + action + ": " + (message.empty() ? "unknown error" : message);
    if (!details.empty()) text += " (" + details + ")";
    if (!hint.empty()) text += " Hint: " + hint;
    text += " [HTTP " + std::to_string(status) + (code.empty() ? "" : ", " + code) + "]";
    throw DatabaseException(text, status, code);
}

Json SupabaseClient::parseRows(const HttpResponse& response, const std::string& action) const {
    if (!response.ok()) raiseError(response, action);
    if (str::trim(response.body).empty()) return Json::array();
    Json rows = Json::parse(response.body);
    if (rows.isObject()) {
        Json wrapped = Json::array();
        wrapped.push(rows);
        return wrapped;
    }
    if (!rows.isArray()) throw DatabaseException("Unexpected response while " + action, response.status);
    return rows;
}

Json SupabaseClient::select(const std::string& table, const Query& query) const {
    const std::string action = "reading " + table;
    Query base = query;
    if (!base.hasOrder()) base.order("id");  // stable ordering is required for paging

    if (base.limitValue() >= 0) return parseRows(execute("GET", table, base.build(), "", {}), action);

    Json all = Json::array();
    long long total = -1;
    int offset = 0;
    while (true) {
        Query page = base;
        page.limit(kPageSize).offset(offset);
        HeaderList headers;
        if (offset == 0) headers.emplace_back("Prefer", "count=exact");
        const HttpResponse response = execute("GET", table, page.build(), "", headers);
        const Json rows = parseRows(response, action);
        if (offset == 0) total = totalFromContentRange(response.header("Content-Range"));
        for (const auto& row : rows.items()) all.push(row);
        offset += static_cast<int>(rows.size());
        const bool done = rows.size() == 0 || (total >= 0 ? static_cast<long long>(all.size()) >= total
                                                          : rows.size() < static_cast<std::size_t>(kPageSize));
        if (done) break;
    }
    return all;
}

Json SupabaseClient::insert(const std::string& table, const Json& rows, const std::string& returnColumns) {
    Json list = rows;
    if (rows.isObject()) {
        list = Json::array();
        list.push(rows);
    }
    Json inserted = Json::array();
    const auto& items = list.items();
    for (std::size_t start = 0; start < items.size(); start += kInsertBatch) {
        Json batch = Json::array();
        for (std::size_t i = start; i < items.size() && i < start + kInsertBatch; ++i) batch.push(items[i]);
        const HttpResponse response = execute("POST", table, "select=" + str::urlEncode(returnColumns), batch.dump(),
                                              {{"Prefer", "return=representation"}});
        const Json rowsBack = parseRows(response, "saving to " + table);
        for (const auto& row : rowsBack.items()) inserted.push(row);
    }
    return inserted;
}

Json SupabaseClient::upsert(const std::string& table, const Json& rows, const std::string& onConflict,
                            bool ignoreDuplicates, const std::string& returnColumns) {
    Json list = rows;
    if (rows.isObject()) {
        list = Json::array();
        list.push(rows);
    }
    const std::string prefer = std::string("resolution=") + (ignoreDuplicates ? "ignore" : "merge") +
                               "-duplicates,return=representation";
    Json saved = Json::array();
    const auto& items = list.items();
    for (std::size_t start = 0; start < items.size(); start += kInsertBatch) {
        Json batch = Json::array();
        for (std::size_t i = start; i < items.size() && i < start + kInsertBatch; ++i) batch.push(items[i]);
        const std::string query =
            "on_conflict=" + str::urlEncode(onConflict) + "&select=" + str::urlEncode(returnColumns);
        const HttpResponse response = execute("POST", table, query, batch.dump(), {{"Prefer", prefer}});
        const Json rowsBack = parseRows(response, "saving to " + table);
        for (const auto& row : rowsBack.items()) saved.push(row);
    }
    return saved;
}

Json SupabaseClient::update(const std::string& table, const Query& filter, const Json& changes,
                            const std::string& returnColumns) {
    if (!filter.hasFilters()) throw DatabaseException("Refusing to update every row of " + table, 0);
    const std::string query = filter.build(false) + "&select=" + str::urlEncode(returnColumns);
    const HttpResponse response =
        execute("PATCH", table, query, changes.dump(), {{"Prefer", "return=representation"}});
    return parseRows(response, "updating " + table);
}

std::size_t SupabaseClient::remove(const std::string& table, const Query& filter) {
    if (!filter.hasFilters()) throw DatabaseException("Refusing to delete every row of " + table, 0);
    const std::string query = filter.build(false) + "&select=id";
    const HttpResponse response = execute("DELETE", table, query, "", {{"Prefer", "return=representation"}});
    return parseRows(response, "deleting from " + table).size();
}

long long SupabaseClient::count(const std::string& table, const Query& filter) const {
    Query q = filter;
    q.select("id").limit(1);
    const HttpResponse response = execute("GET", table, q.build(), "", {{"Prefer", "count=exact"}});
    if (!response.ok()) raiseError(response, "counting " + table);
    const long long total = totalFromContentRange(response.header("Content-Range"));
    if (total < 0) throw DatabaseException("Supabase did not return a row count for " + table, response.status);
    return total;
}

long long SupabaseClient::serverNow() const { return DateTime::nowEpoch() + clockSkew_; }

bool SupabaseClient::tableExists(const std::string& table) const {
    const HttpResponse response = execute("GET", table, "select=*&limit=0", "", {});
    if (response.ok()) return true;
    try {
        raiseError(response, "checking table " + table);
    } catch (const DatabaseException& e) {
        if (e.isMissingTable() || response.status == 404) return false;
        throw;
    }
}

}  // namespace portal
