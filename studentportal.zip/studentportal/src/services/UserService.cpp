#include "services/UserService.hpp"

#include <algorithm>
#include <set>

#include "core/Crypto.hpp"
#include "core/Date.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

UserService::UserService(SupabaseClient& db, AuditService& audit)
    : db_(db), audit_(audit), students_(db), faculty_(db) {}

// =============================================================== students ===
std::vector<Student> UserService::listStudents(int semester) const {
    Query q;
    if (semester > 0) q.eq("semester", semester);
    q.order("prn");
    return students_.find(q);
}

std::optional<Student> UserService::findStudent(long long id) const { return students_.findById(id); }

std::optional<Student> UserService::findStudentByPrn(const std::string& prn) const {
    return students_.findOne(Query().eq("prn", str::toUpper(str::trim(prn))));
}

std::vector<Student> UserService::searchStudents(const std::string& text) const {
    const std::string needle = str::trim(text);
    if (needle.empty()) return {};
    if (auto exact = findStudentByPrn(needle)) return {*exact};
    std::vector<Student> matches;
    for (const auto& s : listStudents()) {
        if (str::containsIgnoreCase(s.fullName(), needle) || str::containsIgnoreCase(s.prn(), needle) ||
            str::containsIgnoreCase(s.email(), needle)) {
            matches.push_back(s);
        }
    }
    return matches;
}

std::vector<Student> UserService::studentsByIds(const std::vector<long long>& ids) const {
    auto list = students_.findByIds(ids);
    std::sort(list.begin(), list.end(), [](const Student& a, const Student& b) { return a.prn() < b.prn(); });
    return list;
}

std::vector<Json> UserService::allAccountRows(const std::string& columns) const {
    return db_.select(User::ACCOUNT_TABLE, Query().select(columns)).items();
}

ImportResult UserService::createStudents(std::vector<Student> students, const std::string& password, bool mustChange,
                                         const User* actor) {
    ImportResult result;
    const std::string strength = PasswordHasher::strengthProblem(password);
    if (!strength.empty()) throw ValidationException("Initial password rejected: " + strength);

    // ---- duplicate checks (database + within the batch) -----------------
    std::set<std::string> usernames, emails, prns;
    for (const auto& row : allAccountRows("username,email")) {
        usernames.insert(row.getString("username"));
        emails.insert(row.getString("email"));
    }
    const Json prnRows = db_.select(Student::TABLE, Query().select("prn"));
    for (const auto& row : prnRows.items()) prns.insert(row.getString("prn"));

    std::vector<Student> accepted;
    for (auto& s : students) {
        if (s.prn().empty() || s.fullName().empty() || s.email().empty()) {
            result.errors.push_back("PRN " + s.prn() + ": PRN, name and email are required.");
            continue;
        }
        if (s.admissionYear() == 0) {
            result.errors.push_back("PRN " + s.prn() + ": admission year is required.");
            continue;
        }
        s.setUsername(s.prn());
        if (prns.count(s.prn()) || usernames.count(s.username())) {
            result.errors.push_back("PRN " + s.prn() + " already exists - skipped.");
            continue;
        }
        if (emails.count(s.email())) {
            result.errors.push_back("PRN " + s.prn() + ": email " + s.email() + " already in use - skipped.");
            continue;
        }
        prns.insert(s.prn());
        usernames.insert(s.username());
        emails.insert(s.email());
        s.setPasswordHash(PasswordHasher::hash(password));
        s.setMustChangePassword(mustChange);
        s.setActive(true);
        accepted.push_back(s);
    }
    if (accepted.empty()) return result;

    // ---- insert users rows, then students rows (with rollback) -----------
    Json accounts = Json::array();
    for (const auto& s : accepted) accounts.push(s.accountJson(true));
    const Json insertedAccounts = db_.insert(User::ACCOUNT_TABLE, accounts, "id,username");
    std::map<std::string, long long> idByUsername;
    std::vector<long long> newIds;
    for (const auto& row : insertedAccounts.items()) {
        idByUsername[row.getString("username")] = row.getInt("id");
        newIds.push_back(row.getInt("id"));
    }
    try {
        Json profiles = Json::array();
        for (auto& s : accepted) {
            s.setId(idByUsername.at(s.username()));
            profiles.push(s.toJson());
        }
        db_.insert(Student::TABLE, profiles, "id");
    } catch (...) {
        if (!newIds.empty()) db_.remove(User::ACCOUNT_TABLE, Query().in("id", newIds));  // compensate
        throw;
    }
    result.added = static_cast<int>(accepted.size());
    if (actor) audit_.record(*actor, "STUDENTS_CREATED", std::to_string(result.added) + " student account(s) created");
    return result;
}

Student UserService::createStudent(Student student, const std::string& password, bool mustChange, const User& actor) {
    const ImportResult result = createStudents({student}, password, mustChange, &actor);
    if (result.added == 0) throw ValidationException(result.errors.empty() ? "Student not created." : result.errors.front());
    auto created = findStudentByPrn(student.prn());
    if (!created) throw NotFoundException("Student was created but could not be re-loaded.");
    return *created;
}

Student UserService::updateStudent(const Student& student, const User& actor) {
    Json account = Json::object();
    account["full_name"] = student.fullName();
    account["email"] = student.email();
    account["phone"] = student.phone().empty() ? Json() : Json(student.phone());
    db_.update(User::ACCOUNT_TABLE, Query().eq("id", student.id()), account, "id");
    Json profile = student.toJson();
    profile.erase("id");
    const Student updated = students_.update(student.id(), profile);
    audit_.record(actor, "STUDENT_UPDATED", "PRN " + student.prn());
    return updated;
}

int UserService::promoteSemester(int fromSemester, const User& actor) {
    Validator::require(fromSemester >= 1 && fromSemester <= 7,
                       "Only semesters 1-7 can be promoted (semester 8 students graduate).");
    Json change = Json::object();
    change["semester"] = fromSemester + 1;
    const Json rows = db_.update(Student::TABLE, Query().eq("semester", fromSemester), change, "id");
    const int count = static_cast<int>(rows.size());
    audit_.record(actor, "SEMESTER_PROMOTED",
                  std::to_string(count) + " students moved from semester " + std::to_string(fromSemester) + " to " +
                      std::to_string(fromSemester + 1));
    return count;
}

Student UserService::studentFromRecord(const CsvRecord& r) {
    Student s;
    s.setPrn(r.get("prn"));
    s.setFullName(r.get("full_name"));
    s.setEmail(r.get("email"));
    s.setPhone(r.get("phone"));
    long long semester = 0, year = 0;
    Validator::require(str::parseInt(r.get("semester"), semester), "semester must be a number");
    s.setSemester(static_cast<int>(semester));
    s.setDivision(r.get("division").empty() ? "A" : r.get("division"));
    Validator::require(str::parseInt(r.get("admission_year"), year), "admission_year must be a number");
    s.setAdmissionYear(static_cast<int>(year));
    if (!r.get("date_of_birth").empty()) s.setDateOfBirth(Date::parse(r.get("date_of_birth")));
    s.setGender(r.get("gender"));
    s.setGuardianName(r.get("guardian_name"));
    s.setGuardianPhone(r.get("guardian_phone"));
    s.setAddress(r.get("address"));
    return s;
}

ImportResult UserService::importStudentsCsv(const std::filesystem::path& csv, const std::string& password,
                                            const User& actor) {
    std::vector<Student> parsed;
    std::vector<std::string> errors;
    for (const auto& record : Csv::readRecords(csv)) {
        try {
            parsed.push_back(studentFromRecord(record));
        } catch (const ValidationException& e) {
            errors.push_back("Row " + std::to_string(record.number()) + " (" + record.get("prn") + "): " + e.what());
        }
    }
    ImportResult result = createStudents(parsed, password, true, &actor);
    result.errors.insert(result.errors.begin(), errors.begin(), errors.end());
    return result;
}

// ================================================================ faculty ===
std::vector<Faculty> UserService::listFaculty() const { return faculty_.find(Query().order("employee_code")); }

std::optional<Faculty> UserService::findFaculty(long long id) const { return faculty_.findById(id); }

std::optional<Faculty> UserService::findFacultyByCode(const std::string& code) const {
    return faculty_.findOne(Query().eq("employee_code", str::toUpper(str::trim(code))));
}

Faculty UserService::createFaculty(Faculty f, const std::string& password, bool mustChange, const User& actor) {
    const std::string strength = PasswordHasher::strengthProblem(password);
    if (!strength.empty()) throw ValidationException(strength);
    Validator::require(!f.employeeCode().empty() && !f.fullName().empty() && !f.email().empty(),
                       "Employee code, name and email are required.");
    if (findFacultyByCode(f.employeeCode())) throw ValidationException("Employee code already exists.");
    f.setUsername(f.employeeCode());
    f.setPasswordHash(PasswordHasher::hash(password));
    f.setMustChangePassword(mustChange);
    const long long id = insertAccount(f);
    f.setId(id);
    try {
        const Faculty created = faculty_.insert(f);
        audit_.record(actor, "FACULTY_CREATED", f.displayName());
        return created;
    } catch (...) {
        db_.remove(User::ACCOUNT_TABLE, Query().eq("id", id));
        throw;
    }
}

Faculty UserService::updateFaculty(const Faculty& f, const User& actor) {
    Json account = Json::object();
    account["full_name"] = f.fullName();
    account["email"] = f.email();
    account["phone"] = f.phone().empty() ? Json() : Json(f.phone());
    db_.update(User::ACCOUNT_TABLE, Query().eq("id", f.id()), account, "id");
    Json profile = f.toJson();
    profile.erase("id");
    const Faculty updated = faculty_.update(f.id(), profile);
    audit_.record(actor, "FACULTY_UPDATED", f.displayName());
    return updated;
}

std::map<long long, std::string> UserService::facultyNames() const {
    std::map<long long, std::string> names;
    const Json facultyRows = db_.select(Faculty::TABLE, Query().select("id,users(full_name)"));
    for (const auto& row : facultyRows.items()) {
        names[row.getInt("id")] = row["users"].getString("full_name");
    }
    return names;
}

// =============================================================== accounts ===
long long UserService::insertAccount(const User& user) {
    const Json rows = db_.insert(User::ACCOUNT_TABLE, user.accountJson(true), "id");
    if (rows.size() == 0) throw DatabaseException("Creating the login account returned no id", 0);
    return rows.at(0).getInt("id");
}

std::vector<AccountSummary> UserService::listAccounts() const {
    const long long now = db_.serverNow();
    std::vector<AccountSummary> out;
    const Json rows = db_.select(User::ACCOUNT_TABLE,
                                 Query()
                                     .select("id,username,full_name,email,role,is_active,locked_until,last_login_at")
                                     .order("role")
                                     .order("username"));
    for (const auto& row : rows.items()) {
        AccountSummary a;
        a.id = row.getInt("id");
        a.username = row.getString("username");
        a.fullName = row.getString("full_name");
        a.email = row.getString("email");
        a.role = roleFromString(row.getString("role"));
        a.active = row.getBool("is_active", true);
        a.locked = row.getInt("locked_until", 0) > now;
        a.lastLoginAt = row.getString("last_login_at");
        out.push_back(a);
    }
    return out;
}

std::optional<Json> UserService::findAccountRow(long long userId) const {
    const Json rows = db_.select(User::ACCOUNT_TABLE, Query().eq("id", userId).limit(1));
    if (rows.size() == 0) return std::nullopt;
    return rows.at(0);
}

std::optional<Json> UserService::findAccountByLogin(const std::string& usernameOrEmail) const {
    const std::string value = str::toLower(str::trim(usernameOrEmail));
    if (value.empty()) return std::nullopt;
    Query q;
    q.eq(value.find('@') != std::string::npos ? "email" : "username", value).limit(1);
    const Json rows = db_.select(User::ACCOUNT_TABLE, q);
    if (rows.size() == 0) return std::nullopt;
    return rows.at(0);
}

std::unique_ptr<User> UserService::loadUser(const Json& accountRow) const {
    const long long id = accountRow.getInt("id");
    switch (roleFromString(accountRow.getString("role"))) {
        case Role::Student: {
            auto s = findStudent(id);
            if (!s) throw NotFoundException("Student profile missing for account #" + std::to_string(id));
            return std::make_unique<Student>(*s);
        }
        case Role::Faculty: {
            auto f = findFaculty(id);
            if (!f) throw NotFoundException("Faculty profile missing for account #" + std::to_string(id));
            return std::make_unique<Faculty>(*f);
        }
        case Role::Admin:
            return std::make_unique<Admin>(Admin::fromJson(accountRow));
    }
    throw NotFoundException("Unknown role");
}

void UserService::setActive(long long userId, bool active, const User& actor) {
    Json change = Json::object();
    change["is_active"] = active;
    const Json rows = db_.update(User::ACCOUNT_TABLE, Query().eq("id", userId), change, "id,username");
    if (rows.size() == 0) throw NotFoundException("Account not found.");
    audit_.record(actor, active ? "ACCOUNT_ACTIVATED" : "ACCOUNT_DEACTIVATED", rows.at(0).getString("username"));
}

void UserService::updateContact(User& user, const std::string& email, const std::string& phone) {
    const std::string oldEmail = user.email();
    const std::string oldPhone = user.phone();
    try {
        user.setEmail(email);
        user.setPhone(phone);
        Json change = Json::object();
        change["email"] = user.email();
        change["phone"] = user.phone().empty() ? Json() : Json(user.phone());
        db_.update(User::ACCOUNT_TABLE, Query().eq("id", user.id()), change, "id");
        audit_.record(user, "CONTACT_UPDATED", user.username());
    } catch (...) {
        user.setEmail(oldEmail);  // keep the in-memory object consistent with the database
        if (oldPhone.empty()) user.setPhone("");
        else user.setPhone(oldPhone);
        throw;
    }
}

void UserService::deleteUser(long long userId, const User& actor) {
    const auto row = findAccountRow(userId);
    if (!row) throw NotFoundException("Account not found.");
    db_.remove(User::ACCOUNT_TABLE, Query().eq("id", userId));
    audit_.record(actor, "ACCOUNT_DELETED", row->getString("username") + " (" + row->getString("full_name") + ")");
}

long long UserService::countAdmins() const { return db_.count(User::ACCOUNT_TABLE, Query().eq("role", "admin")); }

Admin UserService::createAdmin(Admin admin, const std::string& password) {
    const std::string strength = PasswordHasher::strengthProblem(password);
    if (!strength.empty()) throw ValidationException(strength);
    admin.setPasswordHash(PasswordHasher::hash(password));
    admin.setId(insertAccount(admin));
    audit_.record(admin, "ADMIN_CREATED", admin.username());
    return admin;
}

}  // namespace portal
