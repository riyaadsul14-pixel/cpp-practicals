#include "services/AttendanceService.hpp"

#include <map>
#include <set>

#include "core/Exceptions.hpp"
#include "core/Validator.hpp"

namespace portal {

int AttendanceService::mark(long long courseId, const Date& date,
                            const std::vector<std::pair<long long, bool>>& presence, const User& actor) {
    Validator::require(!date.isEmpty(), "Attendance date is required.");
    Validator::require(date <= Date::today(), "Attendance cannot be marked for a future date.");
    Validator::require(Date::today() - date <= 30, "Attendance older than 30 days cannot be changed.");
    Validator::require(!presence.empty(), "No students to mark.");
    const auto course = academic_.findCourse(courseId);
    if (!course) throw NotFoundException("Course not found.");
    if (actor.role() == Role::Faculty && course->facultyId() != actor.id()) {
        throw ValidationException("You can only mark attendance for courses assigned to you.");
    }

    std::set<long long> enrolled;
    for (const auto& s : academic_.studentsInCourse(courseId)) enrolled.insert(s.id());
    std::vector<AttendanceRecord> rows;
    std::set<long long> seen;
    int present = 0;
    for (const auto& [studentId, isPresent] : presence) {
        if (!enrolled.count(studentId)) throw ValidationException("Student #" + std::to_string(studentId) + " is not enrolled in " + course->code() + ".");
        if (!seen.insert(studentId).second) continue;  // ignore duplicates
        rows.emplace_back(courseId, studentId, date, isPresent, actor.id());
        if (isPresent) ++present;
    }
    records_.upsertMany(rows, "course_id,student_id,class_date");
    audit_.record(actor, "ATTENDANCE_MARKED",
                  course->code() + " " + date.toIso() + ": " + std::to_string(present) + "/" +
                      std::to_string(rows.size()) + " present");
    return static_cast<int>(rows.size());
}

bool AttendanceService::isMarked(long long courseId, const Date& date) const {
    return records_.count(Query().eq("course_id", courseId).eq("class_date", date.toIso())) > 0;
}

std::vector<AttendanceRecord> AttendanceService::recordsFor(long long courseId, const Date& date) const {
    return records_.find(Query().eq("course_id", courseId).eq("class_date", date.toIso()));
}

std::vector<AttendanceRecord> AttendanceService::courseRecords(long long courseId) const {
    return records_.find(Query().eq("course_id", courseId).order("class_date").order("id"));
}

std::vector<AttendanceRecord> AttendanceService::recordsForCourses(const std::vector<long long>& courseIds) const {
    return records_.findByIds(courseIds, "course_id", Query().select("course_id,student_id,is_present,class_date"));
}

std::vector<CourseAttendance> AttendanceService::studentSummary(long long studentId, int semester) const {
    const auto courses = academic_.coursesForStudent(studentId, semester);
    std::vector<long long> courseIds;
    for (const auto& c : courses) courseIds.push_back(c.id());
    std::map<long long, CourseAttendance> byCourse;
    for (const auto& c : courses) byCourse[c.id()].course = c;
    if (!courseIds.empty()) {
        Query base;
        base.select("course_id,is_present").eq("student_id", studentId);
        for (const auto& r : records_.findByIds(courseIds, "course_id", base)) {
            auto& entry = byCourse[r.courseId()];
            ++entry.total;
            if (r.present()) ++entry.attended;
        }
    }
    std::vector<CourseAttendance> out;
    for (const auto& c : courses) out.push_back(byCourse[c.id()]);
    return out;
}

std::vector<StudentAttendance> AttendanceService::courseSummary(long long courseId) const {
    std::map<long long, std::pair<int, int>> counts;  // student -> (attended, total)
    for (const auto& r : records_.find(Query().select("student_id,is_present").eq("course_id", courseId))) {
        auto& c = counts[r.studentId()];
        ++c.second;
        if (r.present()) ++c.first;
    }
    std::vector<StudentAttendance> out;
    for (const auto& s : academic_.studentsInCourse(courseId)) {
        StudentAttendance row;
        row.student = s;
        const auto it = counts.find(s.id());
        if (it != counts.end()) {
            row.attended = it->second.first;
            row.total = it->second.second;
        }
        out.push_back(row);
    }
    return out;
}

}  // namespace portal
