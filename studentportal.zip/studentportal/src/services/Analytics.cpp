#include "services/Analytics.hpp"

#include <algorithm>
#include <cmath>
#include <map>

#include "core/StringUtil.hpp"

namespace portal {

// --------------------------------------------------------- GradeCalculator --
const std::vector<std::pair<int, GradeInfo>>& GradeCalculator::bands() {
    static const std::vector<std::pair<int, GradeInfo>> table = {
        {90, {"O", 10, true}}, {80, {"A+", 9, true}}, {70, {"A", 8, true}}, {60, {"B+", 7, true}},
        {50, {"B", 6, true}},  {45, {"C", 5, true}},  {40, {"P", 4, true}},
    };
    return table;
}

GradeInfo GradeCalculator::grade(double total, double endsem) {
    const double rounded = std::round(total);
    if (endsem < kPassEndSem || rounded < kPassTotal) return {"F", 0, false};
    for (const auto& [minimum, info] : bands()) {
        if (rounded >= minimum) return info;
    }
    return {"F", 0, false};
}

GradeInfo GradeCalculator::grade(const MarkRecord& marks) {
    if (!marks.isComplete()) return {"-", 0, false};
    return grade(marks.total(), marks.get(ExamComponent::EndSem).value_or(0));
}

double GradeCalculator::weightedAverage(const std::vector<std::pair<int, int>>& creditPoints) {
    int credits = 0;
    int weighted = 0;
    for (const auto& [c, p] : creditPoints) {
        credits += c;
        weighted += c * p;
    }
    if (credits == 0) return 0.0;
    return std::round(100.0 * weighted / credits) / 100.0;  // 2 decimal places
}

std::string GradeCalculator::classification(double cgpa) {
    if (cgpa >= 7.5) return "First Class with Distinction";
    if (cgpa >= 6.5) return "First Class";
    if (cgpa >= 5.5) return "Higher Second Class";
    if (cgpa >= 4.0) return "Pass Class";
    return "Fail";
}

// -------------------------------------------------------------- Transcript --
const SemesterResult* Transcript::find(int semester) const {
    for (const auto& s : semesters) {
        if (s.semester == semester) return &s;
    }
    return nullptr;
}

std::vector<std::pair<int, double>> Transcript::sgpaHistory() const {
    std::vector<std::pair<int, double>> out;
    for (const auto& s : semesters) {
        if (s.declared) out.emplace_back(s.semester, s.sgpa);
    }
    return out;
}

Transcript TranscriptBuilder::build(const std::vector<Course>& enrolledCourses, const std::vector<MarkRecord>& marks) {
    std::map<long long, MarkRecord> marksByCourse;
    for (const auto& m : marks) marksByCourse[m.courseId()] = m;

    std::map<int, SemesterResult> bySemester;
    for (const auto& course : enrolledCourses) {
        CourseResult result;
        result.course = course;
        const auto it = marksByCourse.find(course.id());
        if (it != marksByCourse.end()) {
            result.marks = it->second;
            result.complete = it->second.isComplete();
            result.total = it->second.total();
            result.grade = GradeCalculator::grade(it->second);
        }
        auto& semester = bySemester[course.semester()];
        semester.semester = course.semester();
        semester.courses.push_back(result);
    }

    Transcript transcript;
    std::vector<std::pair<int, int>> allCredits;
    for (auto& [number, semester] : bySemester) {
        std::sort(semester.courses.begin(), semester.courses.end(),
                  [](const CourseResult& a, const CourseResult& b) { return a.course.code() < b.course.code(); });
        semester.declared = !semester.courses.empty();
        std::vector<std::pair<int, int>> credits;
        for (const auto& c : semester.courses) {
            semester.creditsRegistered += c.course.credits();
            if (!c.complete) {
                semester.declared = false;
                continue;
            }
            credits.emplace_back(c.course.credits(), c.grade.points);
            if (c.grade.passed) semester.creditsEarned += c.course.credits();
            else ++semester.backlogs;
        }
        transcript.backlogs += semester.backlogs;
        transcript.creditsEarned += semester.creditsEarned;
        if (semester.declared) {
            semester.sgpa = GradeCalculator::weightedAverage(credits);
            allCredits.insert(allCredits.end(), credits.begin(), credits.end());
        }
        transcript.semesters.push_back(semester);
    }
    if (!allCredits.empty()) {
        transcript.hasCgpa = true;
        transcript.cgpa = GradeCalculator::weightedAverage(allCredits);
    }
    return transcript;
}

// ------------------------------------------------------ AttendanceGuardian --
double AttendanceGuardian::percent(int attended, int total) {
    return total <= 0 ? 0.0 : 100.0 * attended / total;
}

int AttendanceGuardian::classesNeeded(int attended, int total, double targetPercent) {
    if (total <= 0 || targetPercent >= 100.0) return 0;
    if (100.0 * attended >= targetPercent * total) return 0;
    // (attended + n) / (total + n) >= t  ->  n >= (t*total - 100*attended) / (100 - t)
    const double n = (targetPercent * total - 100.0 * attended) / (100.0 - targetPercent);
    return static_cast<int>(std::ceil(n - 1e-9));
}

int AttendanceGuardian::classesCanMiss(int attended, int total, double targetPercent) {
    if (targetPercent <= 0) return 0;
    if (100.0 * attended < targetPercent * total) return 0;
    // attended / (total + m) >= t  ->  m <= 100*attended/t - total
    const double m = 100.0 * attended / targetPercent - total;
    return std::max(0, static_cast<int>(std::floor(m + 1e-9)));
}

std::string AttendanceGuardian::advice(int attended, int total, double targetPercent) {
    if (total == 0) return "No classes conducted yet.";
    const int need = classesNeeded(attended, total, targetPercent);
    if (need > 0) {
        return "Attend the next " + std::to_string(need) + " class" + (need == 1 ? "" : "es") + " to reach " +
               str::formatFixed(targetPercent, 0) + "%.";
    }
    const int miss = classesCanMiss(attended, total, targetPercent);
    if (miss == 0) return "On the edge - do not miss the next class.";
    return "Safe - you can miss " + std::to_string(miss) + " more class" + (miss == 1 ? "" : "es") + ".";
}

// ------------------------------------------------------ GradeTargetPlanner --
std::optional<double> GradeTargetPlanner::endsemNeeded(double continuous, int minPoints) {
    for (double e = 0.0; e <= 50.0 + 1e-9; e += 0.5) {
        const GradeInfo g = GradeCalculator::grade(continuous + e, e);
        if (g.passed && g.points >= minPoints) return e;
    }
    return std::nullopt;
}

std::vector<GradeStep> GradeTargetPlanner::ladder(double continuous) {
    std::vector<GradeStep> steps;
    for (const auto& [minimum, info] : GradeCalculator::bands()) {
        (void)minimum;
        steps.push_back({info.letter, info.points, endsemNeeded(continuous, info.points)});
    }
    return steps;
}

TargetPlan GradeTargetPlanner::plan(const std::vector<std::pair<Course, MarkRecord>>& currentCourses,
                                    double targetSgpa) {
    TargetPlan plan;
    plan.target = targetSgpa;
    if (currentCourses.empty()) return plan;

    const auto& bands = GradeCalculator::bands();  // best -> worst
    // Per course: index into bands of the currently planned grade (-1 = fail / not reachable).
    std::vector<int> level(currentCourses.size(), -1);
    for (std::size_t i = 0; i < currentCourses.size(); ++i) {
        const auto& [course, marks] = currentCourses[i];
        PlanRow row;
        row.course = course;
        row.continuous = marks.continuousTotal();
        row.continuousComplete = marks.get(ExamComponent::Internal).has_value() &&
                                 marks.get(ExamComponent::MidSem).has_value();
        row.ladder = ladder(row.continuous);
        // start at the lowest passing grade that is still reachable
        for (int b = static_cast<int>(bands.size()) - 1; b >= 0; --b) {
            if (endsemNeeded(row.continuous, bands[static_cast<std::size_t>(b)].second.points)) {
                level[i] = b;
                break;
            }
        }
        plan.rows.push_back(row);
    }

    auto sgpaFor = [&](const std::vector<int>& lv) {
        std::vector<std::pair<int, int>> credits;
        for (std::size_t i = 0; i < lv.size(); ++i) {
            const int points = lv[i] < 0 ? 0 : bands[static_cast<std::size_t>(lv[i])].second.points;
            credits.emplace_back(plan.rows[i].course.credits(), points);
        }
        return GradeCalculator::weightedAverage(credits);
    };
    auto marksFor = [&](std::size_t i, int lv) -> double {
        if (lv < 0) return 50.0;
        return endsemNeeded(plan.rows[i].continuous, bands[static_cast<std::size_t>(lv)].second.points).value_or(50.0);
    };

    // Maximum possible SGPA: best reachable grade in every course.
    std::vector<int> best(level.size(), -1);
    for (std::size_t i = 0; i < level.size(); ++i) {
        for (std::size_t b = 0; b < bands.size(); ++b) {
            if (endsemNeeded(plan.rows[i].continuous, bands[b].second.points)) {
                best[i] = static_cast<int>(b);
                break;
            }
        }
    }
    plan.maxPossibleSgpa = sgpaFor(best);

    // Greedy upgrades: best SGPA gain per extra end-sem mark first.
    while (sgpaFor(level) + 1e-9 < targetSgpa) {
        int chosen = -1;
        double bestRatio = -1.0;
        for (std::size_t i = 0; i < level.size(); ++i) {
            if (level[i] <= 0) continue;  // already at O (index 0) or cannot pass
            const int next = level[i] - 1;
            const auto needed = endsemNeeded(plan.rows[i].continuous, bands[static_cast<std::size_t>(next)].second.points);
            if (!needed) continue;
            const double extra = std::max(0.5, *needed - marksFor(i, level[i]));
            const int gain = plan.rows[i].course.credits() *
                             (bands[static_cast<std::size_t>(next)].second.points -
                              bands[static_cast<std::size_t>(level[i])].second.points);
            const double ratio = gain / extra;
            if (ratio > bestRatio) {
                bestRatio = ratio;
                chosen = static_cast<int>(i);
            }
        }
        if (chosen < 0) break;  // nothing left to upgrade
        --level[static_cast<std::size_t>(chosen)];
    }

    plan.plannedSgpa = sgpaFor(level);
    plan.achievable = plan.plannedSgpa + 1e-9 >= targetSgpa;
    for (std::size_t i = 0; i < level.size(); ++i) {
        if (level[i] >= 0) {
            plan.rows[i].requiredEndsem = marksFor(i, level[i]);
            plan.rows[i].plannedGrade = bands[static_cast<std::size_t>(level[i])].second;
        } else {
            plan.rows[i].plannedGrade = {"F", 0, false};
        }
    }
    return plan;
}

// ------------------------------------------------------------ RiskAssessor --
RiskReport RiskAssessor::assess(const RiskInput& input, double minAttendance) {
    RiskReport report;
    int score = 0;
    if (input.hasAttendance) {
        if (input.attendancePercent < minAttendance) {
            score += 10 + std::min(30, static_cast<int>(std::lround((minAttendance - input.attendancePercent) * 1.5)));
            report.reasons.push_back("Attendance " + str::formatPercent(input.attendancePercent) + " is below " +
                                     str::formatFixed(minAttendance, 0) + "%");
            report.actions.push_back("Mentor meeting + inform guardian about attendance");
        } else if (input.attendancePercent < minAttendance + 5) {
            score += 5;
            report.reasons.push_back("Attendance " + str::formatPercent(input.attendancePercent) + " is borderline");
        }
    }
    if (input.hasMarks) {
        if (input.continuousPercent < 40) {
            score += 10 + std::min(20, static_cast<int>(std::lround(40 - input.continuousPercent)));
            report.reasons.push_back("Internal + mid-sem score " + str::formatPercent(input.continuousPercent) +
                                     " (below 40%)");
            report.actions.push_back("Enrol in remedial / doubt-solving sessions before end-sem");
        } else if (input.continuousPercent < 55) {
            score += 5;
            report.reasons.push_back("Internal + mid-sem score " + str::formatPercent(input.continuousPercent) +
                                     " is average");
        }
    }
    if (input.backlogs > 0) {
        score += std::min(25, input.backlogs * 10);
        report.reasons.push_back(std::to_string(input.backlogs) + " backlog course" + (input.backlogs == 1 ? "" : "s"));
        report.actions.push_back("Plan re-examination for backlog courses");
    }
    if (input.overdueFees > 0.5) {
        score += 10;
        report.reasons.push_back("Overdue fees " + str::formatMoney(input.overdueFees));
        report.actions.push_back("Connect student with accounts office / scholarship cell");
    }
    report.score = std::min(100, score);
    report.level = report.score >= 50 ? "HIGH" : (report.score >= 25 ? "MEDIUM" : "LOW");
    if (report.reasons.empty()) report.reasons.push_back("No warning signs");
    return report;
}

}  // namespace portal
