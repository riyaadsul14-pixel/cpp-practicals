#include "services/AuditService.hpp"

#include "core/Date.hpp"
#include "core/StringUtil.hpp"

namespace portal {

void AuditService::record(const User& actor, const std::string& action, const std::string& details) {
    record(actor.id(), actor.fullName(), action, details);
}

void AuditService::record(long long actorId, const std::string& actorName, const std::string& action,
                          const std::string& details) {
    // prev_hash is UNIQUE in the database, so two simultaneous writers cannot fork the
    // chain: the loser gets a duplicate-key error and retries on top of the new head.
    for (int attempt = 0; attempt < 4; ++attempt) {
        try {
            const auto last = log_.findOne(Query().order("id", false));
            const std::string prev = last ? last->hash() : AuditEntry::genesisHash();
            AuditEntry entry;
            entry.fill(actorId, actorName, action, str::truncate(details, 500), DateTime::nowIsoUtc(), prev);
            log_.insert(entry);
            return;
        } catch (const DatabaseException& e) {
            if (!e.isUniqueViolation()) break;
        } catch (const PortalException&) {
            break;
        }
    }
    ++failures_;
}

ChainVerification AuditService::verifyChain() const {
    ChainVerification result;
    const auto entries = log_.find(Query().order("id"));
    std::string expectedPrev = AuditEntry::genesisHash();
    for (const auto& e : entries) {
        ++result.entries;
        if (e.prevHash() != expectedPrev) {
            result.intact = false;
            result.brokenAtId = e.id();
            result.problem = "Entry #" + std::to_string(e.id()) +
                             " does not link to the previous entry (a record was deleted or inserted).";
            return result;
        }
        if (e.recomputeHash() != e.hash()) {
            result.intact = false;
            result.brokenAtId = e.id();
            result.problem = "Entry #" + std::to_string(e.id()) + " (" + e.action() +
                             ") was modified after it was written.";
            return result;
        }
        expectedPrev = e.hash();
    }
    return result;
}

std::vector<AuditEntry> AuditService::recent(int limit) const {
    return log_.find(Query().order("id", false).limit(limit));
}

}  // namespace portal
