#include "services/CampusServices.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>

#include "core/Crypto.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

namespace {
double round2(double v) { return std::round(v * 100.0) / 100.0; }
}  // namespace

// ============================================================ NoticeService ===
Notice NoticeService::post(const std::string& title, const std::string& body, const std::string& audience,
                           const User& actor) {
    Notice notice;
    notice.setTitle(title);
    notice.setBody(body);
    notice.setAudience(audience);
    notice.setPostedBy(actor.id());
    Notice created = notices_.insert(notice);
    audit_.record(actor, "NOTICE_POSTED", created.title());
    return created;
}

std::vector<Notice> NoticeService::listFor(Role role, int limit) const {
    Query q;
    if (role == Role::Student) q.inText("audience", {"all", "students"});
    if (role == Role::Faculty) q.inText("audience", {"all", "faculty"});
    q.order("created_at", false).limit(limit);
    return notices_.find(q);
}

void NoticeService::remove(long long noticeId, const User& actor) {
    if (!notices_.remove(noticeId)) throw NotFoundException("Notice not found.");
    audit_.record(actor, "NOTICE_DELETED", "Notice #" + std::to_string(noticeId));
}

// =============================================================== FeeService ===
std::string FeeStatement::status() const {
    std::string s = balance <= 0.005 ? "PAID" : (paid > 0.005 ? "PARTIAL" : "UNPAID");
    if (overdue) s += " (OVERDUE)";
    return s;
}

std::vector<FeeStatement> FeeService::combine(const std::vector<FeeAccount>& fees, const std::vector<Payment>& payments) {
    const Date today = Date::today();
    std::vector<FeeStatement> out;
    for (const auto& fee : fees) {
        FeeStatement st;
        st.fee = fee;
        for (const auto& p : payments) {
            if (p.feeId() == fee.id()) {
                st.payments.push_back(p);
                st.paid += p.amount();
            }
        }
        st.paid = round2(st.paid);
        st.balance = round2(std::max(0.0, fee.amount() - st.paid));
        st.overdue = st.balance > 0.005 && !fee.dueDate().isEmpty() && fee.dueDate() < today;
        out.push_back(st);
    }
    return out;
}

int FeeService::assignToSemester(int semester, const std::string& academicYear, const std::string& description,
                                 double amount, const Date& dueDate, const User& actor) {
    FeeAccount templateFee;
    templateFee.setAcademicYear(academicYear);
    templateFee.setDescription(description);
    templateFee.setAmount(round2(amount));
    Validator::require(!dueDate.isEmpty(), "Due date is required.");
    templateFee.setDueDate(dueDate);
    std::vector<FeeAccount> rows;
    for (const auto& s : users_.listStudents(semester)) {
        if (!s.isActive()) continue;
        FeeAccount f = templateFee;
        f.setStudentId(s.id());
        rows.push_back(f);
    }
    if (rows.empty()) throw ValidationException("No active students in semester " + std::to_string(semester) + ".");
    const auto inserted = fees_.upsertMany(rows, "student_id,academic_year,description", true);
    audit_.record(actor, "FEE_ASSIGNED",
                  description + " " + str::formatMoney(amount) + " -> semester " + std::to_string(semester) + " (" +
                      std::to_string(inserted.size()) + " students)");
    return static_cast<int>(inserted.size());
}

Payment FeeService::recordPayment(long long feeId, double amount, const std::string& mode, const std::string& reference,
                                  const Date& paidOn, const User& actor) {
    const auto fee = fees_.findById(feeId);
    if (!fee) throw NotFoundException("Fee record not found.");
    const auto statement = combine({*fee}, payments_.find(Query().eq("fee_id", feeId)));
    const double balance = statement.front().balance;
    Validator::require(balance > 0.005, "This fee is already fully paid.");
    amount = round2(amount);
    Validator::require(amount <= balance + 0.005, "Amount exceeds the balance of " + str::formatMoney(balance) + ".");
    Payment p;
    p.setFeeId(feeId);
    p.setStudentId(fee->studentId());
    p.setAmount(amount);
    p.setMode(mode);
    p.setReference(reference);
    p.setPaidOn(paidOn);
    p.setRecordedBy(actor.id());
    Payment saved = payments_.insert(p);
    audit_.record(actor, "FEE_PAYMENT",
                  saved.receiptNumber() + " " + str::formatMoney(amount) + " student #" + std::to_string(fee->studentId()));
    return saved;
}

std::vector<FeeStatement> FeeService::statementsFor(long long studentId) const {
    return combine(fees_.find(Query().eq("student_id", studentId).order("due_date")),
                   payments_.find(Query().eq("student_id", studentId).order("paid_on")));
}

std::vector<DueRow> FeeService::pendingDues(int semester) const {
    const auto students = users_.listStudents(semester);
    std::vector<long long> ids;
    for (const auto& s : students) ids.push_back(s.id());
    const auto statements = combine(fees_.findByIds(ids, "student_id"), payments_.findByIds(ids, "student_id"));
    std::vector<DueRow> rows;
    for (const auto& s : students) {
        DueRow row;
        row.student = s;
        for (const auto& st : statements) {
            if (st.fee.studentId() != s.id()) continue;
            row.billed += st.fee.amount();
            row.paid += st.paid;
            row.balance += st.balance;
            row.overdue = row.overdue || st.overdue;
        }
        if (row.balance > 0.005) rows.push_back(row);
    }
    std::sort(rows.begin(), rows.end(), [](const DueRow& a, const DueRow& b) { return a.balance > b.balance; });
    return rows;
}

FeeTotals FeeService::totals() const {
    FeeTotals t;
    for (const auto& st : combine(fees_.find(), payments_.find())) {
        t.billed += st.fee.amount();
        t.collected += st.paid;
        t.pending += st.balance;
        if (st.overdue) t.overdue += st.balance;
    }
    return t;
}

std::map<long long, double> FeeService::overdueByStudent() const {
    std::map<long long, double> out;
    for (const auto& st : combine(fees_.find(), payments_.find())) {
        if (st.overdue) out[st.fee.studentId()] += st.balance;
    }
    return out;
}

// ========================================================== DocumentService ===
std::string DocumentService::normalizeCode(const std::string& input) {
    std::string raw;
    for (const char c : input) {
        if (std::isalnum(static_cast<unsigned char>(c))) raw += static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    }
    if (raw.size() != 12) return "";
    for (const char c : raw) {
        if (!std::isxdigit(static_cast<unsigned char>(c))) return "";
    }
    return raw.substr(0, 4) + "-" + raw.substr(4, 4) + "-" + raw.substr(8, 4);
}

std::string DocumentService::sign(long long documentId, const std::string& docType, const std::string& prn,
                                  const std::string& issuedOn, const std::string& digest) const {
    const auto mac = hmacSha256(profile_.documentSecret(), "doc#" + std::to_string(documentId) + "|" + docType + "|" +
                                                               prn + "|" + issuedOn + "|" + digest);
    return normalizeCode(toHex(mac.data(), 6));  // 48-bit code, e.g. 3F9A-C21B-77D0
}

DocumentRecord DocumentService::finalize(long long documentId, const Student& student, const std::string& docType,
                                         const std::string& digest, long long decidedBy) {
    const std::string issuedOn = Date::today().toIso();
    Json change = Json::object();
    change["status"] = "approved";
    change["issued_on"] = issuedOn;
    change["content_digest"] = digest;
    change["verification_code"] = sign(documentId, docType, student.prn(), issuedOn, digest);
    change["decided_by"] = decidedBy > 0 ? Json(decidedBy) : Json();
    return documents_.update(documentId, change);
}

DocumentRecord DocumentService::requestBonafide(const Student& student, const std::string& purpose) {
    for (const auto& d : forStudent(student.id())) {
        if (d.docType() == "bonafide" && d.status() == "pending") {
            throw ValidationException("You already have a pending bonafide request (#" + std::to_string(d.id()) + ").");
        }
    }
    DocumentRecord doc;
    doc.setStudentId(student.id());
    doc.setDocType("bonafide");
    doc.setPurpose(purpose);
    DocumentRecord created = documents_.insert(doc);
    audit_.record(student, "BONAFIDE_REQUESTED", "Request #" + std::to_string(created.id()) + ": " + purpose);
    return created;
}

std::vector<DocumentRecord> DocumentService::forStudent(long long studentId) const {
    return documents_.find(Query().eq("student_id", studentId).order("id", false));
}

std::vector<DocumentRecord> DocumentService::pending() const {
    return documents_.find(Query().eq("status", "pending").order("id"));
}

DocumentRecord DocumentService::approve(long long documentId, const std::string& contentDigest, const User& actor) {
    const auto doc = documents_.findById(documentId);
    if (!doc) throw NotFoundException("Request not found.");
    Validator::require(doc->status() == "pending", "Only pending requests can be approved.");
    const auto student = users_.findStudent(doc->studentId());
    if (!student) throw NotFoundException("Student not found.");
    DocumentRecord approved = finalize(documentId, *student, doc->docType(), contentDigest, actor.id());
    audit_.record(actor, "DOCUMENT_APPROVED", approved.typeTitle() + " " + approved.verificationCode() + " for " + student->prn());
    return approved;
}

DocumentRecord DocumentService::reject(long long documentId, const std::string& remarks, const User& actor) {
    const auto doc = documents_.findById(documentId);
    if (!doc) throw NotFoundException("Request not found.");
    Validator::require(doc->status() == "pending", "Only pending requests can be rejected.");
    Json change = Json::object();
    change["status"] = "rejected";
    change["remarks"] = str::truncate(str::trim(remarks), 200);
    change["decided_by"] = actor.id();
    DocumentRecord rejected = documents_.update(documentId, change);
    audit_.record(actor, "DOCUMENT_REJECTED", "Request #" + std::to_string(documentId));
    return rejected;
}

DocumentRecord DocumentService::issueImmediately(const Student& student, const std::string& docType,
                                                 const std::string& purpose, const std::string& contentDigest) {
    DocumentRecord doc;
    doc.setStudentId(student.id());
    doc.setDocType(docType);
    doc.setPurpose(purpose);
    const DocumentRecord created = documents_.insert(doc);
    DocumentRecord issued = finalize(created.id(), student, docType, contentDigest, 0);
    audit_.record(student, "DOCUMENT_ISSUED", issued.typeTitle() + " " + issued.verificationCode());
    return issued;
}

VerificationResult DocumentService::verify(const std::string& code) const {
    VerificationResult result;
    const std::string normalized = normalizeCode(code);
    if (normalized.empty()) return result;
    const auto doc = documents_.findOne(Query().eq("verification_code", normalized));
    if (!doc) return result;
    result.document = doc;
    result.student = users_.findStudent(doc->studentId());
    const bool signatureOk =
        result.student && doc->status() == "approved" &&
        sign(doc->id(), doc->docType(), result.student->prn(), doc->issuedOn().toIso(), doc->contentDigest()) == normalized;
    result.status = signatureOk ? VerifyStatus::Genuine : VerifyStatus::Tampered;
    return result;
}

}  // namespace portal
