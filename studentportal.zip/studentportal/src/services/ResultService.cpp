#include "services/ResultService.hpp"

#include <algorithm>
#include <cmath>
#include <set>

#include "core/Date.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

int ResultService::saveMarks(long long courseId, ExamComponent component,
                             const std::vector<std::pair<long long, double>>& entries, const User& actor) {
    const auto course = academic_.findCourse(courseId);
    if (!course) throw NotFoundException("Course not found.");
    if (actor.role() == Role::Faculty && course->facultyId() != actor.id()) {
        throw ValidationException("You can only enter marks for courses assigned to you.");
    }
    if (entries.empty()) return 0;
    std::set<long long> enrolled;
    for (const auto& s : academic_.studentsInCourse(courseId)) enrolled.insert(s.id());

    const double maximum = componentMax(component);
    const std::string now = DateTime::nowIsoUtc();
    Json rows = Json::array();
    for (const auto& [studentId, value] : entries) {
        Validator::require(enrolled.count(studentId) > 0,
                           "Student #" + std::to_string(studentId) + " is not enrolled in " + course->code() + ".");
        Validator::require(value >= 0 && value <= maximum,
                           componentLabel(component) + " marks must be between 0 and " + str::formatFixed(maximum, 0) + ".");
        Validator::require(std::fabs(value * 2 - std::round(value * 2)) < 1e-9, "Marks must be in steps of 0.5.");
        Json row = Json::object();
        row["student_id"] = studentId;
        row["course_id"] = courseId;
        row[componentColumn(component)] = value;
        row["updated_by"] = actor.id();
        row["updated_at"] = now;
        rows.push(row);
    }
    // merge-duplicates only updates the columns we send, so other exam components are preserved
    const Json saved = db_.upsert(MarkRecord::TABLE, rows, "student_id,course_id", false, "id");
    audit_.record(actor, "MARKS_SAVED",
                  course->code() + " " + componentLabel(component) + ": " + std::to_string(saved.size()) + " student(s)");
    return static_cast<int>(saved.size());
}

std::vector<MarkRecord> ResultService::marksForCourse(long long courseId) const {
    return marks_.find(Query().eq("course_id", courseId));
}

std::vector<ResultSheetRow> ResultService::resultSheet(long long courseId) const {
    std::map<long long, MarkRecord> byStudent;
    for (const auto& m : marksForCourse(courseId)) byStudent[m.studentId()] = m;
    std::vector<ResultSheetRow> rows;
    for (const auto& s : academic_.studentsInCourse(courseId)) {
        ResultSheetRow row;
        row.student = s;
        const auto it = byStudent.find(s.id());
        if (it != byStudent.end()) {
            row.marks = it->second;
            row.complete = it->second.isComplete();
            row.grade = GradeCalculator::grade(it->second);
        }
        rows.push_back(row);
    }
    return rows;
}

Transcript ResultService::transcriptFor(const Student& student) const {
    const auto courses = academic_.coursesForStudent(student.id());
    const auto marks = marks_.find(Query().eq("student_id", student.id()));
    return TranscriptBuilder::build(courses, marks);
}

std::map<long long, Transcript> ResultService::transcriptsFor(const std::vector<Student>& students) const {
    std::map<long long, Transcript> out;
    if (students.empty()) return out;
    std::vector<long long> ids;
    for (const auto& s : students) ids.push_back(s.id());

    std::map<long long, Course> courseById;
    for (const auto& c : academic_.listCourses()) courseById[c.id()] = c;
    std::map<long long, std::vector<Course>> coursesOf;
    for (const auto& e : academic_.enrollmentsForStudents(ids)) {
        const auto it = courseById.find(e.courseId());
        if (it != courseById.end()) coursesOf[e.studentId()].push_back(it->second);
    }
    std::map<long long, std::vector<MarkRecord>> marksOf;
    for (const auto& m : marks_.findByIds(ids, "student_id")) marksOf[m.studentId()].push_back(m);
    for (const auto& s : students) out[s.id()] = TranscriptBuilder::build(coursesOf[s.id()], marksOf[s.id()]);
    return out;
}

TargetPlan ResultService::planTarget(const Student& student, double targetSgpa) const {
    Validator::require(targetSgpa > 0 && targetSgpa <= 10, "Target SGPA must be between 0 and 10.");
    const auto courses = academic_.coursesForStudent(student.id(), student.semester());
    std::map<long long, MarkRecord> byCourse;
    for (const auto& m : marks_.find(Query().eq("student_id", student.id()))) byCourse[m.courseId()] = m;
    std::vector<std::pair<Course, MarkRecord>> current;
    for (const auto& c : courses) {
        MarkRecord m;
        const auto it = byCourse.find(c.id());
        if (it != byCourse.end()) m = it->second;
        m.setCourseId(c.id());
        m.setStudentId(student.id());
        current.emplace_back(c, m);
    }
    return GradeTargetPlanner::plan(current, targetSgpa);
}

}  // namespace portal
