#include "services/AcademicService.hpp"

#include <algorithm>

#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

std::vector<Course> AcademicService::listCourses(int semester) const {
    Query q;
    if (semester > 0) q.eq("semester", semester);
    return courses_.find(q.order("semester").order("code"));
}

std::optional<Course> AcademicService::findCourseByCode(const std::string& code) const {
    return courses_.findOne(Query().eq("code", str::toUpper(str::trim(code))));
}

std::vector<Course> AcademicService::coursesForFaculty(long long facultyId) const {
    return courses_.find(Query().eq("faculty_id", facultyId).order("semester").order("code"));
}

Course AcademicService::createCourse(const Course& course, const User& actor) {
    if (findCourseByCode(course.code())) throw ValidationException("Course code " + course.code() + " already exists.");
    Course created = courses_.insert(course);
    audit_.record(actor, "COURSE_CREATED", created.label());
    return created;
}

Course AcademicService::assignFaculty(long long courseId, long long facultyId, const User& actor) {
    Json change = Json::object();
    change["faculty_id"] = facultyId > 0 ? Json(facultyId) : Json();
    Course updated = courses_.update(courseId, change);
    audit_.record(actor, "COURSE_FACULTY_ASSIGNED", updated.code() + " -> faculty #" + std::to_string(facultyId));
    return updated;
}

int AcademicService::autoEnrollSemester(int semester, const std::string& academicYear, const User& actor) {
    Validator::require(Validator::isSemester(semester), "Semester must be between 1 and 8.");
    Validator::require(Validator::isAcademicYear(academicYear), "Academic year must look like 2026-27.");
    const auto courses = listCourses(semester);
    const auto students = users_.listStudents(semester);
    if (courses.empty()) throw ValidationException("No courses defined for semester " + std::to_string(semester) + ".");
    if (students.empty()) throw ValidationException("No students in semester " + std::to_string(semester) + ".");
    std::vector<Enrollment> rows;
    for (const auto& s : students) {
        for (const auto& c : courses) rows.emplace_back(s.id(), c.id(), academicYear);
    }
    // ignore-duplicates: re-running is safe and only new enrollments are returned
    const auto inserted = enrollments_.upsertMany(rows, "student_id,course_id", true);
    audit_.record(actor, "AUTO_ENROLL",
                  "Semester " + std::to_string(semester) + ": " + std::to_string(inserted.size()) + " new enrollments");
    return static_cast<int>(inserted.size());
}

std::vector<Enrollment> AcademicService::enrollmentsForStudents(const std::vector<long long>& studentIds) const {
    return enrollments_.findByIds(studentIds, "student_id");
}

std::vector<Course> AcademicService::coursesForStudent(long long studentId, int semester) const {
    std::vector<long long> courseIds;
    for (const auto& e : enrollments_.find(Query().eq("student_id", studentId))) courseIds.push_back(e.courseId());
    auto courses = courses_.findByIds(courseIds);
    if (semester > 0) {
        courses.erase(std::remove_if(courses.begin(), courses.end(),
                                     [semester](const Course& c) { return c.semester() != semester; }),
                      courses.end());
    }
    std::sort(courses.begin(), courses.end(), [](const Course& a, const Course& b) {
        return a.semester() != b.semester() ? a.semester() < b.semester() : a.code() < b.code();
    });
    return courses;
}

std::vector<Student> AcademicService::studentsInCourse(long long courseId) const {
    std::vector<long long> ids;
    for (const auto& e : enrollments_.find(Query().eq("course_id", courseId).eq("academic_year", currentYear_))) {
        ids.push_back(e.studentId());
    }
    return users_.studentsByIds(ids);
}

}  // namespace portal
