#include "services/ReportService.hpp"

#include <algorithm>
#include <fstream>
#include <set>
#include <sstream>

#include "core/Crypto.hpp"
#include "core/Csv.hpp"
#include "core/Date.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"
#include "core/Validator.hpp"

namespace portal {

namespace fs = std::filesystem;

namespace {
constexpr std::size_t kPageWidth = 78;

std::string rule(char c = '-') { return std::string(kPageWidth, c) + "\n"; }

void writeText(const fs::path& path, const std::string& text) {
    fs::create_directories(path.parent_path());
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) throw ValidationException("Cannot write file: " + path.string());
    out << text;
}
}  // namespace

fs::path ReportService::exportPath(const std::string& name, const std::string& extension) const {
    return profile_.exportDir() / (name + "_" + DateTime::fileStamp() + extension);
}

std::string ReportService::letterHead(const std::string& title) const {
    std::string out = rule('=');
    out += str::center(str::toUpper(profile_.name()), kPageWidth) + "\n";
    out += str::center(profile_.campus(), kPageWidth) + "\n";
    out += str::center(profile_.school() + " | " + profile_.department(), kPageWidth) + "\n";
    out += rule('=');
    out += str::center(title, kPageWidth) + "\n";
    out += rule('-');
    return out;
}

// ----------------------------------------------------------------- overview --
Overview ReportService::overview() const {
    Overview o;
    for (const auto& s : users_.listStudents()) {
        if (!s.isActive()) continue;
        ++o.students;
        ++o.studentsPerSemester[s.semester()];
    }
    o.faculty = db_.count(Faculty::TABLE);
    o.courses = db_.count(Course::TABLE);
    o.pendingDocuments = db_.count(DocumentRecord::TABLE, Query().eq("status", "pending"));
    o.fees = fees_.totals();
    return o;
}

// ------------------------------------------------------- Success Radar ----
std::vector<RadarRow> ReportService::successRadar(const std::vector<Student>& students) const {
    std::vector<RadarRow> rows;
    if (students.empty()) return rows;

    // 1) attendance of each student's CURRENT semester courses (one bulk query)
    std::map<long long, Course> courseById;
    for (const auto& c : academic_.listCourses()) courseById[c.id()] = c;
    std::set<int> semesters;
    for (const auto& s : students) semesters.insert(s.semester());
    std::vector<long long> courseIds;
    for (const auto& [id, c] : courseById) {
        if (semesters.count(c.semester())) courseIds.push_back(id);
    }
    std::map<long long, std::pair<int, int>> attendanceOf;  // student -> (attended, total)
    std::set<long long> wanted;
    for (const auto& s : students) wanted.insert(s.id());
    for (const auto& r : attendance_.recordsForCourses(courseIds)) {
        if (!wanted.count(r.studentId())) continue;
        auto& a = attendanceOf[r.studentId()];
        ++a.second;
        if (r.present()) ++a.first;
    }
    // 2) marks & backlogs, 3) overdue fees
    const auto transcripts = results_.transcriptsFor(students);
    const auto overdue = fees_.overdueByStudent();

    for (const auto& s : students) {
        RadarRow row;
        row.student = s;
        RiskInput input;
        const auto a = attendanceOf.find(s.id());
        if (a != attendanceOf.end() && a->second.second > 0) {
            row.hasAttendance = input.hasAttendance = true;
            row.attendance = input.attendancePercent = AttendanceGuardian::percent(a->second.first, a->second.second);
        }
        const auto t = transcripts.find(s.id());
        if (t != transcripts.end()) {
            row.backlogs = input.backlogs = t->second.backlogs;
            if (const SemesterResult* current = t->second.find(s.semester())) {
                double scored = 0, maximum = 0;
                for (const auto& cr : current->courses) {
                    if (!cr.marks) continue;
                    for (const auto comp : {ExamComponent::Internal, ExamComponent::MidSem}) {
                        if (const auto v = cr.marks->get(comp)) {
                            scored += *v;
                            maximum += componentMax(comp);
                        }
                    }
                }
                if (maximum > 0) {
                    row.hasMarks = input.hasMarks = true;
                    row.continuous = input.continuousPercent = 100.0 * scored / maximum;
                }
            }
        }
        const auto o = overdue.find(s.id());
        if (o != overdue.end()) row.overdue = input.overdueFees = o->second;
        row.risk = RiskAssessor::assess(input, profile_.minAttendance());
        rows.push_back(row);
    }
    std::sort(rows.begin(), rows.end(), [](const RadarRow& a, const RadarRow& b) {
        return a.risk.score != b.risk.score ? a.risk.score > b.risk.score : a.student.prn() < b.student.prn();
    });
    return rows;
}

// ------------------------------------------------------------------ exports --
fs::path ReportService::exportStudents(int semester) const {
    std::vector<Csv::Row> rows = {{"prn", "full_name", "email", "phone", "semester", "division", "admission_year",
                                   "date_of_birth", "gender", "guardian_name", "guardian_phone", "status"}};
    for (const auto& s : users_.listStudents(semester)) {
        rows.push_back({s.prn(), s.fullName(), s.email(), s.phone(), std::to_string(s.semester()), s.division(),
                        std::to_string(s.admissionYear()), s.dateOfBirth().toIso(), s.gender(), s.guardianName(),
                        s.guardianPhone(), s.isActive() ? "active" : "inactive"});
    }
    const fs::path path = exportPath(semester ? "students_sem" + std::to_string(semester) : "students_all", ".csv");
    Csv::writeFile(path, rows);
    return path;
}

fs::path ReportService::exportAttendance(long long courseId) const {
    const auto course = academic_.findCourse(courseId);
    if (!course) throw NotFoundException("Course not found.");
    const auto records = attendance_.courseRecords(courseId);
    std::vector<Date> dates;
    std::map<std::pair<long long, long long>, bool> present;  // (student, day) -> present
    for (const auto& r : records) {
        if (std::find(dates.begin(), dates.end(), r.classDate()) == dates.end()) dates.push_back(r.classDate());
        present[{r.studentId(), r.classDate().toDays()}] = r.present();
    }
    std::sort(dates.begin(), dates.end());
    Csv::Row header = {"prn", "name"};
    for (const auto& d : dates) header.push_back(d.toIso());
    header.insert(header.end(), {"attended", "total", "percent"});
    std::vector<Csv::Row> rows = {header};
    for (const auto& s : academic_.studentsInCourse(courseId)) {
        Csv::Row row = {s.prn(), s.fullName()};
        int attended = 0, total = 0;
        for (const auto& d : dates) {
            const auto it = present.find({s.id(), d.toDays()});
            if (it == present.end()) {
                row.push_back("");
                continue;
            }
            ++total;
            if (it->second) ++attended;
            row.push_back(it->second ? "P" : "A");
        }
        row.insert(row.end(), {std::to_string(attended), std::to_string(total),
                               str::formatFixed(AttendanceGuardian::percent(attended, total), 1)});
        rows.push_back(row);
    }
    const fs::path path = exportPath("attendance_" + course->code(), ".csv");
    Csv::writeFile(path, rows);
    return path;
}

fs::path ReportService::exportResults(long long courseId) const {
    const auto course = academic_.findCourse(courseId);
    if (!course) throw NotFoundException("Course not found.");
    std::vector<Csv::Row> rows = {{"prn", "name", "internal_20", "midsem_30", "endsem_50", "total_100", "grade", "grade_points"}};
    auto cell = [](const std::optional<MarkRecord>& m, ExamComponent c) {
        if (!m) return std::string();
        const auto v = m->get(c);
        return v ? str::formatFixed(*v, 1) : std::string();
    };
    for (const auto& r : results_.resultSheet(courseId)) {
        rows.push_back({r.student.prn(), r.student.fullName(), cell(r.marks, ExamComponent::Internal),
                        cell(r.marks, ExamComponent::MidSem), cell(r.marks, ExamComponent::EndSem),
                        r.marks ? str::formatFixed(r.marks->total(), 1) : "", r.complete ? r.grade.letter : "",
                        r.complete ? std::to_string(r.grade.points) : ""});
    }
    const fs::path path = exportPath("results_" + course->code(), ".csv");
    Csv::writeFile(path, rows);
    return path;
}

// ------------------------------------------------------ signed documents ----
fs::path ReportService::writeReportCard(const Student& student, std::string& verificationCode) {
    const Transcript transcript = results_.transcriptFor(student);
    const auto attendance = attendance_.studentSummary(student.id(), student.semester());

    std::ostringstream body;
    body << "  Name      : " << str::padRight(student.fullName(), 32) << "PRN      : " << student.prn() << "\n";
    body << "  Program   : " << str::padRight("B.Tech CSE", 32) << "Semester : " << student.semester() << " ("
         << student.yearLabel() << ")\n";
    body << "  Division  : " << str::padRight(student.division(), 32) << "A.Y.     : " << profile_.academicYear() << "\n";
    body << rule();
    for (const auto& sem : transcript.semesters) {
        body << "  SEMESTER " << sem.semester
             << (sem.declared ? "      SGPA: " + str::formatFixed(sem.sgpa, 2) : "      Result: in progress") << "\n";
        body << "  " << str::padRight("Code", 8) << str::padRight("Course", 36) << str::padLeft("Cr", 3)
             << str::padLeft("Int", 6) << str::padLeft("Mid", 6) << str::padLeft("End", 6) << str::padLeft("Total", 7)
             << str::padLeft("Grd", 5) << "\n";
        for (const auto& c : sem.courses) {
            auto mark = [&](ExamComponent comp) {
                if (!c.marks) return std::string("-");
                const auto v = c.marks->get(comp);
                return v ? str::formatFixed(*v, 1) : std::string("-");
            };
            body << "  " << str::padRight(c.course.code(), 8) << str::padRight(str::truncate(c.course.name(), 35), 36)
                 << str::padLeft(std::to_string(c.course.credits()), 3) << str::padLeft(mark(ExamComponent::Internal), 6)
                 << str::padLeft(mark(ExamComponent::MidSem), 6) << str::padLeft(mark(ExamComponent::EndSem), 6)
                 << str::padLeft(c.marks ? str::formatFixed(c.total, 1) : "-", 7)
                 << str::padLeft(c.complete ? c.grade.letter : "-", 5) << "\n";
        }
        body << "\n";
    }
    body << rule();
    body << "  ATTENDANCE - SEMESTER " << student.semester() << " (minimum " << str::formatFixed(profile_.minAttendance(), 0)
         << "%)\n";
    for (const auto& a : attendance) {
        body << "  " << str::padRight(a.course.code(), 8) << str::padRight(str::truncate(a.course.name(), 35), 36)
             << str::padLeft(std::to_string(a.attended) + "/" + std::to_string(a.total), 8)
             << str::padLeft(a.total ? str::formatPercent(a.percent()) : "-", 9) << "\n";
    }
    body << rule();
    if (transcript.hasCgpa) {
        body << "  CGPA: " << str::formatFixed(transcript.cgpa, 2) << "   Class: "
             << GradeCalculator::classification(transcript.cgpa) << "   Backlogs: " << transcript.backlogs << "\n";
    } else {
        body << "  CGPA: not yet available (no completed semester)\n";
    }
    const std::string content = body.str();
    const DocumentRecord doc =
        documents_.issueImmediately(student, "report_card", "Self-service progress report", Sha256::hexDigest(content));
    verificationCode = doc.verificationCode();

    std::string text = letterHead("STUDENT PROGRESS REPORT");
    text += content;
    text += "  Issued on : " + doc.issuedOn().toDisplay() + "\n";
    text += "  Verification code : " + doc.verificationCode() + "\n";
    text += "  (Verify on the " + profile_.shortName() + " Student Portal login screen -> 'Verify a certificate')\n";
    text += rule('=');
    const fs::path path = exportPath("report_card_" + student.prn(), ".txt");
    writeText(path, text);
    return path;
}

std::string ReportService::bonafideDigest(const DocumentRecord& document, const Student& student,
                                          const std::string& academicYear) {
    return Sha256::hexDigest("bonafide|" + student.prn() + "|" + student.fullName() + "|" +
                             std::to_string(student.semester()) + "|" + academicYear + "|" + document.purpose());
}

fs::path ReportService::writeBonafide(const DocumentRecord& document, const Student& student) const {
    Validator::require(document.status() == "approved", "Certificate is not approved yet.");
    std::string text = letterHead("BONAFIDE CERTIFICATE");
    text += "  Ref. No.: " + profile_.shortName() + "/SOE/CSE/BON/" + std::to_string(document.issuedOn().year()) + "/" +
            str::zeroPad(document.id(), 5) + str::padLeft("Date: " + document.issuedOn().toDisplay(), 34) + "\n\n";
    std::string paragraph = "This is to certify that " + str::toUpper(student.fullName()) + " (PRN: " + student.prn() +
                            ") is a bonafide student of " + profile_.name() + ", Pune, studying in " +
                            student.yearLabel() + " of the " + profile_.program() + " programme (Semester " +
                            std::to_string(student.semester()) + ", Division " + student.division() +
                            ") during the academic year " + profile_.academicYear() + ".";
    for (const auto& line : str::wrap(paragraph, kPageWidth - 4)) text += "  " + line + "\n";
    text += "\n";
    for (const auto& line : str::wrap("This certificate is issued at the request of the student for the purpose of: " +
                                          document.purpose() + ".",
                                      kPageWidth - 4)) {
        text += "  " + line + "\n";
    }
    text += "\n\n" + str::padLeft("Head of Department / Registrar", kPageWidth - 2) + "\n";
    text += str::padLeft(profile_.name(), kPageWidth - 2) + "\n\n";
    text += rule();
    text += "  Verification code : " + document.verificationCode() + "\n";
    text += "  Anyone can verify this certificate on the " + profile_.shortName() +
            " Student Portal login screen -> 'Verify a certificate'.\n";
    text += rule('=');
    const fs::path path = exportPath("bonafide_" + student.prn(), ".txt");
    writeText(path, text);
    return path;
}

}  // namespace portal
