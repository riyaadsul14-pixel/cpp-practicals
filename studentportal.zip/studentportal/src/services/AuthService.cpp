#include "services/AuthService.hpp"

#include "core/Crypto.hpp"
#include "core/Date.hpp"
#include "core/Exceptions.hpp"
#include "core/StringUtil.hpp"

namespace portal {

void AuthService::updateAccount(long long userId, const Json& changes) {
    db_.update(User::ACCOUNT_TABLE, Query().eq("id", userId), changes, "id");
}

std::unique_ptr<User> AuthService::login(const std::string& usernameOrEmail, const std::string& password) {
    static const std::string kInvalid = "Invalid username or password.";
    const auto row = users_.findAccountByLogin(usernameOrEmail);
    if (!row) {
        // Hash anyway so response time does not reveal whether the username exists.
        static const std::string dummy = PasswordHasher::hash("timing-equaliser");
        PasswordHasher::verify(password, dummy);
        throw AuthException(kInvalid);
    }
    const long long id = row->getInt("id");
    const long long now = db_.serverNow();
    if (!row->getBool("is_active", true)) {
        throw AuthException("This account is deactivated. Please contact the academic office.");
    }
    const long long lockedUntil = row->getInt("locked_until", 0);
    if (lockedUntil > now) {
        const long long minutes = (lockedUntil - now + 59) / 60;
        throw AuthException("Account locked after " + std::to_string(kMaxFailedAttempts) +
                            " failed attempts. Try again in " + std::to_string(minutes) + " minute(s).");
    }

    if (!PasswordHasher::verify(password, row->getString("password_hash"))) {
        const int failed = static_cast<int>(row->getInt("failed_logins", 0)) + 1;
        Json change = Json::object();
        if (failed >= kMaxFailedAttempts) {
            change["failed_logins"] = 0;
            change["locked_until"] = now + kLockMinutes * 60LL;
            updateAccount(id, change);
            audit_.record(id, row->getString("full_name"), "ACCOUNT_LOCKED", "Too many failed logins");
            throw AuthException("Too many failed attempts. Account locked for " + std::to_string(kLockMinutes) +
                                " minutes.");
        }
        change["failed_logins"] = failed;
        updateAccount(id, change);
        throw AuthException(kInvalid + " (" + std::to_string(kMaxFailedAttempts - failed) + " attempt(s) left)");
    }

    Json change = Json::object();
    change["failed_logins"] = 0;
    change["locked_until"] = nullptr;
    change["last_login_at"] = DateTime::nowIsoUtc();
    updateAccount(id, change);
    return users_.loadUser(*row);
}

void AuthService::changePassword(User& user, const std::string& currentPassword, const std::string& newPassword) {
    const auto row = users_.findAccountRow(user.id());
    if (!row || !PasswordHasher::verify(currentPassword, row->getString("password_hash"))) {
        throw AuthException("Current password is incorrect.");
    }
    if (currentPassword == newPassword) throw ValidationException("New password must be different from the old one.");
    const std::string problem = PasswordHasher::strengthProblem(newPassword);
    if (!problem.empty()) throw ValidationException(problem);
    const std::string hash = PasswordHasher::hash(newPassword);
    Json change = Json::object();
    change["password_hash"] = hash;
    change["must_change_password"] = false;
    updateAccount(user.id(), change);
    user.setPasswordHash(hash);
    user.setMustChangePassword(false);
    audit_.record(user, "PASSWORD_CHANGED", user.username());
}

std::string AuthService::resetPassword(long long userId, const User& admin) {
    const auto row = users_.findAccountRow(userId);
    if (!row) throw NotFoundException("Account not found.");
    const std::string temporary = PasswordHasher::generateTemporaryPassword();
    Json change = Json::object();
    change["password_hash"] = PasswordHasher::hash(temporary);
    change["must_change_password"] = true;
    change["failed_logins"] = 0;
    change["locked_until"] = nullptr;
    updateAccount(userId, change);
    audit_.record(admin, "PASSWORD_RESET", row->getString("username"));
    return temporary;
}

void AuthService::unlock(long long userId, const User& admin) {
    const auto row = users_.findAccountRow(userId);
    if (!row) throw NotFoundException("Account not found.");
    Json change = Json::object();
    change["failed_logins"] = 0;
    change["locked_until"] = nullptr;
    updateAccount(userId, change);
    audit_.record(admin, "ACCOUNT_UNLOCKED", row->getString("username"));
}

}  // namespace portal
