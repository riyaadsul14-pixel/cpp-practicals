// ============================================================================
//  HttpClient.h - abstract HTTPS client + platform implementations
//  OOP concepts: abstraction (pure virtual interface), runtime polymorphism
//  (WinHttpClient on Windows, CurlHttpClient on Linux/macOS), factory method,
//  RAII (handles released in destructors), non-copyable resources.
// ============================================================================
#pragma once

#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace portal {

using HeaderList = std::vector<std::pair<std::string, std::string>>;

struct HttpRequest {
    std::string method = "GET";  // GET, POST, PATCH, DELETE
    std::string url;
    HeaderList headers;
    std::string body;
};

struct HttpResponse {
    int status = 0;
    std::string body;
    HeaderList headers;

    bool ok() const { return status >= 200 && status < 300; }
    std::string header(const std::string& name) const;  // case-insensitive, "" if absent
};

class HttpClient {
public:
    virtual ~HttpClient() = default;
    HttpClient(const HttpClient&) = delete;
    HttpClient& operator=(const HttpClient&) = delete;

    /// Sends the request; throws NetworkException when no HTTP response was received.
    virtual HttpResponse send(const HttpRequest& request) = 0;
    virtual std::string backendName() const = 0;

    /// Factory: returns the right implementation for the current platform.
    static std::unique_ptr<HttpClient> createDefault(int timeoutSeconds);

protected:
    HttpClient() = default;
};

#ifdef _WIN32
/// Windows implementation using the built-in WinHTTP library (no extra installs).
class WinHttpClient final : public HttpClient {
public:
    explicit WinHttpClient(int timeoutSeconds);
    ~WinHttpClient() override;
    HttpResponse send(const HttpRequest& request) override;
    std::string backendName() const override { return "WinHTTP"; }

private:
    void* session_ = nullptr;  // HINTERNET (kept opaque so <windows.h> stays out of headers)
    int timeoutMs_;
};
#else
/// Linux / macOS implementation using libcurl.
class CurlHttpClient final : public HttpClient {
public:
    explicit CurlHttpClient(int timeoutSeconds);
    ~CurlHttpClient() override;
    HttpResponse send(const HttpRequest& request) override;
    std::string backendName() const override { return "libcurl"; }

private:
    int timeoutSeconds_;
};
#endif

}  // namespace portal
