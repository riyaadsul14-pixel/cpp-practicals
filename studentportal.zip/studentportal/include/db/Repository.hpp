// ============================================================================
//  Repository.h - generic data-access class template
//  OOP / C++ concepts: templates (generic programming), static polymorphism.
//  Any model T that provides
//      static constexpr const char* TABLE;     // table name
//      static constexpr const char* SELECT;    // columns (may embed relations)
//      static T fromJson(const Json& row);
//      Json toJson() const;
//  gets CRUD operations for free:  Repository<Course> courses(db);
// ============================================================================
#pragma once

#include <algorithm>
#include <optional>
#include <string>
#include <vector>

#include "core/Exceptions.hpp"
#include "core/Json.hpp"
#include "db/Query.hpp"
#include "db/SupabaseClient.hpp"

namespace portal {

template <typename T>
class Repository {
public:
    explicit Repository(SupabaseClient& db) : db_(db) {}

    std::vector<T> find(Query query = Query()) const {
        if (!query.hasSelect()) query.select(T::SELECT);
        return mapRows(db_.select(T::TABLE, query));
    }

    std::optional<T> findOne(Query query) const {
        query.limit(1);
        auto rows = find(query);
        if (rows.empty()) return std::nullopt;
        return rows.front();
    }

    std::optional<T> findById(long long id) const { return findOne(Query().eq("id", id)); }

    /// WHERE column IN (ids) - split into chunks to keep URLs short.
    std::vector<T> findByIds(std::vector<long long> ids, const std::string& column = "id", Query base = Query()) const {
        std::sort(ids.begin(), ids.end());
        ids.erase(std::unique(ids.begin(), ids.end()), ids.end());
        std::vector<T> out;
        constexpr std::size_t kChunk = 100;
        for (std::size_t start = 0; start < ids.size(); start += kChunk) {
            const std::vector<long long> chunk(ids.begin() + static_cast<std::ptrdiff_t>(start),
                                               ids.begin() + static_cast<std::ptrdiff_t>(std::min(ids.size(), start + kChunk)));
            Query q = base;
            q.in(column, chunk);
            auto rows = find(q);
            out.insert(out.end(), rows.begin(), rows.end());
        }
        return out;
    }

    T insert(const T& entity) {
        const Json rows = db_.insert(T::TABLE, entity.toJson(), T::SELECT);
        if (rows.size() == 0) throw DatabaseException(std::string("Insert into ") + T::TABLE + " returned no row", 0);
        return T::fromJson(rows.at(0));
    }

    std::vector<T> insertMany(const std::vector<T>& entities) {
        if (entities.empty()) return {};
        return mapRows(db_.insert(T::TABLE, toJsonArray(entities), T::SELECT));
    }

    std::vector<T> upsertMany(const std::vector<T>& entities, const std::string& onConflict,
                              bool ignoreDuplicates = false) {
        if (entities.empty()) return {};
        return mapRows(db_.upsert(T::TABLE, toJsonArray(entities), onConflict, ignoreDuplicates, T::SELECT));
    }

    T update(long long id, const Json& changes) {
        const Json rows = db_.update(T::TABLE, Query().eq("id", id), changes, T::SELECT);
        if (rows.size() == 0) throw NotFoundException(std::string("No record #") + std::to_string(id) + " in " + T::TABLE);
        return T::fromJson(rows.at(0));
    }

    bool remove(long long id) { return db_.remove(T::TABLE, Query().eq("id", id)) > 0; }

    long long count(const Query& filter = Query()) const { return db_.count(T::TABLE, filter); }

private:
    static Json toJsonArray(const std::vector<T>& entities) {
        Json array = Json::array();
        for (const auto& e : entities) array.push(e.toJson());
        return array;
    }

    static std::vector<T> mapRows(const Json& rows) {
        std::vector<T> out;
        out.reserve(rows.size());
        for (const auto& row : rows.items()) out.push_back(T::fromJson(row));
        return out;
    }

    SupabaseClient& db_;
};

}  // namespace portal
