// ============================================================================
//  SupabaseClient.h - talks to the Supabase database through its REST API
//  (PostgREST): https://<project>.supabase.co/rest/v1/<table>
//  OOP concepts: composition (owns an HttpClient through unique_ptr),
//  dependency injection (any HttpClient implementation can be passed in).
// ============================================================================
#pragma once

#include <cstddef>
#include <memory>
#include <string>

#include "core/Json.hpp"
#include "db/Query.hpp"
#include "net/HttpClient.hpp"

namespace portal {

class SupabaseClient {
public:
    SupabaseClient(std::string projectUrl, std::string apiKey, std::unique_ptr<HttpClient> http);

    /// SELECT - transparently follows pagination, so any number of rows is returned.
    Json select(const std::string& table, const Query& query = Query()) const;
    /// INSERT one object or an array of objects; returns the inserted rows.
    Json insert(const std::string& table, const Json& rows, const std::string& returnColumns = "*");
    /// INSERT ... ON CONFLICT (onConflict) DO UPDATE  (or DO NOTHING when ignoreDuplicates)
    Json upsert(const std::string& table, const Json& rows, const std::string& onConflict,
                bool ignoreDuplicates = false, const std::string& returnColumns = "*");
    /// UPDATE rows matching the filter; returns the updated rows.
    Json update(const std::string& table, const Query& filter, const Json& changes,
                const std::string& returnColumns = "*");
    /// DELETE rows matching the filter; returns how many were deleted.
    std::size_t remove(const std::string& table, const Query& filter);
    /// SELECT count(*) using PostgREST's exact count header.
    long long count(const std::string& table, const Query& filter = Query()) const;
    /// false when PostgREST says the table does not exist.
    bool tableExists(const std::string& table) const;

    /// Current time on the Supabase server (local clock corrected by the HTTP Date header),
    /// so OTP attendance windows do not depend on a lab PC's clock being right.
    long long serverNow() const;

    const std::string& projectUrl() const { return url_; }
    std::string backendName() const { return http_->backendName(); }
    std::size_t requestCount() const { return requests_; }

private:
    HttpResponse execute(const std::string& method, const std::string& table, const std::string& query,
                         const std::string& body, const HeaderList& extraHeaders) const;
    [[noreturn]] void raiseError(const HttpResponse& response, const std::string& action) const;
    Json parseRows(const HttpResponse& response, const std::string& action) const;

    static constexpr int kPageSize = 1000;
    static constexpr std::size_t kInsertBatch = 500;

    std::string url_;
    std::string key_;
    std::unique_ptr<HttpClient> http_;
    mutable std::size_t requests_ = 0;
    mutable long long clockSkew_ = 0;  // server time - local time (seconds)
};

}  // namespace portal
