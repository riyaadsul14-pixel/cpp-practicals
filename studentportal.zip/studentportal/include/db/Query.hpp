// ============================================================================
//  Query.h - fluent builder for Supabase (PostgREST) filters
//  Example:  Query().select("*").eq("semester", 5).order("prn").limit(10)
//  becomes   select=*&semester=eq.5&order=prn.asc&limit=10
//  OOP concepts: encapsulation + method chaining (fluent interface).
// ============================================================================
#pragma once

#include <string>
#include <utility>
#include <vector>

namespace portal {

class Query {
public:
    Query& select(const std::string& columns);

    Query& eq(const std::string& column, const std::string& value);
    Query& eq(const std::string& column, long long value);
    Query& eqBool(const std::string& column, bool value);
    Query& neq(const std::string& column, const std::string& value);
    Query& gt(const std::string& column, long long value);
    Query& gte(const std::string& column, const std::string& value);
    Query& lte(const std::string& column, const std::string& value);
    Query& lt(const std::string& column, const std::string& value);
    Query& ilike(const std::string& column, const std::string& pattern);  // '*' is the wildcard
    Query& in(const std::string& column, const std::vector<long long>& values);
    Query& inText(const std::string& column, const std::vector<std::string>& values);
    Query& isNull(const std::string& column);

    Query& order(const std::string& column, bool ascending = true);
    Query& limit(int count);
    Query& offset(int count);

    bool hasSelect() const { return !select_.empty(); }
    bool hasFilters() const { return !filters_.empty(); }
    bool hasOrder() const { return !orders_.empty(); }
    int limitValue() const { return limit_; }

    /// URL query string (values are percent-encoded).
    std::string build(bool includeSelect = true) const;

private:
    Query& addFilter(const std::string& column, const std::string& expression);

    std::string select_;
    std::vector<std::pair<std::string, std::string>> filters_;
    std::vector<std::string> orders_;
    int limit_ = -1;
    int offset_ = 0;
};

}  // namespace portal
