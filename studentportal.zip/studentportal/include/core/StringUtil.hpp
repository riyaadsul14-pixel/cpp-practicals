// ============================================================================
//  StringUtil.h - small string helpers (trim, padding, Indian money format ...)
// ============================================================================
#pragma once

#include <cstddef>
#include <string>
#include <vector>

namespace portal::str {

std::string trim(const std::string& text);
std::string toLower(std::string text);
std::string toUpper(std::string text);
std::vector<std::string> split(const std::string& text, char delimiter);
std::string join(const std::vector<std::string>& parts, const std::string& separator);
bool startsWith(const std::string& text, const std::string& prefix);
bool endsWith(const std::string& text, const std::string& suffix);
bool equalsIgnoreCase(const std::string& a, const std::string& b);
bool containsIgnoreCase(const std::string& haystack, const std::string& needle);
std::string replaceAll(std::string text, const std::string& from, const std::string& to);

/// Number of visible characters in a UTF-8 string (code points).
std::size_t displayWidth(const std::string& utf8);
std::string truncate(const std::string& utf8, std::size_t width);
std::string padRight(const std::string& text, std::size_t width);
std::string padLeft(const std::string& text, std::size_t width);
std::string center(const std::string& text, std::size_t width);
std::vector<std::string> wrap(const std::string& text, std::size_t width);

std::string formatFixed(double value, int decimals);
/// Indian digit grouping: 185000 -> "Rs. 1,85,000.00"
std::string formatMoney(double amount);
std::string formatPercent(double value, int decimals = 1);
std::string zeroPad(long long value, int width);

std::string urlEncode(const std::string& text);
bool parseInt(const std::string& text, long long& out);
bool parseDouble(const std::string& text, double& out);

}  // namespace portal::str
