// ============================================================================
//  Json.h - a small, dependency-free JSON value class (parse + serialize)
//  Used to talk to the Supabase REST API (PostgREST speaks JSON).
//  OOP concepts: encapsulation (private storage, public typed accessors),
//  operator overloading (operator[] / operator==), static factory methods.
// ============================================================================
#pragma once

#include <cstddef>
#include <string>
#include <type_traits>
#include <vector>

namespace portal {

class Json {
public:
    enum class Type { Null, Bool, Number, String, Array, Object };

    // ---- construction -----------------------------------------------------
    Json() = default;
    Json(std::nullptr_t) {}
    Json(bool value) : type_(Type::Bool), bool_(value) {}
    Json(double value) : type_(Type::Number), number_(value) {}
    template <typename T,
              typename std::enable_if<std::is_integral<T>::value && !std::is_same<T, bool>::value,
                                      int>::type = 0>
    Json(T value) : type_(Type::Number), number_(static_cast<double>(value)) {}
    Json(const char* value) : type_(Type::String), string_(value ? value : "") {}
    Json(std::string value) : type_(Type::String), string_(std::move(value)) {}

    static Json array();
    static Json object();
    /// Parses JSON text. Throws JsonException on malformed input.
    static Json parse(const std::string& text);

    // ---- type queries -----------------------------------------------------
    Type type() const { return type_; }
    bool isNull() const { return type_ == Type::Null; }
    bool isBool() const { return type_ == Type::Bool; }
    bool isNumber() const { return type_ == Type::Number; }
    bool isString() const { return type_ == Type::String; }
    bool isArray() const { return type_ == Type::Array; }
    bool isObject() const { return type_ == Type::Object; }

    // ---- strict accessors (throw JsonException on type mismatch) ------------
    bool asBool() const;
    double asDouble() const;
    long long asInt() const;
    const std::string& asString() const;

    // ---- array API --------------------------------------------------------
    std::size_t size() const;
    void push(Json value);
    const Json& at(std::size_t index) const;
    Json& at(std::size_t index);
    const std::vector<Json>& items() const { return items_; }

    // ---- object API -------------------------------------------------------
    bool has(const std::string& key) const;
    Json& operator[](const std::string& key);              // inserts null if missing
    const Json& operator[](const std::string& key) const;  // returns null if missing
    const std::vector<std::string>& keys() const { return keys_; }
    bool erase(const std::string& key);

    // ---- lenient, null-safe getters used by the model classes -------------
    std::string getString(const std::string& key, const std::string& fallback = "") const;
    long long getInt(const std::string& key, long long fallback = 0) const;
    double getDouble(const std::string& key, double fallback = 0.0) const;
    bool getBool(const std::string& key, bool fallback = false) const;
    bool isNullOrMissing(const std::string& key) const;

    // ---- serialization ----------------------------------------------------
    std::string dump() const;

    bool operator==(const Json& other) const;
    bool operator!=(const Json& other) const { return !(*this == other); }

private:
    void dumpTo(std::string& out) const;

    Type type_ = Type::Null;
    bool bool_ = false;
    double number_ = 0.0;
    std::string string_;
    std::vector<std::string> keys_;  // object keys (insertion order)
    std::vector<Json> items_;        // array elements OR object values
};

}  // namespace portal
