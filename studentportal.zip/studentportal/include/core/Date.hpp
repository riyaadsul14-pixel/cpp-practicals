// ============================================================================
//  Date.h - calendar date value type + timestamp helpers
//  OOP concepts: encapsulation (always-valid object), operator overloading
//  (==, <, -, ...), static factory methods.
// ============================================================================
#pragma once

#include <string>

namespace portal {

class Date {
public:
    Date() = default;                 // "empty" date (no value)
    Date(int year, int month, int day);  // throws ValidationException if invalid

    static Date today();
    static Date fromDays(long long daysSinceEpoch);
    /// Accepts YYYY-MM-DD, DD-MM-YYYY or DD/MM/YYYY (also ISO timestamps).
    static Date parse(const std::string& text);  // throws ValidationException
    static bool tryParse(const std::string& text, Date& out);
    static bool isValid(int year, int month, int day);
    static bool isLeapYear(int year);
    static int daysInMonth(int year, int month);

    bool isEmpty() const { return year_ == 0; }
    int year() const { return year_; }
    int month() const { return month_; }
    int day() const { return day_; }

    long long toDays() const;  // days since 1970-01-01
    int weekday() const;       // 0 = Sunday ... 6 = Saturday
    bool isWeekend() const;
    Date addDays(long long days) const;
    int ageOn(const Date& reference) const;

    std::string toIso() const;      // 2026-11-18 ("" when empty)
    std::string toDisplay() const;  // 18-Nov-2026 ("-" when empty)
    std::string weekdayName() const;  // Mon

    friend bool operator==(const Date& a, const Date& b) { return a.toDays() == b.toDays() && a.isEmpty() == b.isEmpty(); }
    friend bool operator!=(const Date& a, const Date& b) { return !(a == b); }
    friend bool operator<(const Date& a, const Date& b) { return a.toDays() < b.toDays(); }
    friend bool operator>(const Date& a, const Date& b) { return b < a; }
    friend bool operator<=(const Date& a, const Date& b) { return !(b < a); }
    friend bool operator>=(const Date& a, const Date& b) { return !(a < b); }
    /// Number of days between two dates (a - b).
    friend long long operator-(const Date& a, const Date& b) { return a.toDays() - b.toDays(); }

private:
    int year_ = 0;
    int month_ = 0;
    int day_ = 0;
};

class DateTime {
public:
    static long long nowEpoch();
    static std::string nowIsoUtc();  // 2026-11-18T09:30:00Z
    /// Parses "2026-11-18T09:30:00.123+00:00" style timestamps into epoch seconds.
    static bool parseIso(const std::string& text, long long& epochSeconds);
    /// Parses an HTTP "Date" header: "Wed, 18 Nov 2026 10:00:00 GMT".
    static bool parseHttpDate(const std::string& text, long long& epochSeconds);
    static std::string formatLocal(long long epochSeconds);  // 18-Nov-2026 03:00 PM
    static std::string formatIsoAsLocal(const std::string& iso);  // "-" if empty/invalid
    static std::string fileStamp();  // 20261118_150000 (local time)
};

}  // namespace portal
