// ============================================================================
//  Validator.h - input validation rules (static utility class)
// ============================================================================
#pragma once

#include <string>

namespace portal {

class Validator {
public:
    Validator() = delete;  // pure utility class - never instantiated

    static bool isEmail(const std::string& email);
    static std::string normalizePhone(const std::string& phone);  // strips +91, spaces, dashes
    static bool isIndianMobile(const std::string& phone);         // 10 digits starting 6-9
    static bool isPrn(const std::string& prn);                    // 6-20 upper-case letters/digits
    static bool isUsername(const std::string& username);
    static bool isPersonName(const std::string& name);
    static bool isCourseCode(const std::string& code);
    static bool isDivision(const std::string& division);
    static bool isAcademicYear(const std::string& year);  // "2026-27"
    static bool isSemester(long long semester) { return semester >= 1 && semester <= 8; }

    /// Throws ValidationException(message) when condition is false.
    static void require(bool condition, const std::string& message);
};

}  // namespace portal
