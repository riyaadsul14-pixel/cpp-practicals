// ============================================================================
//  Csv.h - RFC-4180 style CSV reader / writer (quotes, commas, new lines)
//  Lines starting with '#' are treated as comments.
// ============================================================================
#pragma once

#include <filesystem>
#include <map>
#include <string>
#include <vector>

namespace portal {

/// One data row of a CSV file, addressable by (lower-case) header name.
class CsvRecord {
public:
    CsvRecord(std::size_t number, std::map<std::string, std::string> fields)
        : number_(number), fields_(std::move(fields)) {}

    std::size_t number() const { return number_; }  // 1-based data row number
    std::string get(const std::string& column) const;  // trimmed, "" if missing

private:
    std::size_t number_;
    std::map<std::string, std::string> fields_;
};

class Csv {
public:
    using Row = std::vector<std::string>;

    static std::vector<Row> parse(const std::string& content);
    static std::vector<Row> readFile(const std::filesystem::path& path);
    /// First row is the header; returns one CsvRecord per data row.
    static std::vector<CsvRecord> readRecords(const std::filesystem::path& path);

    static std::string escape(const std::string& field);
    static std::string format(const std::vector<Row>& rows);
    static void writeFile(const std::filesystem::path& path, const std::vector<Row>& rows);
};

}  // namespace portal
