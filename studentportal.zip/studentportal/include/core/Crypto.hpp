// ============================================================================
//  Crypto.h - SHA-256, HMAC-SHA256, PBKDF2 and the PasswordHasher
//  Passwords are NEVER stored in plain text. They are stored as
//      pbkdf2_sha256$<iterations>$<salt-hex>$<hash-hex>
//  (same idea as Django). Everything is implemented in pure C++.
// ============================================================================
#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace portal {

class Sha256 {
public:
    using Digest = std::array<std::uint8_t, 32>;

    Sha256();
    void update(const std::uint8_t* data, std::size_t length);
    void update(const std::string& data);
    Digest finish();  // finalizes; the object must not be updated afterwards

    static Digest digest(const std::string& data);
    static std::string hexDigest(const std::string& data);

private:
    void transform(const std::uint8_t* block);

    std::array<std::uint32_t, 8> state_{};
    std::array<std::uint8_t, 64> buffer_{};
    std::size_t bufferLength_ = 0;
    std::uint64_t totalLength_ = 0;
};

std::string toHex(const std::uint8_t* data, std::size_t length);
std::vector<std::uint8_t> fromHex(const std::string& hex);  // throws std::invalid_argument

Sha256::Digest hmacSha256(const std::string& key, const std::string& message);

/// PBKDF2-HMAC-SHA256 (RFC 8018)
std::vector<std::uint8_t> pbkdf2HmacSha256(const std::string& password, const std::string& salt,
                                           std::uint32_t iterations, std::size_t keyLength);

class PasswordHasher {
public:
    static constexpr std::uint32_t kDefaultIterations = 100000;

    static std::string hash(const std::string& password, std::uint32_t iterations = kDefaultIterations);
    static bool verify(const std::string& password, const std::string& storedHash);

    /// Returns an empty string when the password is strong enough,
    /// otherwise a human readable reason.
    static std::string strengthProblem(const std::string& password);
    /// Random password that satisfies the strength rules, e.g. "Adypu@4821kq"
    static std::string generateTemporaryPassword();

private:
    static std::string randomBytes(std::size_t count);
};

}  // namespace portal
