// ============================================================================
//  Config.h - reads config/portal.conf (simple KEY=VALUE file)
// ============================================================================
#pragma once

#include <filesystem>
#include <map>
#include <string>

namespace portal {

class Config {
public:
    static Config loadFile(const std::filesystem::path& path);
    static Config fromValues(const std::map<std::string, std::string>& values);
    /// Finds portal.conf: explicit path, ./config, next to the exe, or one/two levels above it.
    static std::filesystem::path locate(const std::string& explicitPath, const std::filesystem::path& exeDir);

    bool has(const std::string& key) const;
    std::string get(const std::string& key, const std::string& fallback = "") const;
    std::string require(const std::string& key) const;  // throws ConfigException
    int getInt(const std::string& key, int fallback) const;
    double getDouble(const std::string& key, double fallback) const;

    const std::filesystem::path& sourcePath() const { return source_; }
    /// Folder that contains the config/ folder (the project root).
    std::filesystem::path projectRoot() const;
    /// Reads a path setting; relative paths are resolved against projectRoot().
    std::filesystem::path resolvePath(const std::string& key, const std::string& fallback) const;

private:
    std::map<std::string, std::string> values_;
    std::filesystem::path source_;
};

}  // namespace portal
