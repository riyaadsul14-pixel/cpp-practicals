// ============================================================================
//  Exceptions.h - exception hierarchy used across the Student Portal
//  OOP concept: Inheritance (every portal error IS-A PortalException, which
//  IS-A std::runtime_error) so callers can catch broadly or specifically.
// ============================================================================
#pragma once

#include <stdexcept>
#include <string>
#include <utility>

namespace portal {

class PortalException : public std::runtime_error {
public:
    explicit PortalException(const std::string& message) : std::runtime_error(message) {}
};

/// Missing / malformed config/portal.conf
class ConfigException : public PortalException {
public:
    using PortalException::PortalException;
};

/// Malformed JSON text or wrong JSON type access
class JsonException : public PortalException {
public:
    using PortalException::PortalException;
};

/// Could not reach Supabase (DNS, TLS, timeout, no internet ...)
class NetworkException : public PortalException {
public:
    using PortalException::PortalException;
};

/// User supplied an invalid value (bad email, marks out of range ...)
class ValidationException : public PortalException {
public:
    using PortalException::PortalException;
};

/// Login / password problems
class AuthException : public PortalException {
public:
    using PortalException::PortalException;
};

/// A requested record does not exist
class NotFoundException : public PortalException {
public:
    using PortalException::PortalException;
};

/// stdin reached end-of-file (e.g. scripted input finished)
class InputClosedException : public PortalException {
public:
    InputClosedException() : PortalException("Input stream closed") {}
};

/// Supabase / PostgREST returned an error response
class DatabaseException : public PortalException {
public:
    DatabaseException(const std::string& message, int httpStatus, std::string code = "")
        : PortalException(message), httpStatus_(httpStatus), code_(std::move(code)) {}

    int httpStatus() const { return httpStatus_; }
    const std::string& code() const { return code_; }

    bool isUniqueViolation() const { return code_ == "23505"; }
    bool isForeignKeyViolation() const { return code_ == "23503"; }
    bool isMissingTable() const { return code_ == "PGRST205" || code_ == "42P01"; }

private:
    int httpStatus_;
    std::string code_;
};

}  // namespace portal
