// ============================================================================
//  PortalApp.h - program entry: command-line options, setup checks, login loop
// ============================================================================
#pragma once

#include <string>

namespace portal {

class PortalContext;
class User;

class PortalApp {
public:
    static constexpr const char* kVersion = "1.0.0";
    int run(int argc, char** argv);

private:
    struct Options {
        std::string configPath;
        bool check = false;
        bool seed = false;
        bool resetAndSeed = false;
        bool help = false;
        bool version = false;
    };

    static Options parseArguments(int argc, char** argv);
    static void printUsage();
    static bool requireSchema(PortalContext& ctx);
    int runCheck(PortalContext& ctx);
    int runSeeder(PortalContext& ctx, bool reset);
    void ensureAdministrator(PortalContext& ctx);
    void loginLoop(PortalContext& ctx);
    void login(PortalContext& ctx);
    void verifyCertificate(PortalContext& ctx);
    void about(PortalContext& ctx);
    void forcePasswordChange(PortalContext& ctx, User& user);
};

}  // namespace portal
