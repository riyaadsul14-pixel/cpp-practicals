// ============================================================================
//  PortalContext.h - owns every service (composition root)
//  Members are declared in dependency order, so each service is constructed
//  after the services it depends on and destroyed before them (RAII).
// ============================================================================
#pragma once

#include <string>
#include <vector>

#include "app/UniversityProfile.hpp"
#include "core/Config.hpp"
#include "db/SupabaseClient.hpp"
#include "services/AcademicService.hpp"
#include "services/AttendanceService.hpp"
#include "services/AuditService.hpp"
#include "services/AuthService.hpp"
#include "services/CampusServices.hpp"
#include "services/ReportService.hpp"
#include "services/ResultService.hpp"
#include "services/UserService.hpp"

namespace portal {

class PortalContext {
public:
    explicit PortalContext(const Config& config);
    PortalContext(const PortalContext&) = delete;
    PortalContext& operator=(const PortalContext&) = delete;

    static const std::vector<std::string>& requiredTables();
    std::vector<std::string> missingTables() const;

    const Config& config() const { return config_; }
    const UniversityProfile& profile() const { return profile_; }
    SupabaseClient& db() { return db_; }
    AuditService& audit() { return audit_; }
    UserService& users() { return users_; }
    AuthService& auth() { return auth_; }
    AcademicService& academic() { return academic_; }
    AttendanceService& attendance() { return attendance_; }
    ResultService& results() { return results_; }
    NoticeService& notices() { return notices_; }
    FeeService& fees() { return fees_; }
    DocumentService& documents() { return documents_; }
    ReportService& reports() { return reports_; }

private:
    Config config_;
    UniversityProfile profile_;
    SupabaseClient db_;
    AuditService audit_;
    UserService users_;
    AuthService auth_;
    AcademicService academic_;
    AttendanceService attendance_;
    ResultService results_;
    NoticeService notices_;
    FeeService fees_;
    DocumentService documents_;
    ReportService reports_;
};

}  // namespace portal
