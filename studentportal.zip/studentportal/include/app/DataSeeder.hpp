// ============================================================================
//  DataSeeder.h - loads the sample ADYPU B.Tech CSE data (data/*.csv) into
//  Supabase and generates realistic marks, attendance and fee records.
// ============================================================================
#pragma once

#include <ostream>

#include "app/PortalContext.hpp"

namespace portal {

class DataSeeder {
public:
    DataSeeder(PortalContext& context, std::ostream& log) : ctx_(context), log_(log) {}

    bool isDatabaseEmpty() const;
    void wipeAllData();  // deletes every row of every portal table
    void seed();

private:
    PortalContext& ctx_;
    std::ostream& log_;
};

}  // namespace portal
