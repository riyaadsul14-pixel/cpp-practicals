// ============================================================================
//  UniversityProfile.h - identity of Ajeenkya DY Patil University (ADYPU)
//  Defaults are built in for ADYPU; config/portal.conf can fine-tune them
//  (e.g. the academic year) without recompiling.
// ============================================================================
#pragma once

#include <filesystem>
#include <string>

#include "core/Config.hpp"

namespace portal {

class UniversityProfile {
public:
    static UniversityProfile fromConfig(const Config& config);

    const std::string& name() const { return name_; }
    const std::string& shortName() const { return shortName_; }
    const std::string& campus() const { return campus_; }
    const std::string& school() const { return school_; }
    const std::string& department() const { return department_; }
    const std::string& program() const { return program_; }
    const std::string& website() const { return website_; }
    const std::string& academicYear() const { return academicYear_; }
    double minAttendance() const { return minAttendance_; }
    const std::string& documentSecret() const { return documentSecret_; }
    const std::filesystem::path& exportDir() const { return exportDir_; }
    const std::filesystem::path& dataDir() const { return dataDir_; }
    int academicYearStart() const;  // 2026 for "2026-27"

private:
    std::string name_ = "Ajeenkya DY Patil University";
    std::string shortName_ = "ADYPU";
    std::string campus_ = "D Y Patil Knowledge City, Charholi Bk., Via Lohegaon, Pune - 412105";
    std::string school_ = "School of Engineering";
    std::string department_ = "Department of Computer Science & Engineering";
    std::string program_ = "B.Tech Computer Science & Engineering";
    std::string website_ = "www.adypu.edu.in";
    std::string academicYear_ = "2026-27";
    double minAttendance_ = 75.0;
    std::string documentSecret_;
    std::filesystem::path exportDir_;
    std::filesystem::path dataDir_;
};

}  // namespace portal
