// ============================================================================
//  Student.h - a B.Tech CSE student  (Student IS-A User)
//  Stored in two tables: `users` (login) + `students` (academic profile).
// ============================================================================
#pragma once

#include <string>

#include "core/Date.hpp"
#include "models/User.hpp"

namespace portal {

class Student : public User {
public:
    static constexpr const char* TABLE = "students";
    static constexpr const char* SELECT = "*,users(*)";  // embed the users row

    Role role() const override { return Role::Student; }
    std::string headline() const override;
    void printProfile(std::ostream& os) const override;
    Json toJson() const override;  // `students` table columns
    static Student fromJson(const Json& row);

    const std::string& prn() const { return prn_; }
    int semester() const { return semester_; }
    const std::string& division() const { return division_; }
    int admissionYear() const { return admissionYear_; }
    const Date& dateOfBirth() const { return dateOfBirth_; }
    const std::string& gender() const { return gender_; }
    const std::string& guardianName() const { return guardianName_; }
    const std::string& guardianPhone() const { return guardianPhone_; }
    const std::string& address() const { return address_; }

    void setPrn(const std::string& prn);
    void setSemester(int semester);
    void setDivision(const std::string& division);
    void setAdmissionYear(int year);
    void setDateOfBirth(const Date& dob);
    void setGender(const std::string& gender);
    void setGuardianName(const std::string& name);
    void setGuardianPhone(const std::string& phone);
    void setAddress(const std::string& address);

    int yearOfStudy() const { return (semester_ + 1) / 2; }  // 1..4
    std::string yearLabel() const;                            // "Third Year"
    /// Academic year in which the given semester was/is studied, e.g. "2025-26".
    std::string academicYearForSemester(int semester) const;

private:
    std::string prn_;
    int semester_ = 1;
    std::string division_ = "A";
    int admissionYear_ = 0;
    Date dateOfBirth_;
    std::string gender_;
    std::string guardianName_;
    std::string guardianPhone_;
    std::string address_;
};

}  // namespace portal
