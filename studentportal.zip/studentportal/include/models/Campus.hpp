// ============================================================================
//  Campus.h - notices, fees, placement drives, verifiable documents, audit log
// ============================================================================
#pragma once

#include <string>
#include <vector>

#include "core/Date.hpp"
#include "models/Entity.hpp"

namespace portal {

// ------------------------------------------------------------------ Notice --
class Notice : public Entity {
public:
    static constexpr const char* TABLE = "notices";
    static constexpr const char* SELECT = "*,users(full_name)";

    Json toJson() const override;
    static Notice fromJson(const Json& row);

    const std::string& title() const { return title_; }
    const std::string& body() const { return body_; }
    const std::string& audience() const { return audience_; }  // all | students | faculty
    long long postedBy() const { return postedBy_; }
    const std::string& postedByName() const { return postedByName_; }
    const std::string& createdAt() const { return createdAt_; }

    void setTitle(const std::string& title);
    void setBody(const std::string& body);
    void setAudience(const std::string& audience);
    void setPostedBy(long long userId) { postedBy_ = userId; }

private:
    std::string title_;
    std::string body_;
    std::string audience_ = "all";
    long long postedBy_ = 0;
    std::string postedByName_;
    std::string createdAt_;
};

// -------------------------------------------------------------- FeeAccount --
class FeeAccount : public Entity {
public:
    static constexpr const char* TABLE = "fees";
    static constexpr const char* SELECT = "*";

    Json toJson() const override;
    static FeeAccount fromJson(const Json& row);

    long long studentId() const { return studentId_; }
    const std::string& academicYear() const { return academicYear_; }
    const std::string& description() const { return description_; }
    double amount() const { return amount_; }
    const Date& dueDate() const { return dueDate_; }

    void setStudentId(long long id) { studentId_ = id; }
    void setAcademicYear(const std::string& year);
    void setDescription(const std::string& description);
    void setAmount(double amount);
    void setDueDate(const Date& date) { dueDate_ = date; }

private:
    long long studentId_ = 0;
    std::string academicYear_;
    std::string description_ = "Tuition Fee";
    double amount_ = 0;
    Date dueDate_;
};

// ----------------------------------------------------------------- Payment --
class Payment : public Entity {
public:
    static constexpr const char* TABLE = "fee_payments";
    static constexpr const char* SELECT = "*";
    static const std::vector<std::string>& modes();  // UPI, Card, NetBanking, Cash, Cheque, DD

    Json toJson() const override;
    static Payment fromJson(const Json& row);

    long long feeId() const { return feeId_; }
    long long studentId() const { return studentId_; }
    double amount() const { return amount_; }
    const std::string& mode() const { return mode_; }
    const std::string& reference() const { return reference_; }
    const Date& paidOn() const { return paidOn_; }
    std::string receiptNumber() const;  // ADYPU/FEE/2026/000123

    void setFeeId(long long id) { feeId_ = id; }
    void setStudentId(long long id) { studentId_ = id; }
    void setAmount(double amount);
    void setMode(const std::string& mode);
    void setReference(const std::string& reference);
    void setPaidOn(const Date& date);
    void setRecordedBy(long long userId) { recordedBy_ = userId; }

private:
    long long feeId_ = 0;
    long long studentId_ = 0;
    double amount_ = 0;
    std::string mode_ = "UPI";
    std::string reference_;
    Date paidOn_;
    long long recordedBy_ = 0;
};

// ---------------------------------------------------------- DocumentRecord --
/// A bonafide certificate / report card that carries an HMAC verification code.
class DocumentRecord : public Entity {
public:
    static constexpr const char* TABLE = "documents";
    static constexpr const char* SELECT = "*";

    Json toJson() const override;
    static DocumentRecord fromJson(const Json& row);

    long long studentId() const { return studentId_; }
    const std::string& docType() const { return docType_; }  // bonafide | report_card
    const std::string& purpose() const { return purpose_; }
    const std::string& status() const { return status_; }    // pending | approved | rejected
    const std::string& verificationCode() const { return verificationCode_; }
    const std::string& contentDigest() const { return contentDigest_; }
    const Date& issuedOn() const { return issuedOn_; }
    const std::string& remarks() const { return remarks_; }
    const std::string& requestedAt() const { return requestedAt_; }
    std::string typeTitle() const { return docType_ == "bonafide" ? "Bonafide Certificate" : "Progress Report Card"; }

    void setStudentId(long long id) { studentId_ = id; }
    void setDocType(const std::string& type);
    void setPurpose(const std::string& purpose);
    void setStatus(const std::string& status) { status_ = status; }

private:
    long long studentId_ = 0;
    std::string docType_ = "bonafide";
    std::string purpose_;
    std::string status_ = "pending";
    std::string verificationCode_;
    std::string contentDigest_;
    Date issuedOn_;
    std::string remarks_;
    std::string requestedAt_;
};

// -------------------------------------------------------------- AuditEntry --
/// One link of the tamper-evident (hash-chained) audit trail.
class AuditEntry : public Entity {
public:
    static constexpr const char* TABLE = "audit_log";
    static constexpr const char* SELECT = "*";
    static const std::string& genesisHash();  // 64 zeros

    Json toJson() const override;
    static AuditEntry fromJson(const Json& row);
    /// SHA-256(prevHash | actorId | actorName | action | details | createdAt)
    static std::string computeHash(const std::string& prevHash, long long actorId, const std::string& actorName,
                                   const std::string& action, const std::string& details, const std::string& createdAt);

    long long actorId() const { return actorId_; }
    const std::string& actorName() const { return actorName_; }
    const std::string& action() const { return action_; }
    const std::string& details() const { return details_; }
    const std::string& createdAt() const { return createdAt_; }
    const std::string& prevHash() const { return prevHash_; }
    const std::string& hash() const { return hash_; }
    std::string recomputeHash() const;

    void fill(long long actorId, const std::string& actorName, const std::string& action, const std::string& details,
              const std::string& createdAt, const std::string& prevHash);

private:
    long long actorId_ = 0;
    std::string actorName_;
    std::string action_;
    std::string details_;
    std::string createdAt_;
    std::string prevHash_;
    std::string hash_;
};

}  // namespace portal
