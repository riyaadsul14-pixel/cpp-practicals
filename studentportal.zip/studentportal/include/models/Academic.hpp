// ============================================================================
//  Academic.h - courses, enrollments, attendance and marks
//  Every class IS-A Entity (inheritance) and maps to one Supabase table.
// ============================================================================
#pragma once

#include <optional>
#include <string>
#include <vector>

#include "core/Date.hpp"
#include "models/Entity.hpp"

namespace portal {

// ------------------------------------------------------------------ Course --
class Course : public Entity {
public:
    static constexpr const char* TABLE = "courses";
    static constexpr const char* SELECT = "*";
    static const std::vector<std::string>& types();  // Theory, Lab, Elective, Project

    Json toJson() const override;
    static Course fromJson(const Json& row);

    const std::string& code() const { return code_; }
    const std::string& name() const { return name_; }
    int semester() const { return semester_; }
    int credits() const { return credits_; }
    const std::string& type() const { return type_; }
    long long facultyId() const { return facultyId_; }  // 0 = not assigned
    std::string label() const { return code_ + " - " + name_; }

    void setCode(const std::string& code);
    void setName(const std::string& name);
    void setSemester(int semester);
    void setCredits(int credits);
    void setType(const std::string& type);
    void setFacultyId(long long facultyId) { facultyId_ = facultyId; }

private:
    std::string code_;
    std::string name_;
    int semester_ = 1;
    int credits_ = 3;
    std::string type_ = "Theory";
    long long facultyId_ = 0;
};

// -------------------------------------------------------------- Enrollment --
class Enrollment : public Entity {
public:
    static constexpr const char* TABLE = "enrollments";
    static constexpr const char* SELECT = "*";

    Enrollment() = default;
    Enrollment(long long studentId, long long courseId, std::string academicYear)
        : studentId_(studentId), courseId_(courseId), academicYear_(std::move(academicYear)) {}

    Json toJson() const override;
    static Enrollment fromJson(const Json& row);

    long long studentId() const { return studentId_; }
    long long courseId() const { return courseId_; }
    const std::string& academicYear() const { return academicYear_; }

private:
    long long studentId_ = 0;
    long long courseId_ = 0;
    std::string academicYear_;
};

// -------------------------------------------------------- AttendanceRecord --
class AttendanceRecord : public Entity {
public:
    static constexpr const char* TABLE = "attendance";
    static constexpr const char* SELECT = "*";

    AttendanceRecord() = default;
    AttendanceRecord(long long courseId, long long studentId, const Date& date, bool present, long long markedBy)
        : courseId_(courseId), studentId_(studentId), classDate_(date), present_(present), markedBy_(markedBy) {}

    Json toJson() const override;
    static AttendanceRecord fromJson(const Json& row);

    long long courseId() const { return courseId_; }
    long long studentId() const { return studentId_; }
    const Date& classDate() const { return classDate_; }
    bool present() const { return present_; }
    long long markedBy() const { return markedBy_; }

private:
    long long courseId_ = 0;
    long long studentId_ = 0;
    Date classDate_;
    bool present_ = false;
    long long markedBy_ = 0;
};

// ------------------------------------------------------------- MarkRecord --
enum class ExamComponent { Internal, MidSem, EndSem };

std::string componentLabel(ExamComponent component);   // "Internal (CA)"
std::string componentColumn(ExamComponent component);  // "internal_marks"
double componentMax(ExamComponent component);          // 20 / 30 / 50

class MarkRecord : public Entity {
public:
    static constexpr const char* TABLE = "marks";
    static constexpr const char* SELECT = "*";

    Json toJson() const override;
    static MarkRecord fromJson(const Json& row);

    long long studentId() const { return studentId_; }
    long long courseId() const { return courseId_; }
    std::optional<double> get(ExamComponent component) const;
    void set(ExamComponent component, std::optional<double> value);
    void setStudentId(long long id) { studentId_ = id; }
    void setCourseId(long long id) { courseId_ = id; }

    bool isComplete() const { return internal_ && midsem_ && endsem_; }
    bool hasAny() const { return internal_ || midsem_ || endsem_; }
    double total() const;           // sum of available components (out of 100)
    double continuousTotal() const; // internal + mid-sem (out of 50)

private:
    long long studentId_ = 0;
    long long courseId_ = 0;
    std::optional<double> internal_;
    std::optional<double> midsem_;
    std::optional<double> endsem_;
};

}  // namespace portal
