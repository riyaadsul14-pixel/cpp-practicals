// ============================================================================
//  Faculty.h - a teaching staff member  (Faculty IS-A User)
// ============================================================================
#pragma once

#include <string>

#include "core/Date.hpp"
#include "models/User.hpp"

namespace portal {

class Faculty : public User {
public:
    static constexpr const char* TABLE = "faculty";
    static constexpr const char* SELECT = "*,users(*)";

    Role role() const override { return Role::Faculty; }
    std::string headline() const override;
    void printProfile(std::ostream& os) const override;
    Json toJson() const override;
    static Faculty fromJson(const Json& row);

    const std::string& employeeCode() const { return employeeCode_; }
    const std::string& designation() const { return designation_; }
    const std::string& qualification() const { return qualification_; }
    const std::string& specialization() const { return specialization_; }
    const Date& joiningDate() const { return joiningDate_; }

    void setEmployeeCode(const std::string& code);
    void setDesignation(const std::string& designation);
    void setQualification(const std::string& qualification);
    void setSpecialization(const std::string& specialization);
    void setJoiningDate(const Date& date);

    /// "Dr. Meera Kulkarni (FAC001)"
    std::string displayName() const { return fullName_ + " (" + employeeCode_ + ")"; }

private:
    std::string employeeCode_;
    std::string designation_ = "Assistant Professor";
    std::string qualification_;
    std::string specialization_;
    Date joiningDate_;
};

}  // namespace portal
