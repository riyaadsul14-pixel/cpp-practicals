// ============================================================================
//  Admin.h - portal administrator (Admin IS-A User, only the users table)
// ============================================================================
#pragma once

#include "models/User.hpp"

namespace portal {

class Admin : public User {
public:
    static constexpr const char* TABLE = "users";
    static constexpr const char* SELECT = "*";

    Role role() const override { return Role::Admin; }
    std::string headline() const override { return "Academic Office | Full access"; }
    void printProfile(std::ostream& os) const override;
    Json toJson() const override { return accountJson(false); }
    static Admin fromJson(const Json& row);
};

}  // namespace portal
