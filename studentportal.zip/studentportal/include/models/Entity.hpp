// ============================================================================
//  Entity.h - abstract base class of every database record
//  OOP concepts: abstraction (pure virtual toJson), encapsulation (protected id)
// ============================================================================
#pragma once

#include "core/Json.hpp"

namespace portal {

class Entity {
public:
    virtual ~Entity() = default;

    long long id() const { return id_; }
    void setId(long long id) { id_ = id; }
    bool isPersisted() const { return id_ > 0; }

    /// Column values used when inserting / updating this record.
    virtual Json toJson() const = 0;

protected:
    Entity() = default;
    explicit Entity(long long id) : id_(id) {}
    Entity(const Entity&) = default;
    Entity& operator=(const Entity&) = default;

    long long id_ = 0;
};

}  // namespace portal
