// ============================================================================
//  Dashboard.h - role based menus
//  OOP concepts: abstract base class + Template Method pattern (run() is fixed,
//  title()/menuItems()/handle() are overridden), runtime polymorphism through
//  DashboardFactory, which returns the right dashboard for the logged-in user.
// ============================================================================
#pragma once

#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "app/PortalContext.hpp"
#include "models/Admin.hpp"
#include "models/Faculty.hpp"
#include "models/Student.hpp"

namespace portal {

class Dashboard {
public:
    Dashboard(PortalContext& context, User& user) : ctx_(context), user_(user) {}
    virtual ~Dashboard() = default;
    Dashboard(const Dashboard&) = delete;
    Dashboard& operator=(const Dashboard&) = delete;

    /// Template method: banner -> home summary -> menu loop -> logout.
    void run();

protected:
    virtual std::string title() const = 0;
    virtual std::vector<std::string> menuItems() const = 0;
    virtual void handle(int choice) = 0;
    virtual void showHome() {}

    // ---- shared building blocks used by the derived dashboards -----------
    void showProfile() const;
    void showNotices() const;
    void changePassword();
    std::optional<Course> chooseCourse(const std::vector<Course>& courses) const;
    int chooseSemester(const std::string& prompt, bool allowAll) const;
    std::optional<Student> findStudentInteractive() const;
    void printAttendance(const std::vector<CourseAttendance>& rows) const;
    void printTranscript(const Transcript& transcript) const;
    void printFeeStatements(const std::vector<FeeStatement>& statements) const;
    void printRadar(const std::vector<RadarRow>& rows) const;
    void printStudents(const std::vector<Student>& students) const;
    void postNotice();

    PortalContext& ctx_;
    User& user_;
};

class StudentDashboard final : public Dashboard {
public:
    StudentDashboard(PortalContext& context, Student& student) : Dashboard(context, student), student_(student) {}

protected:
    std::string title() const override { return "STUDENT DASHBOARD"; }
    std::vector<std::string> menuItems() const override;
    void handle(int choice) override;
    void showHome() override;

private:
    void attendanceGuardian();
    void results();
    void targetPlanner();
    void fees();
    void certificates();
    void updateContact();

    Student& student_;
};

class FacultyDashboard final : public Dashboard {
public:
    FacultyDashboard(PortalContext& context, Faculty& faculty) : Dashboard(context, faculty), faculty_(faculty) {}

protected:
    std::string title() const override { return "FACULTY DASHBOARD"; }
    std::vector<std::string> menuItems() const override;
    void handle(int choice) override;
    void showHome() override;

private:
    std::optional<Course> chooseMyCourse() const;
    void myCourses();
    void markAttendance();
    void attendanceReport();
    void enterMarks();
    void resultSheet();
    void radar();
    void exportData();

    Faculty& faculty_;
};

class AdminDashboard final : public Dashboard {
public:
    AdminDashboard(PortalContext& context, Admin& admin) : Dashboard(context, admin) {}

protected:
    std::string title() const override { return "ADMINISTRATOR DASHBOARD"; }
    std::vector<std::string> menuItems() const override;
    void handle(int choice) override;
    void showHome() override;

private:
    void overview();
    void studentMenu();
    void facultyMenu();
    void courseMenu();
    void feeMenu();
    void noticeMenu();
    void radar();
    void certificateRequests();
    void securityMenu();

    void addStudent();
    void editStudent();
    void studentView360();
    void addFaculty();
    void addCourse();
    void recordPayment();
};

/// Factory: picks the dashboard class that matches the user's dynamic type.
class DashboardFactory {
public:
    static std::unique_ptr<Dashboard> create(PortalContext& context, User& user);
};

}  // namespace portal
