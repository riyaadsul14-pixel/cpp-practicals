// ============================================================================
//  Console.h - coloured output and validated keyboard input
//  When input is piped from a file (non-interactive) every answer is echoed,
//  so a scripted run produces a readable transcript (see docs/sample_output.txt).
// ============================================================================
#pragma once

#include <string>
#include <vector>

#include "core/Date.hpp"

namespace portal {

enum class Color { Reset, Red, Green, Yellow, Blue, Magenta, Cyan, Gray, Bold };

class Console {
public:
    Console() = delete;

    static void init();
    static bool interactive() { return interactive_; }
    static std::string paint(const std::string& text, Color color);

    static void banner(const std::vector<std::string>& lines);
    static void heading(const std::string& text);
    static void success(const std::string& message);
    static void error(const std::string& message);
    static void warning(const std::string& message);
    static void info(const std::string& message);
    /// Horizontal bar like  [##########----------]  for percentages.
    static std::string bar(double percent, int width = 20);
    static void clear();
    static void pause();

    // ---- input (throws InputClosedException at end of input) -------------
    static std::string readLine(const std::string& prompt);
    static std::string readRequired(const std::string& prompt);
    static std::string readOptional(const std::string& prompt, const std::string& current);
    static long long readInt(const std::string& prompt, long long min, long long max);
    static long long readIntOr(const std::string& prompt, long long min, long long max, long long fallback);
    static double readDouble(const std::string& prompt, double min, double max);
    static bool confirm(const std::string& question, bool defaultYes = false);
    static Date readDate(const std::string& prompt, const Date& fallback);
    static std::string readPassword(const std::string& prompt);
    /// Prints numbered options and returns 0..options.size() (0 = back / logout).
    static int menu(const std::vector<std::string>& options, const std::string& zeroLabel = "Back");

private:
    static std::string rawLine();
    static bool interactive_;
    static bool colors_;
};

}  // namespace portal
