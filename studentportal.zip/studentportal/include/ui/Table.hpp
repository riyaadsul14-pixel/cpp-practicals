// ============================================================================
//  Table.h - prints neat text tables with automatic column widths
// ============================================================================
#pragma once

#include <iostream>
#include <string>
#include <vector>

namespace portal {

class Table {
public:
    enum class Align { Left, Right };

    explicit Table(std::vector<std::string> headers);
    Table& align(std::size_t column, Align alignment);
    Table& maxWidth(std::size_t column, std::size_t width);
    void addRow(std::vector<std::string> cells);
    bool empty() const { return rows_.empty(); }
    std::size_t size() const { return rows_.size(); }
    void print(std::ostream& os = std::cout) const;

private:
    std::vector<std::string> headers_;
    std::vector<std::vector<std::string>> rows_;
    std::vector<Align> align_;
    std::vector<std::size_t> maxWidth_;
};

}  // namespace portal
