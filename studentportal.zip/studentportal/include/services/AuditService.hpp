// ============================================================================
//  AuditService.h - tamper-evident, hash-chained audit trail
//  Every entry stores SHA-256(previous hash + its own content). Editing or
//  deleting any row directly in the database breaks the chain, and
//  verifyChain() reports exactly where.
// ============================================================================
#pragma once

#include <cstddef>
#include <string>
#include <vector>

#include "db/Repository.hpp"
#include "models/Campus.hpp"
#include "models/User.hpp"

namespace portal {

struct ChainVerification {
    bool intact = true;
    std::size_t entries = 0;
    long long brokenAtId = 0;
    std::string problem;
};

class AuditService {
public:
    explicit AuditService(SupabaseClient& db) : log_(db) {}

    /// Appends an entry. Never throws: auditing must not block the real work.
    void record(const User& actor, const std::string& action, const std::string& details);
    void record(long long actorId, const std::string& actorName, const std::string& action, const std::string& details);

    ChainVerification verifyChain() const;
    std::vector<AuditEntry> recent(int limit) const;
    std::size_t failedWrites() const { return failures_; }

private:
    Repository<AuditEntry> log_;
    std::size_t failures_ = 0;
};

}  // namespace portal
