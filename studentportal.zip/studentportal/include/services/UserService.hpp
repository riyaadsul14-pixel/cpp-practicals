// ============================================================================
//  UserService.h - student, faculty and login-account management
//  A Student/Faculty lives in two tables (users + students/faculty); this
//  service keeps both in sync and rolls back if the second insert fails.
// ============================================================================
#pragma once

#include <filesystem>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "core/Csv.hpp"
#include "db/Repository.hpp"
#include "models/Admin.hpp"
#include "models/Faculty.hpp"
#include "models/Student.hpp"
#include "services/AuditService.hpp"

namespace portal {

struct ImportResult {
    int added = 0;
    std::vector<std::string> errors;
};

struct AccountSummary {
    long long id = 0;
    std::string username;
    std::string fullName;
    std::string email;
    Role role = Role::Student;
    bool active = true;
    bool locked = false;
    std::string lastLoginAt;
};

class UserService {
public:
    UserService(SupabaseClient& db, AuditService& audit);

    // ---- students --------------------------------------------------------
    std::vector<Student> listStudents(int semester = 0) const;  // 0 = all, sorted by PRN
    std::optional<Student> findStudent(long long id) const;
    std::optional<Student> findStudentByPrn(const std::string& prn) const;
    std::vector<Student> searchStudents(const std::string& text) const;
    std::vector<Student> studentsByIds(const std::vector<long long>& ids) const;
    Student createStudent(Student student, const std::string& password, bool mustChange, const User& actor);
    /// Validated bulk creation (used by CSV import and the demo-data seeder).
    ImportResult createStudents(std::vector<Student> students, const std::string& password, bool mustChange,
                                const User* actor);
    Student updateStudent(const Student& student, const User& actor);
    int promoteSemester(int fromSemester, const User& actor);
    ImportResult importStudentsCsv(const std::filesystem::path& csv, const std::string& password, const User& actor);
    static Student studentFromRecord(const CsvRecord& record);

    // ---- faculty ---------------------------------------------------------
    std::vector<Faculty> listFaculty() const;
    std::optional<Faculty> findFaculty(long long id) const;
    std::optional<Faculty> findFacultyByCode(const std::string& code) const;
    Faculty createFaculty(Faculty faculty, const std::string& password, bool mustChange, const User& actor);
    Faculty updateFaculty(const Faculty& faculty, const User& actor);
    std::map<long long, std::string> facultyNames() const;

    // ---- accounts --------------------------------------------------------
    std::vector<AccountSummary> listAccounts() const;
    std::optional<Json> findAccountRow(long long userId) const;
    std::optional<Json> findAccountByLogin(const std::string& usernameOrEmail) const;
    /// Polymorphic factory: builds a Student, Faculty or Admin object from a users row.
    std::unique_ptr<User> loadUser(const Json& accountRow) const;
    void setActive(long long userId, bool active, const User& actor);
    void updateContact(User& user, const std::string& email, const std::string& phone);
    void deleteUser(long long userId, const User& actor);
    long long countAdmins() const;
    Admin createAdmin(Admin admin, const std::string& password);

private:
    long long insertAccount(const User& user);
    std::vector<Json> allAccountRows(const std::string& columns) const;

    SupabaseClient& db_;
    AuditService& audit_;
    Repository<Student> students_;
    Repository<Faculty> faculty_;
};

}  // namespace portal
