// ============================================================================
//  Analytics.h - the "brain" of the portal (pure C++ logic, no database)
//    * GradeCalculator      - ADYPU-style 10-point grading, SGPA / CGPA
//    * TranscriptBuilder    - builds semester-wise results from raw marks
//    * AttendanceGuardian   - "you can miss N more" / "attend next N" advice
//    * GradeTargetPlanner   - greedy optimiser: end-sem marks needed for a target SGPA
//    * RiskAssessor         - Student Success Radar (early-warning risk score)
//  Because these classes are pure logic they are fully unit-tested.
// ============================================================================
#pragma once

#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "models/Academic.hpp"

namespace portal {

struct GradeInfo {
    std::string letter = "-";
    int points = 0;
    bool passed = false;
};

class GradeCalculator {
public:
    static constexpr double kPassTotal = 40.0;   // out of 100
    static constexpr double kPassEndSem = 20.0;  // out of 50 (40% of end-sem)

    /// Grade from the total (rounded to nearest mark) and end-sem marks.
    static GradeInfo grade(double total, double endsem);
    static GradeInfo grade(const MarkRecord& marks);
    /// (minimum rounded total, grade) from best to worst: O, A+, A, B+, B, C, P
    static const std::vector<std::pair<int, GradeInfo>>& bands();
    /// Credit-weighted grade point average; pairs are (credits, grade points).
    static double weightedAverage(const std::vector<std::pair<int, int>>& creditPoints);
    static std::string classification(double cgpa);
};

struct CourseResult {
    Course course;
    std::optional<MarkRecord> marks;
    bool complete = false;
    double total = 0;
    GradeInfo grade;
};

struct SemesterResult {
    int semester = 0;
    std::vector<CourseResult> courses;
    bool declared = false;  // every course has all three components
    double sgpa = 0;
    int creditsRegistered = 0;
    int creditsEarned = 0;
    int backlogs = 0;
};

struct Transcript {
    std::vector<SemesterResult> semesters;
    bool hasCgpa = false;
    double cgpa = 0;
    int creditsEarned = 0;
    int backlogs = 0;
    const SemesterResult* find(int semester) const;
    std::vector<std::pair<int, double>> sgpaHistory() const;  // declared semesters only
};

class TranscriptBuilder {
public:
    static Transcript build(const std::vector<Course>& enrolledCourses, const std::vector<MarkRecord>& marks);
};

class AttendanceGuardian {
public:
    static double percent(int attended, int total);
    /// Consecutive classes that must be attended to reach the target percentage.
    static int classesNeeded(int attended, int total, double targetPercent);
    /// Classes that can still be missed while staying at/above the target.
    static int classesCanMiss(int attended, int total, double targetPercent);
    static std::string advice(int attended, int total, double targetPercent);
};

struct GradeStep {
    std::string letter;
    int points = 0;
    std::optional<double> endsemNeeded;  // nullopt = not reachable any more
};

struct PlanRow {
    Course course;
    double continuous = 0;  // internal + mid-sem already scored (out of 50)
    bool continuousComplete = false;
    std::vector<GradeStep> ladder;
    std::optional<double> requiredEndsem;  // smart-plan target for this course
    GradeInfo plannedGrade;
};

struct TargetPlan {
    double target = 0;
    bool achievable = false;
    double plannedSgpa = 0;
    double maxPossibleSgpa = 0;
    std::vector<PlanRow> rows;
};

class GradeTargetPlanner {
public:
    /// Smallest end-sem score (0.5 steps) giving at least `minPoints` grade points.
    static std::optional<double> endsemNeeded(double continuous, int minPoints);
    static std::vector<GradeStep> ladder(double continuous);
    /// Greedy optimiser: starts every course at the pass mark, then repeatedly upgrades
    /// the course that gives the most SGPA per extra mark until the target is reached.
    static TargetPlan plan(const std::vector<std::pair<Course, MarkRecord>>& currentCourses, double targetSgpa);
};

struct RiskInput {
    bool hasAttendance = false;
    double attendancePercent = 0;
    bool hasMarks = false;
    double continuousPercent = 0;  // internal + mid-sem as % of maximum
    int backlogs = 0;
    double overdueFees = 0;
};

struct RiskReport {
    int score = 0;  // 0 - 100
    std::string level = "LOW";
    std::vector<std::string> reasons;
    std::vector<std::string> actions;
};

class RiskAssessor {
public:
    static RiskReport assess(const RiskInput& input, double minAttendance);
};

}  // namespace portal
