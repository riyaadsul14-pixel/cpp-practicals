// ============================================================================
//  AuthService.h - login, password change/reset and brute-force lockout
// ============================================================================
#pragma once

#include <memory>
#include <string>

#include "services/AuditService.hpp"
#include "services/UserService.hpp"

namespace portal {

class AuthService {
public:
    static constexpr int kMaxFailedAttempts = 5;
    static constexpr int kLockMinutes = 15;

    AuthService(SupabaseClient& db, UserService& users, AuditService& audit)
        : db_(db), users_(users), audit_(audit) {}

    /// Returns the logged-in user as Student, Faculty or Admin (polymorphic).
    /// Throws AuthException with a user-friendly message on failure.
    std::unique_ptr<User> login(const std::string& usernameOrEmail, const std::string& password);
    void changePassword(User& user, const std::string& currentPassword, const std::string& newPassword);
    /// Admin action: sets a random temporary password (must be changed at next login) and unlocks.
    std::string resetPassword(long long userId, const User& admin);
    void unlock(long long userId, const User& admin);

private:
    void updateAccount(long long userId, const Json& changes);

    SupabaseClient& db_;
    UserService& users_;
    AuditService& audit_;
};

}  // namespace portal
