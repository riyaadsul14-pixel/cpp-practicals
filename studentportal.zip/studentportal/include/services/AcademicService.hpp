// ============================================================================
//  AcademicService.h - courses (curriculum) and student enrollments
// ============================================================================
#pragma once

#include <optional>
#include <string>
#include <vector>

#include "db/Repository.hpp"
#include "models/Academic.hpp"
#include "services/AuditService.hpp"
#include "services/UserService.hpp"

namespace portal {

class AcademicService {
public:
    AcademicService(SupabaseClient& db, UserService& users, AuditService& audit, std::string currentAcademicYear)
        : db_(db), users_(users), audit_(audit), currentYear_(std::move(currentAcademicYear)), courses_(db),
          enrollments_(db) {}

    std::vector<Course> listCourses(int semester = 0) const;
    std::optional<Course> findCourse(long long id) const { return courses_.findById(id); }
    std::optional<Course> findCourseByCode(const std::string& code) const;
    std::vector<Course> coursesByIds(const std::vector<long long>& ids) const { return courses_.findByIds(ids); }
    std::vector<Course> coursesForFaculty(long long facultyId) const;
    Course createCourse(const Course& course, const User& actor);
    Course assignFaculty(long long courseId, long long facultyId, const User& actor);

    /// Enrolls every student of the semester in every course of that semester (skips existing).
    int autoEnrollSemester(int semester, const std::string& academicYear, const User& actor);
    std::vector<Enrollment> enrollmentsForStudents(const std::vector<long long>& studentIds) const;
    std::vector<Course> coursesForStudent(long long studentId, int semester = 0) const;
    /// Class roster of the CURRENT academic year (seniors who took the course earlier are excluded).
    std::vector<Student> studentsInCourse(long long courseId) const;

private:
    SupabaseClient& db_;
    UserService& users_;
    AuditService& audit_;
    std::string currentYear_;
    Repository<Course> courses_;
    Repository<Enrollment> enrollments_;
};

}  // namespace portal
