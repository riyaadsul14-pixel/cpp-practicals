// ============================================================================
//  AttendanceService.h - attendance marking and summaries
// ============================================================================
#pragma once

#include <utility>
#include <vector>

#include "db/Repository.hpp"
#include "models/Academic.hpp"
#include "models/Student.hpp"
#include "services/AcademicService.hpp"
#include "services/AuditService.hpp"

namespace portal {

struct CourseAttendance {
    Course course;
    int attended = 0;
    int total = 0;
    double percent() const { return total ? 100.0 * attended / total : 0.0; }
};

struct StudentAttendance {
    Student student;
    int attended = 0;
    int total = 0;
    double percent() const { return total ? 100.0 * attended / total : 0.0; }
};

class AttendanceService {
public:
    AttendanceService(SupabaseClient& db, AcademicService& academic, AuditService& audit)
        : academic_(academic), audit_(audit), records_(db) {}

    /// Saves (or corrects) one lecture's attendance. Only enrolled students are accepted.
    int mark(long long courseId, const Date& date, const std::vector<std::pair<long long, bool>>& presence,
             const User& actor);
    bool isMarked(long long courseId, const Date& date) const;
    std::vector<AttendanceRecord> recordsFor(long long courseId, const Date& date) const;
    std::vector<CourseAttendance> studentSummary(long long studentId, int semester) const;
    std::vector<StudentAttendance> courseSummary(long long courseId) const;
    std::vector<AttendanceRecord> courseRecords(long long courseId) const;
    std::vector<AttendanceRecord> recordsForCourses(const std::vector<long long>& courseIds) const;

private:
    AcademicService& academic_;
    AuditService& audit_;
    Repository<AttendanceRecord> records_;
};

}  // namespace portal
