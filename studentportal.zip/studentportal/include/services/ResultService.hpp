// ============================================================================
//  ResultService.h - marks entry, transcripts (SGPA/CGPA) and target planning
// ============================================================================
#pragma once

#include <map>
#include <optional>
#include <utility>
#include <vector>

#include "db/Repository.hpp"
#include "models/Academic.hpp"
#include "models/Student.hpp"
#include "services/AcademicService.hpp"
#include "services/Analytics.hpp"
#include "services/AuditService.hpp"

namespace portal {

struct ResultSheetRow {
    Student student;
    std::optional<MarkRecord> marks;
    GradeInfo grade;
    bool complete = false;
};

class ResultService {
public:
    ResultService(SupabaseClient& db, AcademicService& academic, AuditService& audit)
        : db_(db), academic_(academic), audit_(audit), marks_(db) {}

    /// Saves one exam component for many students (other components are untouched).
    int saveMarks(long long courseId, ExamComponent component,
                  const std::vector<std::pair<long long, double>>& entries, const User& actor);
    std::vector<MarkRecord> marksForCourse(long long courseId) const;
    std::vector<ResultSheetRow> resultSheet(long long courseId) const;
    Transcript transcriptFor(const Student& student) const;
    /// Transcripts for many students using a handful of bulk queries.
    std::map<long long, Transcript> transcriptsFor(const std::vector<Student>& students) const;
    TargetPlan planTarget(const Student& student, double targetSgpa) const;

private:
    SupabaseClient& db_;
    AcademicService& academic_;
    AuditService& audit_;
    Repository<MarkRecord> marks_;
};

}  // namespace portal
