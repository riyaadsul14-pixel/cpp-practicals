// ============================================================================
//  CampusServices.h - notice board, fees and verifiable documents
// ============================================================================
#pragma once

#include <map>
#include <optional>
#include <string>
#include <vector>

#include "app/UniversityProfile.hpp"
#include "db/Repository.hpp"
#include "models/Campus.hpp"
#include "services/AuditService.hpp"
#include "services/UserService.hpp"

namespace portal {

// ------------------------------------------------------------ NoticeService --
class NoticeService {
public:
    NoticeService(SupabaseClient& db, AuditService& audit) : audit_(audit), notices_(db) {}

    Notice post(const std::string& title, const std::string& body, const std::string& audience, const User& actor);
    /// Notices visible to the role (admins see everything), newest first.
    std::vector<Notice> listFor(Role role, int limit = 20) const;
    void remove(long long noticeId, const User& actor);

private:
    AuditService& audit_;
    Repository<Notice> notices_;
};

// --------------------------------------------------------------- FeeService --
struct FeeStatement {
    FeeAccount fee;
    std::vector<Payment> payments;
    double paid = 0;
    double balance = 0;
    bool overdue = false;
    std::string status() const;  // PAID / PARTIAL / UNPAID (+ OVERDUE)
};

struct DueRow {
    Student student;
    double billed = 0;
    double paid = 0;
    double balance = 0;
    bool overdue = false;
};

struct FeeTotals {
    double billed = 0;
    double collected = 0;
    double pending = 0;
    double overdue = 0;
};

class FeeService {
public:
    FeeService(SupabaseClient& db, UserService& users, AuditService& audit)
        : users_(users), audit_(audit), fees_(db), payments_(db) {}

    /// Bills every student of the semester (students already billed for the same item are skipped).
    int assignToSemester(int semester, const std::string& academicYear, const std::string& description, double amount,
                         const Date& dueDate, const User& actor);
    Payment recordPayment(long long feeId, double amount, const std::string& mode, const std::string& reference,
                          const Date& paidOn, const User& actor);
    std::vector<FeeStatement> statementsFor(long long studentId) const;
    std::vector<DueRow> pendingDues(int semester) const;
    FeeTotals totals() const;
    std::map<long long, double> overdueByStudent() const;

private:
    static std::vector<FeeStatement> combine(const std::vector<FeeAccount>& fees, const std::vector<Payment>& payments);

    UserService& users_;
    AuditService& audit_;
    Repository<FeeAccount> fees_;
    Repository<Payment> payments_;
};

// ---------------------------------------------------------- DocumentService --
enum class VerifyStatus { Genuine, Tampered, NotFound };

struct VerificationResult {
    VerifyStatus status = VerifyStatus::NotFound;
    std::optional<DocumentRecord> document;
    std::optional<Student> student;
};

class DocumentService {
public:
    DocumentService(SupabaseClient& db, UserService& users, AuditService& audit, const UniversityProfile& profile)
        : db_(db), users_(users), audit_(audit), profile_(profile), documents_(db) {}

    DocumentRecord requestBonafide(const Student& student, const std::string& purpose);
    std::vector<DocumentRecord> forStudent(long long studentId) const;
    std::vector<DocumentRecord> pending() const;
    std::optional<DocumentRecord> find(long long id) const { return documents_.findById(id); }
    /// Approves a request: signs it with an HMAC-SHA256 verification code.
    DocumentRecord approve(long long documentId, const std::string& contentDigest, const User& actor);
    DocumentRecord reject(long long documentId, const std::string& remarks, const User& actor);
    /// Self-service document (report card) - issued and signed immediately.
    DocumentRecord issueImmediately(const Student& student, const std::string& docType, const std::string& purpose,
                                    const std::string& contentDigest);
    VerificationResult verify(const std::string& code) const;
    static std::string normalizeCode(const std::string& input);  // "abcd ef12-3456" -> "ABCD-EF12-3456"

private:
    std::string sign(long long documentId, const std::string& docType, const std::string& prn,
                     const std::string& issuedOn, const std::string& digest) const;
    DocumentRecord finalize(long long documentId, const Student& student, const std::string& docType,
                            const std::string& digest, long long decidedBy);

    SupabaseClient& db_;
    UserService& users_;
    AuditService& audit_;
    const UniversityProfile& profile_;
    Repository<DocumentRecord> documents_;
};

}  // namespace portal
