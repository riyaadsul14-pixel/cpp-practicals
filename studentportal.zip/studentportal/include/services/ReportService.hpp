// ============================================================================
//  ReportService.h - dashboards, Student Success Radar, exports, certificates
// ============================================================================
#pragma once

#include <filesystem>
#include <map>
#include <vector>

#include "app/UniversityProfile.hpp"
#include "services/AcademicService.hpp"
#include "services/Analytics.hpp"
#include "services/AttendanceService.hpp"
#include "services/CampusServices.hpp"
#include "services/ResultService.hpp"
#include "services/UserService.hpp"

namespace portal {

struct Overview {
    long long students = 0;
    long long faculty = 0;
    long long courses = 0;
    long long pendingDocuments = 0;
    std::map<int, int> studentsPerSemester;
    FeeTotals fees;
};

struct RadarRow {
    Student student;
    RiskReport risk;
    bool hasAttendance = false;
    double attendance = 0;
    bool hasMarks = false;
    double continuous = 0;
    int backlogs = 0;
    double overdue = 0;
};

class ReportService {
public:
    ReportService(SupabaseClient& db, UserService& users, AcademicService& academic, AttendanceService& attendance,
                  ResultService& results, FeeService& fees, DocumentService& documents,
                  const UniversityProfile& profile)
        : db_(db), users_(users), academic_(academic), attendance_(attendance), results_(results), fees_(fees),
          documents_(documents), profile_(profile) {}

    Overview overview() const;
    /// Early-warning risk scores, highest risk first.
    std::vector<RadarRow> successRadar(const std::vector<Student>& students) const;

    std::filesystem::path exportStudents(int semester) const;
    std::filesystem::path exportAttendance(long long courseId) const;
    std::filesystem::path exportResults(long long courseId) const;
    /// Writes a signed report card text file and returns its path.
    std::filesystem::path writeReportCard(const Student& student, std::string& verificationCode);
    std::filesystem::path writeBonafide(const DocumentRecord& document, const Student& student) const;
    /// Digest of the bonafide text that gets signed when the admin approves a request.
    static std::string bonafideDigest(const DocumentRecord& document, const Student& student,
                                      const std::string& academicYear);

private:
    std::filesystem::path exportPath(const std::string& name, const std::string& extension) const;
    std::string letterHead(const std::string& title) const;

    SupabaseClient& db_;
    UserService& users_;
    AcademicService& academic_;
    AttendanceService& attendance_;
    ResultService& results_;
    FeeService& fees_;
    DocumentService& documents_;
    const UniversityProfile& profile_;
};

}  // namespace portal
